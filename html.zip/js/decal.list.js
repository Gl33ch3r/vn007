$(document).ready(function() {
    $('#basic-datatables').DataTable({
        "order": [[ 0, "desc" ]]
    });
    function displayNotification(title1, msg, state){
        if(state == 'success'){
            iziToast.success({title: title1, message: msg, onClosing: function () {},});
        }else{
            iziToast.error({title: title1, message: msg, onClosing: function () {},});
        }
           return;
    }

    $('#logout-btn-nav').click(function(e) {
        swal({
            title: 'Are you sure?',
            text: 'It will automatically logout your account!',
            type: 'warning',
            buttons:{
                confirm: {
                    text : 'yes',
                    className : 'btn btn-success'
                },
                cancel: {
                    visible: true,
                    className: 'btn btn-danger',
                    text : 'No'
                }
            }
        }).then((confirm) => {
            if (confirm) {
                window.location='/logout' 
            } else {
                swal.close();
            }
        });
    });

    $('#logout-btn').click(function(e) {
        swal({
            title: 'Are you sure?',
            text: 'It will automatically logout your account!',
            type: 'warning',
            buttons:{
                confirm: {
                    text : 'yes',
                    className : 'btn btn-success'
                },
                cancel: {
                    visible: true,
                    className: 'btn btn-danger',
                    text : 'No'
                }
            }
        }).then((confirm) => {
            if (confirm) {
                window.location='/logout' 
            } else {
                swal.close();
            }
        });
    });

    var allCount = $("#count-all");
    if($("#request-li").hasClass('active')){
        allCount.css("display","none");
    }
    $('#toggle-btn').click(function(e) {
        if(!$("#base").hasClass('show')){
            allCount.css("display","none");
        } else {
            allCount.css("display","");
        }
    });
});