<?php
    header("Location: login");
?>