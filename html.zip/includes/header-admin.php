<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title><?php echo APP . " - " . $response["username"]; ?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="..<?php echo ICO ?>" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script type="text/javascript" src="../assets/js/plugin/webfont/webfont.min.js"></script>
	<script type="text/javascript" src="../assets/js/plugin/webfont/webfont.load.js"></script>

	<link rel="stylesheet" href="../css/loading.css" type='text/css'/>

	<!-- CSS Files -->
	<link rel="stylesheet" href="../assets/css/font.nunito.css" type='text/css'/>
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css" type='text/css'/>
	<link rel="stylesheet" href="../assets/css/atlantis.min.css" type='text/css'/>

	<!-- CSS Just for demo purpose, don't include it in your project -->
   
    <link rel="stylesheet" href="../css/intlTelInput.css" type='text/css'/>
    <link rel="stylesheet" href="../dist/css/iziToast.min.css" type='text/css'/>
	<link rel="stylesheet" href="../assets/css/demo.css" type='text/css'/>

	<script type="text/javascript" src="../js/intlTelInput.min.js"></script>
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../dist/assets/jquery-file-upload/js/vendor/jquery.ui.widget.js"></script>
    <script type="text/javascript" src="../dist/assets/jquery-file-upload/js/jquery.iframe-transport.js"></script>
    <script type="text/javascript" src="../dist/assets/jquery-file-upload/js/jquery.fileupload.js"></script>
	<link href='/simplelightbox/dist/simple-lightbox.min.css' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="/simplelightbox/dist/simple-lightbox.jquery.min.js"></script>
	<script type="text/javascript" src="/js/loading.js"></script>
</head>