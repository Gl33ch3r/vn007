<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['id']);
  include_once '../includes/header.login.location.php';
}
if($response['user_role'] != "1"){
    header("Location: ../404");
}
include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
	<div class="wrapper">
		<?php include "../includes/navbar-admin.php" ?>
		<?php include "../includes/sidebar-admin.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Systems Logs</h4>
									</div>
								</div>
								<div class="card-body">
									<div class="table-responsive">
                                        <table id="basic-datatables" class="display table table-striped table-hover" >
                                            <thead>
												<tr>
                                                    <th>Logtime</th>
                                                    <th>Role</th>
													<th>Username</th>
                                                    <th>Type</th>
													<th>Other Info</th>
													<th>IP Address</th>
												</tr>
											</thead>
											<tbody>
												<?php
												    $responseLogs = getLogs($mysqli);
													while($u = mysqli_fetch_array($responseLogs)) {
														$userid = $u["user_id"];
                                                        $type = $u["type_function"];
                                                        $role = $u["is_admin"];
                                                        $other_info = $u["other_info"];
                                                        $ipadd = $u["ipaddress"];
                                                        $logtime = $u["logs_at"];

                                                        if($role == "1"){
                                                            $responseUser = loginAdmin($mysqli, $userid);
                                                            $username = $responseUser["username"];
                                                            $responseSio = getSioName($mysqli, $responseUser["sio_id"]);
                                                            $role = $responseUser["user_role"];
															if($responseUser["user_role"] == "1" || $responseUser["user_role"] == "2" || $responseUser["user_role"] == "5"){
																$roleFlag = getRoleName($mysqli, $role)["name"].", ".$responseUser["account_name"];
															}else{
																$roleFlag = getRoleName($mysqli, $role)["name"]." - ".$responseSio['sio_name'].", ".$responseUser["account_name"];
															}
                                                        }else{
                                                            $roleFlag = "User";
                                                            $responseUser = getUserByID($mysqli, $userid);
                                                            $username = $responseUser["email"];
                                                        }

                                                        if($other_info == "") {
                                                            $other_info = "NONE";
                                                        }

													
                                                        
                                                        
														
												?>
												<tr>
                                                    <td><?php echo $logtime ?></td>
                                                    <td><?php echo $roleFlag ?></td>
													<td><?php echo $username ?></td>
													<td><?php echo $type ?></td>
                                                    <td><?php echo $other_info ?></td>
                                                    <td><?php echo $ipadd ?></td>
												</tr>

												<?php } ?>
												
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "../includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>


	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<script src="../dist/js/iziToast.min.js"></script>
	<script >
		$(document).ready(function() {
			$('#basic-datatables').DataTable({
                "order": [[ 0, "desc" ]],
				lengthMenu: [10, 20, 50, 100, 200, 500], "pageLength": 50
			});
		});
		function displayNotification(title, msg, state, icon){
			if(state == 'success'){
                iziToast.success({title: title1, message: msg, onClosing: function () {},});
            }else{
                iziToast.error({title: title1, message: msg, onClosing: function () {},});
            }
           return;
        }
	
	</script>
		<script>
	<?php
		if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
			$state 	= $_SESSION["state"];
			$msg 	= $_SESSION["msg"];
			$title 	= $_SESSION["title"];

			if($state == "success"){
				$icon = "fas fa-check";
			}else if($state == "warning"){
				$icon = "fas fa-exclamation-circle";
			}else if($state == "danger"){
				$icon = "fas fa-exclamation-triangle";
			}?>
				displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>", "<?php echo $icon; ?>");
	<?php } ?>
	</script>

	<?php
		unset($_SESSION["state"]);
		unset($_SESSION["msg"]);
		unset($_SESSION["title"]);
	?>
    <script src="../js/search.js"></script>
</body>
</html>