<?php
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/constant.php';
if(isset($_POST['emailhost']) && $_POST['emailhost'] != "" && isset($_POST['hostport'])  && $_POST['hostport'] != "" && isset($_POST['email']) &&  $_POST['email'] != "" && isset($_POST['password']) &&  $_POST['password'] != "" && isset($_POST['replyto']) &&  $_POST['replyto'] != ""){
    $content = "<?php\n";
    $content .= "define('APP', '".APP."');\n";
    $content .= "define('ADMIN_TITLE', '".ADMIN_TITLE."');\n";
    $content .= "define('ICO', '".ICO."');\n";
    $content .= "define('SITE_LOGO', '".SITE_LOGO."');\n";
    $content .= "define('PROTOCOL', '".PROTOCOL."');\n";
    $content .= "define('PORT', '".addslashes($_POST['hostport'])."');\n";
    $content .= "define('MAILHOST', '".addslashes($_POST['emailhost'])."');\n";
    $content .= "define('MAIL', '".addslashes($_POST['email'])."');\n";
    $content .= "define('PASSWORD', '".addslashes($_POST['password'])."');\n";
    $content .= "define('REPLYTO', '".addslashes($_POST['replyto'])."');\n";
    $content .= "define('HOST', '".HOST."');\n";
    $content .= "define('PENDING', '".PENDING."');\n";
    $content .= "define('APPROVED', '".APPROVED."');\n";
    $content .= "define('REJECTED', '".REJECTED."');\n";
    $content .= "define('MAINTENANCE', '".MAINTENANCE."');\n";
    $content .= "define('ENABLE_SMS', '".ENABLE_SMS."');\n";
    $content .= "?>";
   
    // Open the config.php for writting
    $handle = fopen('../includes/constant.php', 'w');
    // Write the config file
    $success = fwrite($handle, $content);
    if($success){
        $response["error"]  = false;
        $response["title"]  = "Success";
        $response["msg"]    = "Email Settings successfully saved.";
    }else{
        $response["error"]  = true;
        $response["title"]  = "Error";
        $response["msg"]    = "Problem occured while saving data...";
    }
    // Close the file
    fclose($handle);
}else{
    $response["error"]  = true;
    $response["title"]  = "Error";
    $response["msg"]    = "Problem occured while saving data...";
}
echo json_encode($response);