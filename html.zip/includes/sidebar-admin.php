<!-- Sidebar -->
<div class="sidebar sidebar-style-2" data-background-color="dark2">
	<div class="sidebar-wrapper scrollbar scrollbar-inner">
		<div class="sidebar-content">
			<ul class="nav nav-primary">
				<?php $curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);  ?>
				<?php if($response["user_role"] == "1" || $response["user_role"] == "5"){ ?>
				<li class="nav-item <?php if($curPageName == 'dashboard.php') echo 'active'; ?> ">
					<a href="dashboard">
						<i class="icon-graph"></i>
						<p>Dashboard</p>
					</a>
				</li>
				<?php } ?>

				<li id="request-li" class="nav-item <?php if($curPageName == 'claimed.php' || $curPageName == 'pending.php' || $curPageName == 'rejected.php' || $curPageName == 'approved.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "pending.php" || base64_decode($_GET['from']) ==  "approved.php" || base64_decode($_GET['from']) ==  "rejected.php" || base64_decode($_GET['from']) ==  "claimed.php"))) echo 'active'; ?> submenu">
					<a id="toggle-btn" data-toggle="collapse" href="#base">
						<i class="flaticon-file"></i>
						<?php if($response["user_role"] == "1" || $response["user_role"] == "2"){
									$pending_count = getAllPendingDecalCount($mysqli, $response["user_role"]);
								}else { 
									$pending_count = getSioPendingDecalCount($mysqli, $response["sio_id"], $response["user_role"]);
								}
								?>

						<?php if($response["user_role"] == "3"){ $approved_count = getSioApprovedDecalCount($mysqli, $response["sio_id"], $response["user_role"]); }else{ $approved_count = 0; } ?>
						
						<?php $all_count =  $pending_count + $approved_count; 
						if($all_count > "0"){
							$a_count = "<span id='count-all' class='for-action ml-1'>".$all_count."</span>";
						}else{
							$a_count = "";
						}
						?>
						<p>Decal Request <?php echo $a_count ?></p>
						<span class="caret"></span>
					</a>
					<div class="collapse <?php if($curPageName == 'claimed.php' || $curPageName == 'pending.php' || $curPageName == 'rejected.php' || $curPageName == 'approved.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "pending.php" || base64_decode($_GET['from']) ==  "approved.php" || base64_decode($_GET['from']) ==  "rejected.php" || base64_decode($_GET['from']) ==  "claimed.php"))) echo 'show'; ?>" id="base">
					<ul class="nav nav-collapse">
							<li <?php if($curPageName == 'pending.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "pending.php" ))) echo 'class="active"'; ?>>
								<a href="pending">
									<i class="icon-hourglass"></i>
									<?php if($response["user_role"] == "1" || $response["user_role"] == "2"){ ?>
										<?php $pending_count = getAllPendingDecalCount($mysqli, $response["user_role"]);
										if($pending_count > "0"){
											$p_count = "<span class='for-action ml-1'>".$pending_count."</span>";
										}else{
											$p_count = "";
										}
									?>
									<p>Pending <?php echo $p_count ?></p>
									<?php } else { ?>
										<?php $pending_count = getSioPendingDecalCount($mysqli, $response["sio_id"], $response["user_role"]);
										if($pending_count > "0"){
											$p_count = "<span class='for-action ml-1'>".$pending_count."</span>";
										}else{
											$p_count = "";
										}
									?>
									<p>Pending <?php echo $p_count ?></p>
									<?php } ?>
								</a>
							</li>
							
							<li <?php if($curPageName == 'rejected.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "rejected.php" ))) echo 'class="active"'; ?>>
								<a href="rejected">
									<i class="icon-ban"></i>
									<p>Rejected</p>
								</a>
							</li>
							
							<li <?php if($curPageName == 'approved.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "approved.php" ))) echo 'class="active"'; ?>>
								<a href="approved">
									<i class="icon-like"></i>
									<?php if($response["user_role"] == "1" || $response["user_role"] == "2" || $response["user_role"] == "3"){ ?>
									<p>Approved</p>
									<?php } else { ?>
									<?php $approved_count = getSioApprovedDecalCount($mysqli, $response["sio_id"], $response["user_role"]);
										if($approved_count > "0"){
											$a_count = "<span class='for-action ml-1'>".$approved_count."</span>";
										}else{
											$a_count = "";
										}
									?>
									<p>Approved <?php echo $a_count ?></p>
									<?php } ?>
								</a>
							</li>
							<li <?php if($curPageName == 'claimed.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "claimed.php" ))) echo 'class="active"'; ?>>
								<a href="claimed">
									<i class="flaticon-list"></i>
									<p>Claimed</p>
								</a>
							</li>
							
						</ul>
					</div>
				</li>
				<?php if($response["user_role"] == "1" || $response["user_role"] == "2" || $response["user_role"] == "3" || $response["user_role"] == "5"){ ?>
				<li class="nav-item">
					<a href="#" id="report-btn" data-toggle="modal" data-target="#reportModal">
						<i class="flaticon-presentation"></i>
						<p>Generate Report</p>
					</a>
				</li>
				<li class="nav-item">
					<a href="#" id="search-btn" data-app-id="<?php echo $responseDecalInfo['application_id']; ?>"  data-toggle="modal" data-target="#searchModal">
						<i class="flaticon-search-2"></i>
						<p>Search Vehicle Info</p>
					</a>
				</li>
				<?php } ?>
				<?php if($response["user_role"] == "1" || $response["user_role"] == "5"){ ?>
				<li class="nav-item <?php if($curPageName == 'users.php') echo 'active'; ?> ">
					<a href="users">
						<i class="flaticon-users"></i>
						<p>Users Accounts</p>
					</a>
				</li>
				<?php } if($response["user_role"] == "1"){ ?>
				<li class="nav-item <?php if($curPageName == 'admin.accounts.php') echo 'active'; ?> ">
					<a href="admin.accounts">
						<i class="flaticon-user-5"></i>
						<p>Admin Accounts</p>
					</a>
				</li>
				<li class="nav-item <?php if($curPageName == 'logs.php') echo 'active'; ?> ">
					<a href="logs">
						<i class="flaticon-agenda-1"></i>
						<p>System Logs</p>
					</a>
				</li>
				<li class="nav-item <?php if($curPageName == 'site-settings.php' || $curPageName == 'mail-settings.php') echo 'active'; ?> submenu">
					<a data-toggle="collapse" href="#settings">
						<i class="flaticon-settings"></i>
						<p>Settings</p>
						<span class="caret"></span>
					</a>
					<div class="collapse <?php if($curPageName == 'site-settings.php' || $curPageName == 'mail-settings.php') echo 'show'; ?>" id="settings">
						<ul class="nav nav-collapse">
							<li <?php if($curPageName == 'site-settings.php') echo 'class="active"' ?>>
								<a href="site-settings">
								<i class="fas fa-globe"></i>
									<span>Site Settings</span>
								</a>
							</li>
							<li <?php if($curPageName == 'mail-settings.php') echo 'class="active"' ?>>
								<a href="mail-settings">
								<i class="far fa-envelope-open"></i>
									<span>Email Settings</span>
								</a>
							</li>
						</ul>
					</div>
				</li>
				<?php } ?>
				<li class="nav-item">
					<a href="#" id="logout-btn">
						<i class="flaticon-arrow"></i>
						<p>Logout</p>
					</a>
				</li>
			</ul>
		</div>
	</div>
</div>
<!-- End Sidebar -->