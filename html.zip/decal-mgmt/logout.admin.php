<?php
session_start();
require_once('../includes/config.php');
require_once "../includes/functions.php";
$mysqli = db_connect($config);
$ipaddress = getPublicIP();
$responseLogs = addLogs($mysqli, $_SESSION['id'], "Logout", "", $ipaddress, "1");
if(!$responseLogs["error"]){
    unset($_SESSION['id']);
    setcookie("user_c", "", time() - 3600);
    session_destroy();
    header("Location: login");
}else{
    unset($_SESSION['id']);
    setcookie("user_c", "", time() - 3600);
    session_destroy();
    header("Location: login");
}
?>