<?php
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/constant.php';
$response = array();
if(isset($_POST['site_status']) && $_POST['site_status'] != "" && isset($_POST['site_name']) && $_POST['site_name'] != "" && isset($_POST['admin_site_name'])  && $_POST['admin_site_name'] != "" && isset($_POST['uploaded_favico_name']) &&  $_POST['uploaded_favico_name'] != "" && isset($_POST['uploaded_sitelogo_name']) &&  $_POST['uploaded_sitelogo_name'] != ""){
    $content = "<?php\n";
    $content .= "define('APP', '".addslashes($_POST['site_name'])."');\n";
    $content .= "define('ADMIN_TITLE', '".addslashes($_POST['admin_site_name'])."');\n";
    $content .= "define('ICO', '".addslashes($_POST['uploaded_favico_name'])."');\n";
    $content .= "define('SITE_LOGO', '".addslashes($_POST['uploaded_sitelogo_name'])."');\n";
    $content .= "define('PROTOCOL', '".PROTOCOL."');\n";
    $content .= "define('PORT', '".PORT."');\n";
    $content .= "define('MAILHOST', '".MAILHOST."');\n";
    $content .= "define('MAIL', '".MAIL."');\n";
    $content .= "define('PASSWORD', '".PASSWORD."');\n";
    $content .= "define('REPLYTO', '".REPLYTO."');\n";
    $content .= "define('HOST', '".HOST."');\n";
    $content .= "define('PENDING', '".PENDING."');\n";
    $content .= "define('APPROVED', '".APPROVED."');\n";
    $content .= "define('REJECTED', '".REJECTED."');\n";
    $content .= "define('MAINTENANCE', '".addslashes($_POST['site_status'])."');\n";
    $content .= "define('ENABLE_SMS', '".ENABLE_SMS."');\n";
    $content .= "?>";
   
    // Open the config.php for writting
    $handle = fopen('../includes/constant.php', 'w');
    // Write the config file
    $success = fwrite($handle, $content);
    if($success){
        $response["error"]  = false;
        $response["title"]  = "Success";
        $response["msg"]    = "Site Settings successfully saved.";
    }else{
        $response["error"]  = true;
        $response["title"]  = "Error";
        $response["msg"]    = "Problem occured while saving data...";
    }
    // Close the file
    fclose($handle);
}else{
    $response["error"]  = true;
    $response["title"]  = "Error";
    $response["msg"]    = "Problem occured while saving data...";
}
echo json_encode($response);