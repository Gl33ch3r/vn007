<div class="overlay"></div>
</body>
  <script src="../dist/js/iziToast.min.js"></script>
  <script src="../js/functions.js"></script>
  <script>
    <?php 
    if(isset($_SESSION['status']) && isset($_SESSION['msg'])){
    if($_SESSION['status'] == "success"){ ?>
        iziToast.success({title: 'OK', message: '<?php echo $_SESSION['msg']; ?>', onClosing: function () {
        },});
    <?php }else if($_SESSION['status'] == "error"){ ?>
        iziToast.error({title: 'Error', message: '<?php echo $_SESSION['msg']; ?>', onClosing: function () {
        },});
    <?php } 
    unset($_SESSION['status']);
    unset($_SESSION['msg']);
    }
    ?>
</script>
</html>
