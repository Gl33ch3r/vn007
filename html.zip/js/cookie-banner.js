const cookieContainer = $("#cookie-container");
const cookieButton = $("#cookie-btn");

cookieButton.click(function(){
  cookieContainer.removeClass("active");
  localStorage.setItem("cookieBannerDisplayed", "true");
});

setTimeout(() => {
  if (!localStorage.getItem("cookieBannerDisplayed")) {
    cookieContainer.addClass("active");
  }
}, 2000);