<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
  header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
require_once "../mailer.php";
require_once "../otp.php";

$mysqli = db_connect($config);
$responseRevoked = array();
$aid =  mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["id"], ENT_QUOTES, 'UTF-8'));
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$remarks =  mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["remarks"], ENT_QUOTES, 'UTF-8'));
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  $responseRevoked = true;
  echo json_encode($responseRevoked);
  return;
}
if($response["user_role"] != "1"){
  $responseRevoked = true;
  echo json_encode($responseRevoked);
  return;
}

$responseDecalInfo = getDecalInformation($mysqli, $aid);
$responseUser =  getUserByID($mysqli, $responseDecalInfo["user_id"]);
$responseVehicleInfo = getVehicleInformation($mysqli, $responseDecalInfo["vehicle_id"]);
if($responseVehicleInfo['error']){
  $responseRevoked = true;
  echo json_encode($responseRevoked);
  return;
}

$email  = $responseUser["email"];
$subject = "Request Revoked - Philippine Navy Decal System";
$content = "<font size='3' face='Courier New' >Dear ".$responseUser["firstname"].",<br><br>    We would like to inform you that your Decal for the Vehicle with following information below is revoked due to ".$remarks.".</font> <br><br><br>
<center><table style='width:60%; font-family:Courier New, Courier, monospace; font-size: 18px;'>
<tr><th style='border: 1px solid black;'>Plate No.</th><th style='border: 1px solid black;'>Maker</th><th style='border: 1px solid black;'>Vehicle Model</th> <th style='border: 1px solid black;'>Year Model</th> <th style='border: 1px solid black;'>Color</th></tr>
<tr><td style='border: 1px solid black;'>".$responseVehicleInfo["plate_number"]."</td><td style='border: 1px solid black;'>".$responseVehicleInfo["vehicle_maker"]."</td><td style='border: 1px solid black;'>".$responseVehicleInfo["vehicle_model"]."</td><td style='border: 1px solid black;'>".$responseVehicleInfo["year_model"]."</td><td style='border: 1px solid black;'>".$responseVehicleInfo["vehicle_color"]."</td></tr>
</table></center>";

$responseRemarks = addRemarksRejected($mysqli, $aid, $remarks, $id);
if($responseRemarks['error']){
  $responseRevoked = true;
  echo json_encode($responseRevoked);
  return;
}

if(ENABLE_SMS == '1'){
  $number  = $responseUser["mobile"];
  $textMessage = "Dear ".$responseUser["firstname"].", We would like to inform you that your Decal request for the Vehicle with plate number ".$responseVehicleInfo["plate_number"]." is revoked due to ".$remarks.".";
  sendTextMessage($number,  $textMessage);
}

addTimeLine($mysqli, $aid, $id, "6", "0", "4");
$responseMail = sendMail($email, $subject, $content);
echo json_encode($responseMail);

?>
