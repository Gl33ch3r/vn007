<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['id']);
  include_once '../includes/header.login.location.php';
}

include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
<div class="wrapper">
        <?php include "../includes/navbar-admin.php" ?>
		<?php include "../includes/sidebar-admin.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<div class="card" id="emailSettingForm">
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Email Settings</h4>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
								
										<div class="col-md-5 mx-auto">	
                                        <div class="form-group">
                                        </div> 
                                            <div class="form-group">
												<label for="account_name">EMAIL HOST SERVER</label>
												<input type="text" class="form-control" id="emailhost" name="emailhost" placeholder="Enter Email Host" value="<?php echo MAILHOST; ?>" >
											</div>
											<div class="form-group">
												<label for="username">SERVER PORT</label>
												<input type="number" class="form-control" id="hostport" name="hostport" placeholder="Enter (1-65535)" value="<?php echo PORT; ?>" >
											</div>

                                            <div class="form-group">
												<label for="username">EMAIL ADDRESS</label>
												<input type="text" class="form-control" id="email" name="email" placeholder="Enter Email Address" value="<?php echo MAIL; ?>" >
											</div>
                                            <div class="form-group">
												<label for="username">EMAIL PASSWORD</label>
                                                <div class="input-group mb-3"  id="show_hide_password">
                                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" value="<?php echo PASSWORD; ?>" >
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">
                                                            <a href=""><i class="fa fa-eye-slash" aria-hidden="true"></i></a>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group">
												<label for="username">REPLY TO</label>
												<input type="text" class="form-control" id="replyto" name="replyto" placeholder="Enter Reply To" value="<?php echo REPLYTO; ?>" >
											</div>
                                           
                                            <br>
                                            <div class="card-action">
                                                <div class="d-flex justify-content-center">
                                                    <button type="button" id="save-mail-btn" class="btn btn-success btn-round pr-5 pl-5"><i class="far fa-save"></i>  Save</button>
                                                </div>
                                            </div>
										</div>
								</div>
                            </div>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "../includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<script src="../dist/js/iziToast.min.js"></script>
    <script src="js/upload.admin.js"></script>
    <script>

        $(document).ready(function() {
            $("#show_hide_password a").on('click', function(event) {
                event.preventDefault();
                if($('#show_hide_password input').attr("type") == "text"){
                    $('#show_hide_password input').attr('type', 'password');
                    $('#show_hide_password i').addClass( "fa-eye-slash" );
                    $('#show_hide_password i').removeClass( "fa-eye" );
                }else if($('#show_hide_password input').attr("type") == "password"){
                    $('#show_hide_password input').attr('type', 'text');
                    $('#show_hide_password i').removeClass( "fa-eye-slash" );
                    $('#show_hide_password i').addClass( "fa-eye" );
                }
            });
        });
		$(document).ready(function(){
            var gallery = $('#photoviewer_sitelogo').simpleLightbox();
        });
        $(document).ready(function(){
            var gallery = $('#photoviewer_favico').simpleLightbox();
        });
		
        
	  	function displayNotification(title1, msg, state){
            if(state == 'success'){
                iziToast.success({title: title1, message: msg, onClosing: function () {},});
            }else{
                iziToast.error({title: title1, message: msg, onClosing: function () {},});
            }
           
           return;
        }

        $("#save-mail-btn").click(function () {
            if($.trim($("#emailhost").val()) === "") {
                displayNotification("Error", "Please enter Host Email Server...", "danger");
                return;
            } 
            if($.trim($("#hostport").val()) === "") {
                displayNotification("Error", "Please enter Host Port...", "danger");
                return;
            } 
            if($.trim($("#email").val()) === "") {
                displayNotification("Error", "Please enter Email Address...", "danger");
                return;
            } 
            if($.trim($("#password").val()) === "") {
                displayNotification("Error", "Please enter Email Password...", "danger");
                return;
            } 
            if($.trim($("#replyto").val()) === "") {
                displayNotification("Error", "Please enter Reply To Email Address...", "danger");
                return;
            } 
            var emailhost = $("#emailhost").val();
            var hostport =  $("#hostport").val();
            var email = $("#email").val();
            var password =  $("#password").val();
            var replyto =  $("#replyto").val();
            $.ajax({
                type: "POST",
                url: "save.mail-settings.php",
                data: { 'emailhost': emailhost, 'hostport': hostport, 'email': email, 'password': password, 'replyto': replyto },
                dataType : 'json',
                cache: false,
                success: function(response) {
                    if(response.error){
                        iziToast.error({title: response.title, message: response.msg, onClosing: function () {},});
                    }else{
                        iziToast.success({title:  response.title, message: response.msg, onClosing: function () {},});
                    }
                },failure: function (response) {
                    swal("Internal Error","Oops, something went wrong.", "error")
                }
            });
        });
    </script>
<script src="../js/search.js"></script>
</body>
</html
