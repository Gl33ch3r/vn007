<?php
session_start();
if(!isset($_GET['id'])){
    echo '<script>window.location="../404"</script>';
}
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$aid =  mysqli_real_escape_string($mysqli, $_GET["id"]);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['id']);
  include_once '../includes/header.login.location.php';
  return;
}

$responseDecalInfo =  getDecalInformation($mysqli, $aid);
if($responseDecalInfo['error']){
    header('Location: ../404');
    return;
}

$responseAccount =  getUserByID($mysqli, $responseDecalInfo["user_id"]);
if($responseAccount['error']){
    header('Location: ../404');
    return;
}

$resVehicleInfo =  getVehicleInformation($mysqli, $responseDecalInfo["vehicle_id"]);
if($resVehicleInfo['error']){
    header('Location: ../404');
    return;
}
$classification = $responseAccount["classification"];

include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
<div class="overlay"></div>
<div class="wrapper">
    <?php include "../includes/navbar-admin.php" ?>
	<?php include "../includes/sidebar-admin.php"; ?>
    <div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
                       
					</div>
					<div class="row">
					    <div class="col-md-12">
							<div class="card" >
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Decal Application of <?php echo $responseAccount["firstname"] ?></h4>
                                        <div class="float-right" style="width:100%">
                                            <a class="btn btn-primary btn-round pull-right pl-5 pr-5 ml-2 mr-2" href="download/<?php echo $aid ?>">
                                                <i class="flaticon-download"></i>Export
                                            </a>
                                            <button class="btn btn-primary btn-round pull-right pl-5 pr-5 ml-2 mr-2" type="button" data-toggle="modal" data-target="#timelineModal">
                                                <i class="fas fa-clock"></i>
                                                Timeline
                                            </button>
                                        </div>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6 mx-auto">
                                            <div class="form-group" id="select_file_support">
                                                <div class="profile-picture text-center">
                                                    <div class="avatar avatar-xxxl">
                                                        <a id="photoviewer" href="<?php echo $responseAccount['profile_pic']; ?>">
                                                            <img src="<?php echo $responseAccount['profile_pic']; ?>" alt="..." id="profile_pic" class="avatar-img rounded-circle">
                                                        </a> 
                                                    </div>
                                                </div>   
                                            </div>
                                            <?php       
                                                $status = $responseDecalInfo["status"];
                                                $has_deficiency = $responseDecalInfo["has_deficiency"];
                                                $is_claimed 		= $responseDecalInfo["is_claimed"];
												if($status == "0" && $has_deficiency){
													$statusFlag = "<span style='color:#f25961!important; font-style: italic; font-weight:700 '>Pending - Has Deficiency</span>";
													$remarks = $responseDecalInfo["remarks"];
												}elseif($status == "0" && !$has_deficiency){
													$statusFlag = "<span style='color:#ffad46!important; font-style: italic; font-weight:700'>Pending</span>";
													$remarks = "NONE";
												}else if($status == "1" && $is_claimed){
													$statusFlag = "<span style='color:#31ce36!important; font-style: italic; font-weight:700'>Claimed</span>";
													$responseSio	   = getSioName($mysqli, $responseDecalInfo["sio_id"]);
													$remarks = "Claimed by ".$responseDecalInfo["claimed_by"]." at SIO ".$responseSio["sio_name"]. " on ".$responseDecalInfo["date_claimed"]; 
                                                    $responseAdminUser  = loginAdmin($mysqli, $responseDecalInfo["released_by"]);
												}else if($status == "1" && !$is_claimed){
													$statusFlag = "<span style='color:#31ce36!important; font-style: italic; font-weight:700'>Approved</span>";
													$remarks = "NONE";
												}else if($status == "2"){
													$statusFlag = "<span style='color:#f25961!important; font-style: italic; font-weight:700'>Rejected</span>";
                                                    $remarks = $responseDecalInfo["remarks"];
												}
                                            ?>
                                            <div class="form-group">
                                                <h5 class="card-title">Status: <?php echo  $statusFlag  ?></h5>
                                            </div>
                                            <div class="form-group">
                                                <h5 class="card-title">Remarks: <span style="font-style: italic;"><?php echo $remarks ?></span> </h5>
                                            </div>
                                            <?php if($is_claimed && $responseDecalInfo["status"] == '1'){?>
                                            <div class="form-group">
                                                <h5 class="card-title">Decal No.: <span><?php echo  $responseDecalInfo["decal_number"] ?></span> </h5>
                                            </div>
                                            <div class="form-group">
                                                <h5 class="card-title">Released by: <span><?php echo  $responseAdminUser["account_name"] ?></span> </h5>
                                            </div>
                                            <?php } ?>
                                            <div class="form-group"> 
                                                <h5><b>Personal Information</b></h5>
                                            </div>
											<div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <label for="lastname">Lastname</label>
                                                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Enter Lastname" value="<?php echo $responseAccount['lastname']; ?>" disabled>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="firstname">Firstname</label>
                                                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Enter Firstname" value="<?php echo $responseAccount['firstname']; ?>" disabled>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="middlename">Middlename</label>
                                                        <input type="text" class="form-control" id="middlename" name="middlename" placeholder="Enter Middlename" value="<?php echo $responseAccount['middlename']; ?>" disabled>
                                                    </div>
                                                </div>
                                            </div>
                                           
											<div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="phone">Mobile Number</label>
                                                        <input class="form-control" placeholder="9xxxxxxxxx" id="phone" name="phone" type="phone"  maxlength="13"  value="<?php echo $responseAccount['mobile']; ?>" disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="birthdate">Birthdate</label>
                                                        <input class="form-control" placeholder="DD/MM/YYYY"  id="birthdate" style="color-scheme: dark;" name="birthdate" type="date" value="<?php echo $responseAccount['birthdate']; ?>" disabled>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
												<label for="address">Complete Address</label>
												<textarea type="text" class="form-control" id="address" name="address" placeholder="Enter Complete Address" disabled><?php echo $responseAccount['address']; ?> </textarea>
											</div>
                                            <div class="form-group">
												<label for="classification">Select Personnel Classification</label>
												<select class="form-control"  name="classification" id="classification" disabled>
                                                <?php $type = getAllClassification($mysqli, $responseAccount['classification']);
                                                foreach ($type as $value){
                                                        echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                } ?>
												</select>
											</div>
                                            <div id="active">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="bos_a">Branch of Service</label>
                                                            <select class="form-control" name="bos_a" id="bos_a" disabled>
                                                            <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                            foreach ($type as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="rank_a">Select Rank</label>
                                                            <select class="form-control" name="rank_a" id="rank_a" disabled>
                                                            <?php $ranks = getAllRanks($mysqli, $responseAccount['rank']);
                                                            foreach ($ranks as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['rank'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="date_enlisted_a">Date Enlisted</label>
                                                            <input class="form-control"  placeholder="dd/mm/yyyy"   value="<?php echo $responseAccount['date_enlisted'] ?>" id="date_enlisted_a" style="color-scheme: dark;" name="date_enlisted_a" type="date" disabled>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="date_retired_a">Date Retired</label>
                                                            <input class="form-control"  placeholder="dd/mm/yyyy"  value="<?php echo $responseAccount['date_retired'] ?>" id="date_retired_a" style="color-scheme: dark;" name="date_retired_a" type="date" disabled>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="serial_number_a">Serial Number</label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $responseAccount['serial_number'] ?>" id="serial_number_a" name="serial_number_a" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="designation_a">Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_a" name="designation_a" value="<?php echo $responseAccount['designation'] ?>" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_a">Unit Assignment</label>
                                                    <input type="text" class="form-control" id="unit_a" name="unit_a" value="<?php echo $responseAccount['unit_name'] ?>" placeholder="Enter Unit Assignment" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_mobile_a">Unit Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" maxlength="13" value="<?php echo $responseAccount['unit_mobile'] ?>" id="unit_mobile_a" name="unit_mobile_a" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_address_a">Unit Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_a" name="unit_address_a" placeholder="Enter Unit Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="retired" style="display:none;">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="bos_b">Branch of Service</label>
                                                            <select class="form-control" name="bos_b" id="bos_b" disabled>
                                                            <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                            foreach ($type as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="rank_b">Select Rank</label>
                                                            <select class="form-control" name="rank_b" id="rank_b" disabled>
                                                            <?php $ranks = getAllRanks($mysqli, $responseAccount['rank']);
                                                            foreach ($ranks as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['rank'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group" id="des">
                                                    <label for="designation_b">Last Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_b" value="<?php echo $responseAccount['designation'] ?>" name="designation_b" placeholder="Enter Last Designation/Office" disabled>
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_b">Last Unit Name</label>
                                                    <input type="text" class="form-control" id="unit_b" name="unit_b" value="<?php echo $responseAccount['unit_name'] ?>" placeholder="Enter Last Unit Name" disabled>
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_b">Last Unit Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $responseAccount['unit_mobile'] ?>"  onkeypress="return onlyNumberKey(event)" maxlength="13" id="unit_mobile_b" name="unit_mobile_b" type="text" disabled>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_b">Last Unit Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_b" name="unit_address_b" placeholder="Enter Last Unit Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="reservist" style="display:none;">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="bos_r">Branch of Service</label>
                                                            <select class="form-control" name="bos_r" id="bos_r" disabled>
                                                            <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                            foreach ($type as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="rank_r">Select Rank</label>
                                                            <select class="form-control" name="rank_r" id="rank_r" disabled>
                                                            <?php $ranks = getAllRanks($mysqli, $responseAccount['rank']);
                                                            foreach ($ranks as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['rank'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group" id="reservist_sn">
                                                    <label for="serial_number_r">Serial Number</label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $responseAccount['serial_number'] ?>" id="serial_number_r" name="serial_number_r" type="text" disabled>
                                                </div>

                                                <div class="form-group" id="des">
                                                    <label for="designation_r">Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_r" value="<?php echo $responseAccount['designation'] ?>" name="designation_r" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_r">Company Name</label>
                                                    <input type="text" class="form-control" id="unit_r" name="unit_r" value="<?php echo $responseAccount['unit_name'] ?>" placeholder="Enter Company Name" disabled>
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_r">Company Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $responseAccount['unit_mobile'] ?>"  onkeypress="return onlyNumberKey(event)" maxlength="13" id="unit_mobile_r" name="unit_mobile_r" type="text" disabled>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_r">Company Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_r" name="unit_address_r" placeholder="Enter Company Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="chr" style="display:none;">
                                                <div class="form-group">
                                                    <label for="bos_c">Branch of Service</label>
                                                    <select class="form-control" name="bos_c" id="bos_c" disabled>
                                                    <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                        foreach ($type as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                        } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="date_enlisted_c">Date Employed</label>
                                                            <input class="form-control"  placeholder="dd/mm/yyyy" value="<?php echo $responseAccount['date_enlisted'] ?>" id="date_enlisted_c" style="color-scheme: dark;" name="date_enlisted_c" type="date" disabled>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="date_retired_c">Date Retired</label>
                                                            <input class="form-control"  placeholder="dd/mm/yyyy" value="<?php echo $responseAccount['date_retired'] ?>" id="date_retired_c" style="color-scheme: dark;" name="date_retired_c" type="date" disabled>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group" id="chrid">
                                                    <label for="serial_number_c">CivHR Number</label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $responseAccount['serial_number'] ?>" id="serial_number_c" name="serial_number_c" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="designation_c">Designation/Office</label>
                                                    <input type="text" class="form-control" value="<?php echo $responseAccount['designation'] ?>" id="designation_c" name="designation_c" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_c">Unit Assignment</label>
                                                    <input type="text" class="form-control"  value="<?php echo $responseAccount['unit_name'] ?>" id="unit_c" name="unit_c" placeholder="Enter Unit Assignment" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_mobile_c">Unit Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $responseAccount['unit_mobile'] ?>" maxlength="13" id="unit_mobile_c" name="unit_mobile_c" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_address_c">Unit Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_c" name="unit_address_c" placeholder="Enter Unit Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="dependent_active" style="display:none;">
                                                <div class="form-group">
                                                    <label for="dependent_of_d">Dependent of?</label>
                                                    <input class="form-control"  placeholder="Dependent of?" value="<?php echo $responseAccount['dependent_of'] ?>" id="dependent_of_d" name="dependent_of_d" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="bos_d">Branch of Service</label>
                                                    <select class="form-control" name="bos_d" id="bos_d" disabled>
                                                    <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                        foreach ($type as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                        } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="serial_number_d">Serial Number</label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $responseAccount['serial_number'] ?>" id="serial_number_d" name="serial_number_d" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="designation_d">Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_d" value="<?php echo $responseAccount['designation'] ?>" name="designation_d" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_d">Unit Assignment</label>
                                                    <input type="text" class="form-control" id="unit_d"  value="<?php echo $responseAccount['unit_name'] ?>" name="unit_d" placeholder="Enter Unit Assignment" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_mobile_d">Unit Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $responseAccount['unit_mobile'] ?>" maxlength="13" id="unit_mobile_d" name="unit_mobile_d" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_address_d">Unit Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_d" name="unit_address_d" placeholder="Enter Unit Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="dependent_retired" style="display:none;">
                                                <div class="form-group">
                                                    <label for="dependent_of_e">Dependent of?</label>
                                                    <input class="form-control"  placeholder="Dependent of?" value="<?php echo $responseAccount['dependent_of'] ?>" id="dependent_of_e" name="dependent_of_e" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="bos_e">Branch of Service</label>
                                                    <select class="form-control" name="bos_e" id="bos_e" disabled>
                                                    <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                        foreach ($type as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                        } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group" id="des">
                                                    <label for="designation_e">Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_e" value="<?php echo $responseAccount['designation'] ?>" name="designation_e" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_e">Company Name</label>
                                                    <input type="text" class="form-control" id="unit_e" value="<?php echo $responseAccount['unit_name'] ?>" name="unit_e" placeholder="Enter Company Name" disabled>
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_e">Company Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $responseAccount['unit_mobile'] ?>" maxlength="13" id="unit_mobile_e" name="unit_mobile_e" type="text" disabled>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_e">Company Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_e" name="unit_address_e" placeholder="Enter Company Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="others" style="display:none;">
                                                <div class="form-group" id="des">
                                                    <label for="designation_f">Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_f" value="<?php echo $responseAccount['designation'] ?>" name="designation_f" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_f">Company Name</label>
                                                    <input type="text" class="form-control" id="unit_f" value="<?php echo $responseAccount['unit_name'] ?>" name="unit_f" placeholder="Enter Company Name" disabled>
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_f">Company Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx"  value="<?php echo $responseAccount['unit_mobile'] ?>"  maxlength="13" id="unit_mobile_f" name="unit_mobile_f" type="text" disabled>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_f">Company Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_f" name="unit_address_f" placeholder="Enter Company Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                               
                                            </div>
                                            <br>
										
                                            <div class="form-group"> 
                                            <h5><b>Vehicle Information</b></h5>
                                            </div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="sio">Select SIO</label>
                                                        <select class="form-control" name="sio" id="sio" disabled>
                                                        <?php $sios = getAllSios($mysqli, $responseDecalInfo["sio_id"]);
                                                        foreach ($sios as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['sios'].'</option>';
                                                        } ?>
                                                        </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="selectYearModel">Year Model</label>
                                                            <input class="form-control" value="<?php echo $resVehicleInfo['year_model'] ?>" id="selectYearModel" type="text" disabled>
                                                        </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="plate_number">Plate No.</label>
                                                        <input class="form-control" value="<?php echo $resVehicleInfo['plate_number'] ?>" placeholder="Enter Plate No." id="plate_number" name="plate_number" type="text" disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="vehicle_color">Color</label>
                                                        <input class="form-control" value="<?php echo $resVehicleInfo['vehicle_color'] ?>" placeholder="Enter Vehicle Color" id="vehicle_color" name="vehicle_color" type="text" disabled>
                                                    </div>
                                                </div>
											</div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="vehicle_maker">Vehicle Manufacturer</label>
                                                        <input class="form-control" value="<?php echo $resVehicleInfo['vehicle_maker'] ?>" placeholder="Enter Vehicle Manufacturer" id="vehicle_maker" name="vehicle_maker" type="text" disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="vehicle_model">Vehicle Model</label>
                                                        <input type="text" value="<?php echo $resVehicleInfo['vehicle_model'] ?>" class="form-control" id="vehicle_model" name="vehicle_model" placeholder="Enter Vehicle Model" disabled>
											        </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="chassis_number">Chassis No.</label>
                                                        <input type="text" value="<?php echo $resVehicleInfo['chassis_number'] ?>" class="form-control" id="chassis_number" name="chassis_number" placeholder="Enter Chassis No." disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="motor_number">Engine No.</label>
                                                        <input class="form-control" value="<?php echo $resVehicleInfo['motor_number'] ?>" placeholder="Enter Engine No." id="motor_number" name="motor_number" type="text" disabled>
                                                    </div>
                                                </div>
											</div>
                                            <?php if($classification == "8" || $classification == "9" || $classification == "10"){ ?>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="endorse_by">Endorse by</label>
                                                        <input type="text" class="form-control" value="<?php echo $responseDecalInfo['endorse_by'] ?>" id="endorse_by" name="endorse_by" placeholder="Enter name of your Endorser"  disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="owner">Endorser's Contact No.</label>
                                                        <input class="form-control" placeholder="63xxxxxxxxx"  value="<?php echo $responseDecalInfo['endorser_contact'] ?>" id="endorser_phone" name="endorser_phone" type="phone" onkeypress="return onlyNumberKey(event)" maxlength="13" disabled>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php } ?>
											<div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="owner">Is the vehicle in your name?</label>
                                                        <select class="form-control" name="owner" onchange="handleSelectChange(event)" id="owner" disabled>
                                                            <option value="1" <?php if($resVehicleInfo['is_owner'] == "1"){ echo "selected"; } ?>>Yes</option>
                                                            <option value="0" <?php if($resVehicleInfo['is_owner'] == "0"){ echo "selected"; } ?>>No</option>
                                                        </select>
                                                    </div>
                                                    <?php if($classification == "2") { ?>
                                                    <div class="col-lg-6">
                                                        <label for="decal_type">Decal Type</label>
                                                        <select class="form-control" name="decal_type" id="decal_type" disabled>
                                                            <option value="passcard" <?php if($responseDecalInfo['decal_type'] == "passcard"){ echo "selected"; } ?>>Passcard</option>
                                                            <option value="sticker" <?php if($responseDecalInfo['decal_type'] == "sticker"){ echo "selected"; } ?>>Sticker</option>
                                                        </select>
                                                    </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="form-group"> 
                                                <h5><b>Document Requirements</b></h5>
                                            </div>
                                            <div class="form-group">
                                                    <label>Application Form</label>
                                            </div> 
                                            <div class="form-group" id="select_file_af"  style="display: none;">
                                                <input id="afupload" type="file" name="id_af_file" accept="image/x-png, image/gif, image/jpeg">
                                                <br>
                                                <div id="progress_af" class="progress" style="display: none;">
                                                     <div class="progress-bar progress-bar-success"></div>
                                                 </div>
                                            </div>
                                            <div id="uploaded_images_af" class="form-group">
                                                <div class="uploaded_af avatar-id avatar-new"> 
                                                    <input type="text" value="<?php echo $responseDecalInfo['application_form_path'] ?>" name="uploaded_af_name" id="uploaded_af_name" hidden=""> 
                                                    <?php if(fileExtension($responseDecalInfo['application_form_path']) == "pdf"){ ?>
                                                        <a href="<?php echo $responseDecalInfo['application_form_path'] ?>"  target="_blank"> 
                                                            <img src="/img/pdf_icon.png" class="avatar-img rounded"> 
                                                        </a> 
                                                        <a id="remove-af-btn" class="img_rmv btn" style="display: none;">
                                                            <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                        </a> 
                                                    <?php }else{ ?>
                                                        <a target="_blank" id="photoviewer_af" href="<?php echo $responseDecalInfo['application_form_path'] ?>"> 
                                                            <img src="<?php echo $responseDecalInfo['application_form_path'] ?>" class="avatar-img rounded"> 
                                                        </a> 
                                                        <a id="remove-af-btn" class="img_rmv btn" style="display: none;">
                                                            <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                        </a> 
                                                    <?php } ?>
                                                </div>
                                            </div>

                                            <?php if($classification == "1"){ ?>
                                            <div id="militaryID">
                                                <div class="form-group">
                                                    <label>Military ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_mf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_mf" style="display: none;">
                                                                <input id="mfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_mf" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_mf">
                                                                <div class="uploaded_mf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_mf_name" id="uploaded_mf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_mb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_mb" style="display: none;">
                                                                <input id="mbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_mb" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_mb">
                                                                <div class="uploaded_mb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_mb_name" id="uploaded_mb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "2"){ ?>
                                            <div id="retirementID">
                                                <div class="form-group">
                                                    <label>Retirement ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_rf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_rf" style="display: none;">
                                                                <input id="rfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_rf" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_rf">
                                                                <div class="uploaded_rf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_rf_name" id="uploaded_rf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_rb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_rb" style="display: none;">
                                                                <input id="rbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_rb" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_rb">
                                                                <div class="uploaded_rb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_rb_name" id="uploaded_rb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "3"){ ?>
                                            <div id="reservistID">
                                                <div class="form-group">
                                                    <label>Reservist ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_resf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_resf" style="display: none;">
                                                                <input id="resfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_resf" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_resf">
                                                                <div class="uploaded_resf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_resf_name" id="uploaded_resf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_resb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_resb" style="display: none;">
                                                                <input id="resbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_resb" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_resb">
                                                                <div class="uploaded_resb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_resb_name" id="uploaded_resb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "4"){ ?>
                                            <div id="chrID">
                                                <div class="form-group">
                                                    <label>CivHR ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_cf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_cf" style="display: none;">
                                                                <input id="cfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_cf" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_cf">
                                                                <div class="uploaded_cf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_cf_name" id="uploaded_cf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_cb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_cb" style="display: none;">
                                                                <input id="cbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_cb" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_cb">
                                                                <div class="uploaded_cb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_cb_name" id="uploaded_cb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "5"){ ?>
                                            <div id="projectfund">
                                                <div class="form-group">
                                                    <label>Service Contract</label>
                                                </div>
                                                <div class="form-group">
                                                    <div id="select_file_pf" style="display: none;">
                                                        <input id="pfupload" type="file" name="id_service_file" accept="image/x-png, image/gif, image/jpeg">
                                                        <div id="progress_pf" class="progress" style="display: none;">
                                                            <div class="progress-bar progress-bar-success"></div>
                                                        </div>
                                                    </div>
                                                    <div id="uploaded_images_pf">
                                                        <div class="uploaded_pf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['service_contract_path'] ?>" name="uploaded_pf_name" id="uploaded_pf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_pf" href="<?php echo $responseDecalInfo['service_contract_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['service_contract_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-pf-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                    </div><br>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "6"){ ?>
                                            <div id="dependentID">
                                                <div class="form-group">
                                                    <label>Dependent ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_df">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_df" style="display: none;">
                                                                <input id="dfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_df" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_df">
                                                                <div class="uploaded_df avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_df_name" id="uploaded_df_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_db">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_db" style="display: none;">
                                                                <input id="dbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_db" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_db">
                                                                <div class="uploaded_db avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_db_name" id="uploaded_db_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "7"){ ?>
                                            <div id="retiredDependent">
                                                <div class="form-group">
                                                    <label>Father/Mother's Retirement ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_drf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_drf" style="display: none;">
                                                                <input id="drfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_drf" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_drf">
                                                                <div class="uploaded_drf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_drf_name" id="uploaded_drf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_drb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_drb" style="display: none;">
                                                                <input id="drbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_drb" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_drb">
                                                                <div class="uploaded_drb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_drb_name" id="uploaded_drb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Birth Certificate</label>
                                                </div>
                                                <div class="form-group">
                                                    <div id="select_file_bc" style="display: none;">
                                                        <input id="bcupload" type="file" name="id_birth_file" accept="image/x-png, image/gif, image/jpeg">
                                                        <div id="progress_bc" class="progress" style="display: none;">
                                                            <div class="progress-bar progress-bar-success"></div>
                                                        </div>
                                                    </div>
                                                    <div id="uploaded_images_bc">
                                                        <div class="uploaded_bc avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['birth_cert_path'] ?>" name="uploaded_bc_name" id="uploaded_bc_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_bc" href="<?php echo $responseDecalInfo['birth_cert_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['birth_cert_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-bc-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                    </div><br>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "8"){ ?>
                                            <div id="concessionaires">
                                                <div class="form-group">
                                                    <label>Driver's License</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_dlf" style="display: none;">
                                                                <input id="dlfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_dlf" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_dlf">
                                                                <div class="uploaded_dlf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_dlf_name" id="uploaded_dlf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_dlb" style="display: none;">
                                                                <input id="dlbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_dlb" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_dlb">
                                                                <div class="uploaded_dlb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_dlb_name" id="uploaded_dlb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                         <?php }else if($classification == "9"){ ?>
                                            <div id="tenant">
                                                <div class="form-group">
                                                    <label>Tenant's Issued ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_tif">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_tif" style="display: none;">
                                                                <input id="tifupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_tif" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_tif">
                                                                <div class="uploaded_tif avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_tif_name" id="uploaded_dlf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_tib">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_tib" style="display: none;">
                                                                <input id="tibupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_tib" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_tib">
                                                                <div class="uploaded_tib avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_tib_name" id="uploaded_tib_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                               
                                            </div>
                                         <?php }else if($classification == "10"){ ?>
                                            <div id="civilian">
                                                <div class="form-group">
                                                    <label>Driver's License</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_dlf"  style="display: none;">
                                                                <input id="dlfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_dlf" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_dlf">
                                                                <div class="uploaded_dlf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_dlf_name" id="uploaded_dlf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_dlb"  style="display: none;">
                                                                <input id="dlbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg">
                                                                    <div id="progress_dlb" class="progress" style="display: none;">
                                                                        <div class="progress-bar progress-bar-success"></div>
                                                                    </div>
                                                                </div>
                                                            <div id="uploaded_images_dlb">
                                                                <div class="uploaded_dlb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_dlb_name" id="uploaded_dlb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn" style="display: none;">
                                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }?>
                                               
                                            <div class="form-group">
                                                <label>Official Receipt</label>
                                            </div> 
                                            <div class="form-group" id="select_file_or" style="display: none;">
                                                <input id="orupload" type="file" name="or_file" accept="image/x-png, image/gif, image/jpeg">
                                                <!-- The global progress bar -->
                                                <br>
                                                <div id="progress_or" class="progress" style="display: none;">
                                                    <div class="progress-bar progress-bar-success"></div>
                                                </div>
                                                <!-- The container for the uploaded files -->
                                                <div id="files_or" class="files"></div>
                                                <input type="text" name="uploaded_or_file_name" id="uploaded_or_file_name" hidden>
                                            </div>
                                            <div id="uploaded_images_or" class="form-group">
                                                <div class="uploaded_or avatar avatar-xxxl"> 
                                                    <input type="text" value="<?php echo $responseDecalInfo['or_path']; ?>" name="uploaded_or_name" id="uploaded_or_name" hidden=""> 
                                                    <?php if(fileExtension($responseDecalInfo['or_path']) == "pdf"){ ?>
                                                        <a href="<?php echo $responseDecalInfo['or_path']; ?>"  target="_blank">
                                                            <img src="/img/pdf_icon.png" class="avatar-img rounded">
                                                        </a> 
                                                        <a id="remove_or" class="img_rmv btn" style="display: none;">
                                                            <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                        </a>
                                                    <?php }else{ ?>
                                                        <a target="_blank" id="photoviewer_or" href="<?php echo $responseDecalInfo['or_path']; ?>">
                                                            <img src="<?php echo $responseDecalInfo['or_path']; ?>" class="avatar-img rounded">
                                                        </a> 
                                                        <a id="remove_or" class="img_rmv btn" style="display: none;">
                                                            <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                        </a>
                                                    <?php } ?>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label>Certificate of Registration</label>
                                            </div> 
                                            <div class="form-group" id="select_file_cr" style="display: none;">
                                                <input id="crupload" type="file" name="cr_file" accept="image/x-png, image/gif, image/jpeg">
                                                <!-- The global progress bar -->
                                                <br>
                                                <div id="progress_cr" class="progress" style="display: none;">
                                                    <div class="progress-bar progress-bar-success"></div>
                                                </div>
                                                <!-- The container for the uploaded files -->
                                                <div id="files_cr" class="files"></div>
                                                <input type="text" name="uploaded_cr_file_name" id="uploaded_cr_file_name" hidden>
                                            </div>
                                            <div id="uploaded_images_cr" class="form-group">
                                                <div class="uploaded_cr avatar avatar-xxxl"> 
                                                    <input type="text" value="<?php echo $responseDecalInfo['cr_path']; ?>" name="uploaded_cr_name" id="uploaded_cr_name" hidden=""> 
                                                    <?php if(fileExtension($responseDecalInfo['cr_path']) == "pdf"){ ?>
                                                        <a href="<?php echo $responseDecalInfo['cr_path']; ?>" target="_blank">
                                                            <img src="/img/pdf_icon.png" class="avatar-img rounded">
                                                        </a> 
                                                        <a id="remove_cr" class="img_rmv btn" style="display: none;">
                                                            <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                        </a>
                                                    <?php }else{ ?>
                                                        <a target="_blank" id="photoviewer_cr" href="<?php echo $responseDecalInfo['cr_path']; ?>">
                                                            <img src="<?php echo $responseDecalInfo['cr_path']; ?>" class="avatar-img rounded">
                                                        </a> 
                                                        <a id="remove_cr" class="img_rmv btn" style="display: none;">
                                                            <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                        </a>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Vehicle Front Picture</label>
                                            </div> 
                                            <div class="form-group" id="select_file_front" style="display: none;">
                                                <input id="frontupload" type="file" name="front_file" accept="image/x-png, image/gif, image/jpeg">
                                                <!-- The global progress bar -->
                                                <br>
                                                <div id="progress_front" class="progress" style="display: none;">
                                                    <div class="progress-bar progress-bar-success"></div>
                                                </div>
                                                <!-- The container for the uploaded files -->
                                                <div id="files_front" class="files"></div>
                                                <input type="text" name="uploaded_front_file_name" id="uploaded_front_file_name" hidden>
                                            </div>
                                            <div id="uploaded_images_front" class="form-group">
                                                <div class="uploaded_front avatar avatar-xxxl"> 
                                                    <input type="text" value="<?php echo $responseDecalInfo['front_path']; ?>" name="uploaded_front_name" id="uploaded_front_name" hidden=""> 
                                                    <a target="_blank" id="photoviewer_front2" href="<?php echo $responseDecalInfo['front_path']; ?>">
                                                        <img src="<?php echo $responseDecalInfo['front_path']; ?>" class="avatar-img rounded">
                                                    </a> 
                                                    <a id="remove_front" class="img_rmv btn" style="display: none;">
                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                    </a> 
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label>Vehicle Rear Picture</label>
                                            </div> 
                                            <div class="form-group" id="select_file_rear" style="display: none;">
                                                <input id="rearupload" type="file" name="rear_file" accept="image/x-png, image/gif, image/jpeg">
                                                <!-- The global progress bar -->
                                                <br>
                                                <div id="progress_rear" class="progress" style="display: none;">
                                                    <div class="progress-bar progress-bar-success"></div>
                                                </div>
                                                <!-- The container for the uploaded files -->
                                                <div id="files_rear" class="files"></div>
                                                <input type="text" name="uploaded_rear_file_name" id="uploaded_rear_file_name" hidden>
                                            </div>
                                            <div id="uploaded_images_rear" class="form-group">
                                                <div class="uploaded_rear avatar avatar-xxxl"> 
                                                    <input type="text" value="<?php echo $responseDecalInfo['rear_path']; ?>" name="uploaded_rear_name" id="uploaded_rear_name" hidden=""> 
                                                    <a target="_blank" id="photoviewer_rear" href="<?php echo $responseDecalInfo['rear_path']; ?>">
                                                        <img src="<?php echo $responseDecalInfo['rear_path']; ?>" class="avatar-img rounded">
                                                    </a> 
                                                    <a id="remove_rear" class="img_rmv btn" style="display: none;">
                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                    </a> 
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Vehicle 2 Sides Pictures</label>
                                            </div> 
                                            <div class="form-group" id="select_file_sides" style="display: none;">
                                                <input id="sidesupload" type="file"  name="sides_file" accept="image/x-png, image/gif, image/jpeg">
                                                <!-- The global progress bar -->
                                                <br>
                                                <div id="progress_sides" class="progress" style="display: none;">
                                                    <div class="progress-bar progress-bar-success"></div>
                                                </div>
                                                <!-- The container for the uploaded files -->
                                                <div id="files_sides" class="files"></div>
                                                <input type="text" name="uploaded_sides_file_name" id="uploaded_sides_file_name" hidden>
                                            </div>
                                            <div id="uploaded_images_sides" class="form-group">
                                                <?php 
                                                if(strpos($responseDecalInfo['sides_path'], ",") !== false ) {
                                                    $sides_path_array = explode (",", $responseDecalInfo['sides_path']);
                                                    $i = 0;
                                                    foreach ($sides_path_array as $sides) { 
                                                    $i++;    ?>
                                                    <div class="uploaded_sides avatar avatar-xxxl"> 
                                                        <input type="text" value="<?php echo $sides; ?>" name="uploaded_sides_name[]" id="uploaded_sides_name[]" hidden=""> 
                                                        <a target="_blank" id="photoviewer_side<?php echo $i;?>" href="<?php echo $sides; ?>">
                                                            <img src="<?php echo $sides; ?>" class="avatar-img rounded">
                                                        </a> 
                                                        <a id="remove_side<?php echo $i; ?>" class="img_rmv btn" style="display: none;">
                                                            <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                        </a> 
                                                    </div>&nbsp; &nbsp;
                                                <?php }
                                                }else{?>
                                                <div class="uploaded_sides avatar avatar-xxxl"> 
                                                    <input type="text" value="<?php echo $responseDecalInfo['sides_path']; ?>" name="uploaded_sides_name[]" id="uploaded_sides_name[]" hidden=""> 
                                                    <a target="_blank" id="photoviewer_side1" href="<?php echo $responseDecalInfo['sides_path']; ?>">
                                                        <img src="<?php echo $responseDecalInfo['sides_path']; ?>" class="avatar-img rounded">
                                                    </a> 
                                                    <a class="img_rmv btn">
                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                    </a> 
                                                </div>
                                                <?php }?>
                                                
                                            </div>
                                            <?php if($resVehicleInfo["is_owner"] == "0"){ ?>
                                            <div class="form-group">
                                                <label>Other Supporting Documents</label>
                                            </div> 
                                            <div class="form-group" id="select_file_support" style="display: none;">
                                                <input id="supportupload" type="file" name="support_file" accept="image/x-png, image/gif, image/jpeg">
                                                <!-- The global progress bar -->
                                                <br>
                                                <div id="progress_support" class="progress" style="display: none;">
                                                    <div class="progress-bar progress-bar-success"></div>
                                                </div>
                                                <!-- The container for the uploaded files -->
                                                <div id="files_support" class="files"></div>
                                                <input type="text" name="uploaded_support_file_name[]" id="uploaded_support_file_name[]" hidden>
                                            </div>
                                            <div id="uploaded_images_support" class="form-group">
                                            <?php 
                                                if(strpos($responseDecalInfo['support_path'], ",") !== false ) {
                                                    $support_path_array = explode (",", $responseDecalInfo['support_path']);
                                                    $i = 0;
                                                    foreach ($support_path_array as $support) { 
                                                    $i++; ?>
                                                    <div class="uploaded_sides avatar avatar-xxxl"> 
                                                        <input type="text" value="<?php echo $support; ?>" name="uploaded_support_name[]" id="uploaded_support_name[]" hidden=""> 
                                                        <?php if(fileExtension($support) == "pdf"){ ?> 
                                                            <a href="<?php echo $support; ?>"  target="_blank">
                                                                <img src="/img/pdf_icon.png" class="avatar-img rounded">
                                                            </a> 
                                                            <a id="remove_support<?php echo $i ?>" class="img_rmv btn" style="display:none">
                                                                <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                            </a>
                                                        <?php }else{ ?>
                                                            <a target="_blank" id="photoviewer_support<?php echo $i ?>" href="<?php echo $support; ?>">
                                                                <img src="<?php echo $support; ?>" class="avatar-img rounded">
                                                            </a> 
                                                            <a id="remove_support<?php echo $i ?>" class="img_rmv btn" style="display:none">
                                                                <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                            </a>
                                                        <?php } ?>
                                                    </div>&nbsp; &nbsp;
                                                <?php }
                                                }else{?>
                                                <div class="uploaded_sides avatar avatar-xxxl"> 
                                                    <input type="text" value="<?php echo $responseDecalInfo['support_path']; ?>" name="uploaded_support_name[]" id="uploaded_support_name[]" hidden=""> 
                                                    <?php if(fileExtension($responseDecalInfo['support_path']) == "pdf"){ ?> 
                                                        <a href="<?php echo $responseDecalInfo['support_path']; ?>" target="_blank" >
                                                            <img src="/img/pdf_icon.png" class="avatar-img rounded">
                                                        </a> 
                                                        <a id="remove_support1" class="img_rmv btn" style="display:none">
                                                            <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                        </a>
                                                    <?php }else{ ?>
                                                        <a target="_blank" id="photoviewer_support1" href="<?php echo $responseDecalInfo['support_path']; ?>">
                                                            <img src="<?php echo $responseDecalInfo['support_path']; ?>" class="avatar-img rounded">
                                                        </a> 
                                                        <a id="remove_support1" class="img_rmv btn" style="display:none">
                                                            <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                        </a>
                                                    <?php } ?>
                                                </div>
                                                <?php }?>
                                            </div>
                                            <?php } ?>
                                            
                                            <br>
                                            <br>
                                            <div class="card-action">
                                                <div class="d-flex justify-content-center">
                                                    <?php if($response["user_role"] == "1"){ ?>
                                                        <?php if($status == "1"){ ?>
                                                            <button type="button" id="revoke-btn" data-app-id="<?php echo $responseDecalInfo['application_id']; ?>"  data-toggle="modal" data-target="#revokeModal" class="btn btn-danger btn-round pr-5 pl-5 ml-1 mr-1">
                                                                <i class="icon-ban"></i>    
                                                                <b>Revoke Approved Request</b>
                                                            </button>
                                                            
                                                        <?php }else if($status == "2"){ ?>
                                                            
                                                        <?php }else{ ?>
                                                            <?php if(!$responseDecalInfo["has_deficiency"]){ ?>
                                                            <button id="approve-btn" class="btn btn-success btn-round pr-5 pl-5 ml-1 mr-1" >
                                                                <i class="fas fa-thumbs-up"></i>    
                                                                <b>Approve Request</b>
                                                            </button>
                                                            <button type="button" id="deficiency-btn" data-app-id="<?php echo $responseDecalInfo['application_id']; ?>"  data-toggle="modal" data-target="#deficiencyModal" id="deficiency-btn" class="btn btn-warning btn-round pr-5 pl-5 ml-1 mr-1">
                                                                <i class="fas fa-thumbs-down"></i>    
                                                                <b>Has Deficiency</b>
                                                                </button>
                                                                <button type="button" id="reject-btn" data-app-id="<?php echo $responseDecalInfo['application_id']; ?>"  data-toggle="modal" data-target="#rejectModal"  class="btn btn-danger btn-round pr-5 pl-5 ml-1 mr-1">
                                                                <i class="icon-ban"></i>    
                                                                <b>Reject Request</b>
                                                            </button>
                                                            <?php } } ?>
                                                    <?php
                                                    }else if($response["user_role"] == "4" || $response["user_role"] == "3" || $response["user_role"] == "2"){
                                                    if($status == "0") {?>
                                                    <?php if(!$responseDecalInfo["has_deficiency"]){ ?>
                                                        <button id="endorse-btn" class="btn btn-success btn-round pr-5 pl-5 ml-1 mr-1" >
                                                            <i class="icon-rocket"></i>    
                                                            <b>Endorse Request</b>
                                                        </button>
                                                        <button type="button" id="deficiency-btn" data-app-id="<?php echo $responseDecalInfo['application_id']; ?>"  data-toggle="modal" data-target="#deficiencyModal" class="btn btn-warning btn-round pr-5 pl-5 ml-1 mr-1">
                                                            <i class="fas fa-thumbs-down"></i>    
                                                            <b>Has Deficiency</b>
                                                        </button>
                                                        <button type="button" id="reject-btn" data-app-id="<?php echo $responseDecalInfo['application_id']; ?>"  data-toggle="modal" data-target="#rejectModal"  class="btn btn-danger btn-round pr-5 pl-5 ml-1 mr-1">
                                                            <i class="icon-ban"></i>    
                                                            <b>Reject Request</b>
                                                        </button>
                                                    <?php } ?>
                                                    <?php } ?>
                                                    <?php } ?>
                                                    <?php if($response["user_role"] == "4") { ?>
                                                        <?php if(!$responseDecalInfo["is_claimed"] && $responseDecalInfo["status"] == "1"){ ?>
                                                            <button type="button" id="claim-btn" data-app-id="<?php echo $responseDecalInfo['application_id']; ?>"  data-toggle="modal" data-target="#claimModal" class="btn btn-primary btn-round pr-5 pl-5 ml-1 mr-1">
                                                                <b>Claim Decal</b>
                                                            </button>
                                                        <?php } ?>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                        <!----- START TIMELINE MODAL ------>
                                       <div class="modal fade" id="timelineModal" role="dialog" aria-hidden="true">
                                            <div class="modal-dialog" style="max-width: 750px" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header no-bd">
                                                        <h3 class="modal-title" style="color:black; font-weight:700;">
                                                            Timeline
                                                        </h3>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <ul class="timeline">
                                                                        <?php $responseTimeline = getTimeline($mysqli, $aid);
                                                                            while($u = mysqli_fetch_array($responseTimeline)) { 
                                                                                if($u["what_type"] == "0"){
                                                                                    $timeline = "";
                                                                                    $title = "Decal request submitted";
                                                                                    $icon_color = "warning";
                                                                                    $icon  = "flaticon-message";
                                                                                }else if($u["what_type"] == "1"){
                                                                                    $timeline = "timeline-inverted";
                                                                                    $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                                                    $role = $responseAdmin["user_role"];
                                                                                    $toRole = $role - 1;
                                                                                    $title = "Endorsed by ".$responseAdmin['account_name']." to ".getRoleName($mysqli, $toRole)["name"];
                                                                                    $icon_color = "primary";
                                                                                    $icon  = "icon-rocket";
                                                                                }else if($u["what_type"] == "2"){
                                                                                    $timeline = "timeline-inverted";
                                                                                    $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                                                    $responseDecal = getDecalInformation($mysqli, $u["application_id"]);
                                                                                    $role = $responseAdmin["user_role"];
                                                                                    $forwardedTo = $role + 3;
                                                                                    $title = "Approved by ".$responseAdmin["account_name"]." and forwarded to ".getSioName($mysqli, $responseDecal["sio_id"])["sio_name"]." for printing and releasing.";
                                                                                    $icon_color = "success";
                                                                                    $icon  = "icon-like";
                                                                                }else if($u["what_type"] == "3"){
                                                                                    $timeline = "";
                                                                                    $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                                                    $role = $responseAdmin["user_role"];
                                                                                    $responseDecal = getDecalInformation($mysqli, $u["application_id"]);
                                                                                    $title = "Decal already claimed by ".$responseDecal["claimed_by"];
                                                                                    $icon_color = "success";
                                                                                    $icon  = "flaticon-list";
                                                                                }else if($u["what_type"] == "4"){
                                                                                    $timeline = "timeline-inverted";
                                                                                    $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                                                    $role = $responseAdmin["user_role"];
                                                                                    $title = "Request still Pending due to some deficiency. <br>
                                                                                    Check by: ". getRoleName($mysqli, $role)["name"];
                                                                                    $icon_color = "warning";
                                                                                    $icon  = "icon-dislike";
                                                                                }else if($u["what_type"] == "5"){
                                                                                    $timeline = "timeline-inverted";
                                                                                    $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                                                    $role = $responseAdmin["user_role"];
                                                                                    $title = "Request rejected by ". getRoleName($mysqli, $role)["name"]."(".$responseAdmin["account_name"].")";
                                                                                    $icon_color = "danger";
                                                                                    $icon  = "icon-ban";
                                                                                }else if($u["what_type"] == "6"){
                                                                                    $timeline = "timeline-inverted";
                                                                                    $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                                                    $role = $responseAdmin["user_role"];
                                                                                    $title = "Your Decal is revoke by ". getRoleName($mysqli, $role)["name"]."(".$responseAdmin["account_name"].")";
                                                                                    $icon_color = "danger";
                                                                                    $icon  = "icon-ban";
                                                                                }
                                                                                
                                                                                ?>
                                                                                <li class="<?php echo $timeline ?>">
                                                                                    <div class="timeline-badge <?php echo $icon_color ?>"><i class="<?php echo $icon ?>"></i></div>
                                                                                    <div class="timeline-panel">
                                                                                        <div class="timeline-heading">
                                                                                            <h5 class="timeline-title"><?php echo $title ?></h5>
                                                                                            <p><small class="text-muted"></i><?php echo $u["what_time"] ?></small></p>
                                                                                        </div>
                                                                                    </div>
                                                                                </li>
                                                                        <?php } ?>
                                                                    
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer no-bd">
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!----- END TIMELINE MODAL ------>

                                        <!----- START CLAIM MODAL ------>
                                        <div class="modal fade" id="claimModal" role="dialog" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header no-bd">
                                                        <h3 class="modal-title" style="color:black;">
                                                            Claim Decal
                                                        </h3>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                        <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label>Decal No.</label>
                                                                            <input type="hidden" name="token_claim" id="token_claim" value="<?php echo $_SESSION["token"]?>"/>
                                                                            <input type="hidden" name="id_claim" id="id_claim" value="<?php echo $aid ?>"/>
                                                                            <input id="decalNumber" name="decalNumber" type="text" class="form-control" placeholder="Enter Decal No." required>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label>Name</label>
                                                                            <input id="claimantsName" name="claimantsName" type="text" class="form-control" placeholder="Enter Claimant's Name" required>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label>Decal Category</label>
                                                                            <select id="category" name="category" class="form-control" required>
                                                                                <option value="A-4W">A-4W</option>
                                                                                <option value="B-4W">B-4W</option>
                                                                                <option value="B-4WP">B-4WP</option>
                                                                                <option value="C-4W">C-4W</option>
                                                                                <option value="A-2W">A-2W</option>
                                                                                <option value="B-2W">B-2W</option>
                                                                                <option value="C-2W">C-2W</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer no-bd">
                                                            <button type="button" id="claimDecal" class="btn btn-primary">Claim</button>
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!----- END CLAIM MODAL ------>


                                        <!----- START DEFICIENCY MODAL ------>
                                        <div class="modal fade" id="deficiencyModal" role="dialog" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header no-bd">
                                                        <h3 class="modal-title" style="color:black; font-weight:700;">
                                                        Remarks for Deficiency
                                                        </h3>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                        <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <input type="hidden" name="id_remarks" id="id_remarks" value="<?php echo $aid ?>"/>
                                                                            <textarea id="remarks" name="remarks" type="text" class="form-control" placeholder="Enter Remarks for Deficiency" required></textarea>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer no-bd">
                                                            <button type="button" id="deficiency" class="btn btn-primary">Add Remarks</button>
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!----- END DEFICIENCY MODAL ------>
                                        <!----- START REJECT MODAL ------>
                                        <div class="modal fade" id="rejectModal" role="dialog" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header no-bd">
                                                        <h3 class="modal-title" style="color:black; font-weight:700;">
                                                            Remarks for Rejection
                                                        </h3>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                        <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <input type="hidden" name="token_reject" id="token_reject" value="<?php echo $_SESSION["token"]?>"/>
                                                                            <input type="hidden" name="id_reject" id="id_reject" value="<?php echo $aid ?>"/>
                                                                            <textarea id="remarks_reject" name="remarks_reject" type="text" class="form-control" placeholder="Enter Remarks for Rejection" required></textarea>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer no-bd">
                                                            <button type="button" id="reject" class="btn btn-primary">Reject</button>
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!----- END REJECT MODAL ------>
                                        <!----- START REVOKE MODAL ------>
                                        <div class="modal fade" id="revokeModal" role="dialog" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header no-bd">
                                                        <h3 class="modal-title" style="color:black; font-weight:700;">
                                                            Remarks for Revocation
                                                        </h3>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                        <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label>Remarks for Revoation</label>
                                                                            <input type="hidden" name="token_revoke" id="token_revoke" value="<?php echo $_SESSION["token"]?>"/>
                                                                            <input type="hidden" name="id_revoke" id="id_revoke" value="<?php echo $aid ?>"/>
                                                                            <textarea id="remarks_revoke" name="remarks_revoke" type="text" class="form-control" placeholder="Enter Remarks for Revocation" required></textarea>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer no-bd">
                                                            <button type="button" id="revoke" class="btn btn-primary">Revoke</button>
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!----- END REVOKE MODAL ------>
                                    </div>
                                </div>
                            </div>
						</div>
					</div>
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
					<div class="copyright ml-auto">
						<?php include "includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
        </div>
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
    <script src="../dist/js/iziToast.min.js"></script>

    <script src="../js/upload.js"></script>
    <script>
        $(document).ready(function(){
            var gallery = $('#photoviewer_or').simpleLightbox();
         });
         $(document).ready(function(){
            var gallery = $('#photoviewer_cr').simpleLightbox();
         });
         $(document).ready(function(){
            var gallery = $('#photoviewer_front').simpleLightbox();
         });
         $(document).ready(function(){
            var gallery = $('#photoviewer_rear').simpleLightbox();
         });
         $(document).ready(function(){
            var gallery = $('#photoviewer_side1').simpleLightbox();
         });
         $(document).ready(function(){
            var gallery = $('#photoviewer_side2').simpleLightbox();
         });
         $(document).ready(function(){
            var gallery = $('#photoviewer_support1').simpleLightbox();
         });
         $(document).ready(function(){
            var gallery = $('#photoviewer_support2').simpleLightbox();
         });
         
         $(document).ready(function(){
            var gallery = $('#photoviewer_front2').simpleLightbox();
         });

         $(document).ready(function(){
            var gallery = $('#photoviewer_back').simpleLightbox();
         });

         $(document).ready(function(){
            var gallery = $('#photoviewer_pf').simpleLightbox();
         });
         $(document).ready(function(){
            var gallery = $('#photoviewer_bc').simpleLightbox();
         });

         $(document).ready(function(){
            var gallery = $('#photoviewer_af').simpleLightbox();
         });
       
     $(document).ready(function(){
        var gallery = $('#photoviewer').simpleLightbox();
     });
    var active = document.getElementById("active");
    var retired = document.getElementById("retired");
    var chr = document.getElementById("chr");
    var chrid = document.getElementById("chrid");
    var dep_a = document.getElementById("dependent_active");
    var dep_r = document.getElementById("dependent_retired");
    var others = document.getElementById("others");

    var reservist_sn = document.getElementById("reservist_sn");


    var value = "<?php echo $responseAccount['classification'] ?>";

            if(value == "1"){
                active.style.display = "";
                retired.style.display = "none";
                chr.style.display = "none";
                dep_a.style.display = "none";
                dep_r.style.display = "none";
                others.style.display = "none";
                reservist.style.display= "none";
            }else  if(value == "2"){
                active.style.display = "none";
                retired.style.display = "";
                reservist.style.display= "none";
                chr.style.display = "none";
                dep_a.style.display = "none";
                dep_r.style.display = "none";
                others.style.display = "none";
            }else  if(value == "3"){
                active.style.display = "none";
                retired.style.display = "none";
                reservist.style.display= "";
                chr.style.display = "none";
                dep_a.style.display = "none";
                dep_r.style.display = "none";
                others.style.display = "none";
            }else  if(value == "4"){
                active.style.display = "none";
                retired.style.display = "none";
                chr.style.display = "";
                chrid.style.display = "";
                dep_a.style.display = "none";
                dep_r.style.display = "none";
                others.style.display = "none";
                reservist.style.display= "none";
            }else  if(value == "5"){
                active.style.display = "none";
                retired.style.display = "none";
                chr.style.display = "";
                chrid.style.display = "none";
                dep_a.style.display = "none";
                dep_r.style.display = "none";
                others.style.display = "none";
                reservist.style.display= "none";
            }else  if(value == "6"){
                active.style.display = "none";
                retired.style.display = "none";
                chr.style.display = "none";
                dep_a.style.display = "";
                dep_r.style.display = "none";
                others.style.display = "none";
                reservist.style.display= "none";
            }else  if(value == "7"){
                active.style.display = "none";
                retired.style.display = "none";
                chr.style.display = "none";
                dep_a.style.display = "none";
                dep_r.style.display = "";
                others.style.display = "none";
                reservist.style.display= "none";
            }else{
                active.style.display = "none";
                retired.style.display = "none";
                chr.style.display = "none";
                dep_a.style.display = "none";
                dep_r.style.display = "none";
                others.style.display = "";
                reservist.style.display= "none";
            }

    

  function displayNotification(title1, msg, state, icon){
        if(state == 'success'){
            iziToast.success({title: title1, message: msg, onClosing: function () {},});
        }else{
            iziToast.error({title: title1, message: msg, onClosing: function () {},});
        }
       
       return;
    }

    $("#claimDecal").click(function () {
        if($.trim($("#decalNumber").val()) === ""){
            displayNotification("Error", "Please enter Decal Number!", "danger");
            return false;
        }
        if($.trim($("#claimantsName").val()) === ""){
            displayNotification("Error", "Please enter Claimant's Name!", "danger");
            return false;
        }
        var id = $("#id_claim").val();
        var claimants = $("#claimantsName").val();
        var decal_number =  $("#decalNumber").val();
        var token =  $("#token_claim").val();
        var category =  $("#category").val();
        $("#claimModal").modal('hide');
        $.ajax({
        	type: "POST",
        	url: "claim.decal.php",
        	data: { 'id': id, 'claimants_name': claimants, 'decal_number': decal_number, 'category': category, 'token': token },
			dataType : 'json',
        	cache: false,
        	success: function(response) {
				swal({
                    title: "Good job!",
                        text: "You have succefully update the records.",
                        icon: "success",
                        closeOnClickOutside: false,
                        buttons: {
                            confirm2: {
                                text: "Ok",
                                value: true,
                                visible: true,
                                className: "btn btn-success",
                                closeModal: true
                            }
                        }
                     }).then(confirm2 => {
                        if(confirm2){
                             window.location='view-request.php?id='+id+'&from=<?php echo base64_encode('claimed.php') ?>' 
                        }
                    });
        			},
        		failure: function (response) {
            		swal("Internal Error","Oops, something went wrong.", "error")
       			}
    		});
    });


    $("#deficiency").click(function () {
        if($.trim($("#remarks").val()) === ""){
            displayNotification("Error", "Please enter Deficiency Remarks!", "danger");
            return false;
        }
        var remarks =  $("#remarks").val();
        var id =  $("#id_remarks").val();
        $("#deficiencyModal").modal('hide')
        $.ajax({
        	type: "POST",
        	url: "add.deficiency.remarks.php",
        	data: { 'id': id, 'remarks': remarks },
			dataType : 'json',
        	cache: false,
        	success: function(response) {
                if(!response.error){
                    swal({
                    title: "Good job!",
                    text: "You have succefully add a deficiency remarks.",
                    icon: "success",
                    closeOnClickOutside: false,
                    buttons: {
                        confirm2: {
                                text: "Ok",
                                value: true,
                                visible: true,
                                className: "btn btn-success",
                                closeModal: true
                            }
                        }
                    }).then(confirm2 => {
                        if(confirm2){
                            window.location='pending' 
                        }
                    });
                }else{
                    swal("Internal Error","Oops, something went wrong.", "error")
                }
				
        	},
        	failure: function (response) {
            	swal("Internal Error","Oops, something went wrong.", "error")
       		}
    	});
    });
    


    $("#reject").click(function () {
        if($.trim($("#remarks_reject").val()) === ""){
            displayNotification("Error", "Please enter Reject Remarks!", "danger");
            return false;
        }
        var remarks =  $("#remarks_reject").val();
        var id =  $("#id_reject").val();
        $("#rejectModal").modal('hide')
        $.ajax({
        	type: "POST",
        	url: "add.rejected.remarks.php",
        	data: { 'id': id, 'remarks': remarks },
			dataType : 'json',
        	cache: false,
        	success: function(response) {
                if(!response.error){
                    swal({
                    title: "Good job!",
                    text: "You have succefully add a reject remarks.",
                    icon: "success",
                    closeOnClickOutside: false,
                    buttons: {
                        confirm2: {
                            text: "Ok",
                            value: true,
                            visible: true,
                            className: "btn btn-success",
                            closeModal: true
                        }
                    }
                }).then(confirm2 => {
                    if(confirm2){
                         window.location='rejected' 
                    }
                });
                }else{
                    swal("Internal Error","Oops, something went wrong.", "error")
                }
        	},
        	failure: function (response) {
            	swal("Internal Error","Oops, something went wrong.", "error")
       		}
    	});
    });
    
    <?php if($response["user_role"] == "4" || $response["user_role"] == "3" || $response["user_role"] == "2") {?>
    $('#endorse-btn').click(function(e) {
					swal({
						title: 'Are you sure?',
						text: "Review the request before you proceed? If you have already reviewed the request and no deficiency, please click Endorse.",
						type: 'warning',
						buttons:{
							confirm: {
								text : 'Endorse Request',
								className : 'btn btn-success'
							},
							cancel: {
								visible: true,
								className: 'btn btn-danger',
                                text : 'Review Again'
							}
						}
					}).then((confirm) => {
						if (confirm) {
                            $.ajax({
        						type: "POST",
        						url: "endorsed.request.php",
        						data: { 'id': '<?php echo $aid ?>'},
								dataType : 'json',
        						cache: false,
        						success: function(response) {
                                    if(!response.error){
                                        swal({
                                        title: "Good job!",
                                        text: "You have succefully endorsed the request",
                                        icon: "success",
                                        closeOnClickOutside: false,
                                        buttons: {
                                            confirm2: {
                                                text: "Ok",
                                                value: true,
                                                visible: true,
                                                className: "btn btn-success",
                                                closeModal: true
                                            }
                                        }
                                        }).then(confirm2 => {
                                            if(confirm2){
                                                window.location='pending' 
                                            }
                                        })
                                    }else{
                                        swal("Internal Error","Oops, something went wrong.", "error")
                                    }
        						},
        						failure: function (response) {
            						swal("Internal Error","Oops, something went wrong.", "error")
       							}
    						})
						} else {
							swal.close();
						}
					});
				});

        <?php } if($response["user_role"] == "1") {?>
                $('#approve-btn').click(function(e) {
					swal({
						title: 'Are you sure?',
						text: "Review the request before you proceed? If you have already reviewed the request and no deficiency, please click Approve Request.",
						type: 'warning',
						buttons:{
							confirm: {
								text : 'Approve Request',
								className : 'btn btn-success'
							},
							cancel: {
								visible: true,
								className: 'btn btn-danger',
                                text : 'Review Again'
							}
						}
					}).then((confirm) => {
						if (confirm) {
                            $.ajax({
        						type: "POST",
        						url: "approved.request.php",
        						data: { 'id': '<?php echo $aid ?>'},
								dataType : 'json',
        						cache: false,
        						success: function(response) {
                                    if(!response.error){
                                        swal({
                                        title: "Good job!",
                                        text: "You have succefully approved the request",
                                        icon: "success",
                                        closeOnClickOutside: false,
                                        buttons: {
                                                confirm2: {
                                                    text: "Ok",
                                                    value: true,
                                                    visible: true,
                                                    className: "btn btn-success",
                                                    closeModal: true
                                                }
                                        }
                                        }).then(confirm2 => {
                                            if(confirm2){
                                                window.location='approved' 
                                            }
                                        });
                                    }else{
                                        swal("Internal Error","Oops, something went wrong.", "error")
                                    }
        						},
        						failure: function (response) {
            						swal("Internal Error","Oops, something went wrong.", "error")
       							}
    						});
						} else {
							swal.close();
						}
					});
				});



                $('#revoke').click(function(e) {
                    if($.trim($("#remarks_revoke").val()) === ""){
                        displayNotification("Error", "Please enter Revocation Remarks!", "danger");
                        return false;
                    }
                    var remarks =  $("#remarks_revoke").val();
                    var id =  $("#id_revoke").val();
                    $("#revokeModal").modal('hide')
                    $.ajax({
                        type: "POST",
                        url: "revoke.approved.request.php",
                        data: { 'id': id, 'remarks': remarks },
                        dataType : 'json',
                        cache: false,
                        success: function(response) {
                            if(!response.error){
                                swal({
                                title: "Good job!",
                                text: "You have succefully revoked decal request.",
                                icon: "success",
                                closeOnClickOutside: false,
                                buttons: {
                                    confirm2: {
                                        text: "Ok",
                                        value: true,
                                        visible: true,
                                        className: "btn btn-success",
                                        closeModal: true
                                    }
                                }
                                }).then(confirm2 => {
                                    if(confirm2){
                                        window.location='rejected' 
                                    }
                                });
                            }else{
                                swal("Internal Error","Oops, something went wrong.", "error")
                            }
                        },
                        failure: function (response) {
                            swal("Internal Error","Oops, something went wrong.", "error")
                        }
                    });
				});
    <?php } ?>
</script>
<script>
<?php
    if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
        $state 	= $_SESSION["state"];
        $msg 	= $_SESSION["msg"];
        $title 	= $_SESSION["title"];

        if($state == "success"){
            $icon = "fas fa-check";
        }else if($state == "warning"){
            $icon = "fas fa-exclamation-circle";
        }else if($state == "danger"){
            $icon = "fas fa-exclamation-triangle";
        }?>
            displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>", "<?php echo $icon; ?>");
<?php } ?>
</script>

<?php
    unset($_SESSION["state"]);
    unset($_SESSION["msg"]);
    unset($_SESSION["title"]);
?>
<script src="../js/search.js"></script>
</body>
</html>