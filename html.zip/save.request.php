<?php
include_once 'includes/csrf.php';
session_start();
if(!isset($_COOKIE['user_c']) && !isset($_SESSION['email'])){
    header('Location: login');
}
include_once 'includes/config.php';
include_once 'includes/functions.php';
include_once 'includes/constant.php';
$csrf = new CSRF(
    'session-hashes', 
    'csrftoken',       
    5*60,
    256
  );
if(MAINTENANCE == "1"){
	header("Location: maintenance");
	return;
}
$mysqli = db_connect($config);
$email = mysqli_real_escape_string($mysqli,$_SESSION["email"]);
$response =  loginAccount($mysqli, $email);
if ($csrf->validate('apply')) {
//PERSONAL DATA
    if(!$response['error']){
        $userid     = $response['id'];
        //VEHICLE DATA
        $year_model         = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['year_model'], ENT_QUOTES, 'UTF-8'));
        $plate_number       = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['plate_number'], ENT_QUOTES, 'UTF-8'));
        $vehicle_color      = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['vehicle_color'], ENT_QUOTES, 'UTF-8'));
        $vehicle_model      = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['vehicle_model'], ENT_QUOTES, 'UTF-8'));
        $chassis_number     = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['chassis_number'], ENT_QUOTES, 'UTF-8'));
        $vehicle_maker      = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['vehicle_maker'], ENT_QUOTES, 'UTF-8'));
        $motor_number       = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['motor_number'], ENT_QUOTES, 'UTF-8'));
        $owner              = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['owner'], ENT_QUOTES, 'UTF-8'));
        $sio_id             = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['sio'], ENT_QUOTES, 'UTF-8'));

        $uploaded_or_name             = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['uploaded_or_name'], ENT_QUOTES, 'UTF-8'));
        $uploaded_cr_name             = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['uploaded_cr_name'], ENT_QUOTES, 'UTF-8'));
        $uploaded_front_name          = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['uploaded_front_name'], ENT_QUOTES, 'UTF-8'));
        $uploaded_rear_name           = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['uploaded_rear_name'], ENT_QUOTES, 'UTF-8'));
        $uploaded_af_name             = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['uploaded_af_name'], ENT_QUOTES, 'UTF-8'));
        $uploaded_sides_name          = $_POST['uploaded_sides_name'];
        $uploaded_support_name        = $_POST['uploaded_support_name'];
        $uploaded_side_list           = implode(",", $uploaded_sides_name);
        if($owner=="1"){
            $uploaded_support_name = "";
        }else{
            if($uploaded_support_name != ""){
                $uploaded_support_list    = implode(",", $uploaded_support_name);
            }
        }
        $uploaded_support_list        = htmlspecialchars($uploaded_support_list, ENT_QUOTES, 'UTF-8');

        $classification = $response["classification"];
        if($classification == "1"){
            $frontid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_mf_name'], ENT_QUOTES, 'UTF-8'));
            $backid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_mb_name'], ENT_QUOTES, 'UTF-8'));
            $birthcert = "";
            $contract = "";
            $endorse_by = "";
            $endorser_phone = "";
            $decal_type = "";
        }else if($classification == "2"){
            $frontid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_rf_name'], ENT_QUOTES, 'UTF-8'));
            $backid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_rb_name'], ENT_QUOTES, 'UTF-8'));
            $birthcert = "";
            $contract = "";
            $endorse_by = "";
            $endorser_phone = "";
            $decal_type = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['decal_type'], ENT_QUOTES, 'UTF-8'));
        }else if($classification == "3"){
            $frontid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_resf_name'], ENT_QUOTES, 'UTF-8'));
            $backid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_resb_name'], ENT_QUOTES, 'UTF-8'));
            $birthcert = "";
            $contract = "";
            $endorse_by = "";
            $endorser_phone = "";
            $decal_type = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['decal_type'], ENT_QUOTES, 'UTF-8'));
        }else if($classification == "4"){
            $frontid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_cf_name'], ENT_QUOTES, 'UTF-8'));
            $backid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_cb_name'], ENT_QUOTES, 'UTF-8'));
            $birthcert = "";
            $contract = "";
            $endorse_by = "";
            $endorser_phone = "";
            $decal_type = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['decal_type'], ENT_QUOTES, 'UTF-8'));
        }else if($classification == "5"){
            $frontid = "";
            $backid = "";
            $birthcert = "";
            $contract = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_pf_name'], ENT_QUOTES, 'UTF-8'));;
            $endorse_by = "";
            $endorser_phone = "";
            $decal_type = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['decal_type'], ENT_QUOTES, 'UTF-8'));
        }else if($classification == "6"){
            $frontid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_df_name'], ENT_QUOTES, 'UTF-8'));
            $backid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_db_name'], ENT_QUOTES, 'UTF-8'));
            $birthcert = "";
            $contract = "";
            $endorse_by = "";
            $endorser_phone = "";
            $decal_type = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['decal_type'], ENT_QUOTES, 'UTF-8'));
        }else if($classification == "7"){
            $frontid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_drf_name'], ENT_QUOTES, 'UTF-8'));
            $backid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_drb_name'], ENT_QUOTES, 'UTF-8'));
            $birthcert = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_bc_name'], ENT_QUOTES, 'UTF-8'));
            $contract = "";
            $endorse_by = "";
            $endorser_phone = "";
            $decal_type = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['decal_type'], ENT_QUOTES, 'UTF-8'));
        }else if($classification == "8"){
            $frontid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_dlf_name'], ENT_QUOTES, 'UTF-8'));
            $backid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_dlb_name'], ENT_QUOTES, 'UTF-8'));
            $birthcert = "";
            $contract = "";
            $endorse_by = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['endorse_by'], ENT_QUOTES, 'UTF-8'));
            $endorser_phone = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['endorser_phone'], ENT_QUOTES, 'UTF-8'));
            $decal_type = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['decal_type'], ENT_QUOTES, 'UTF-8'));
        }else if($classification == "9"){
            $frontid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_tif_name'], ENT_QUOTES, 'UTF-8'));
            $backid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_tib_name'], ENT_QUOTES, 'UTF-8'));
            $birthcert = "";
            $contract = "";
            $endorse_by = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['endorse_by'], ENT_QUOTES, 'UTF-8'));
            $endorser_phone = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['endorser_phone'], ENT_QUOTES, 'UTF-8'));
            $decal_type = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['decal_type'], ENT_QUOTES, 'UTF-8'));
        }else if($classification == "10"){
            $frontid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_dlf_name'], ENT_QUOTES, 'UTF-8'));
            $backid = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['uploaded_dlb_name'], ENT_QUOTES, 'UTF-8'));
            $birthcert = "";
            $contract = "";
            $endorse_by = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['endorse_by'], ENT_QUOTES, 'UTF-8'));
            $endorser_phone = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['endorser_phone'], ENT_QUOTES, 'UTF-8'));
            $decal_type = mysqli_real_escape_string($mysqli,  htmlspecialchars($_POST['decal_type'], ENT_QUOTES, 'UTF-8'));
        }



        $responsePlate = getVehicleInformationByPlate($mysqli, $plate_number);
        if(!isVehicleExist($mysqli, $responsePlate["id"])){
            $responseVehicle = addVehicleInformation($mysqli, $vehicle_model, $year_model, $vehicle_color, $plate_number,  $chassis_number, $vehicle_maker, $motor_number, $owner);
                if(!$responseVehicle["error"]){
                    $vehicle_id  = $responseVehicle['vehicle_id'];
                    $responseDecal = addDecalApplication($mysqli, $userid, $sio_id, $vehicle_id, $uploaded_or_name, $uploaded_cr_name, $uploaded_front_name, $uploaded_rear_name, $uploaded_side_list, $uploaded_support_list, $frontid, $backid, $birthcert, $contract, $endorse_by, $endorser_phone, $uploaded_af_name, $decal_type);
                    if(!$responseDecal["error"]){
                        $ipaddress = getPublicIP();
                        $responseLogs = addLogs($mysqli, $userid, "apply decal", "", $ipaddress, "0");
                        addTimeLine($mysqli, $responseDecal["appid"], "0", "0", "0", "4");
                        if(!$responseLogs["error"]){
                            $_SESSION["state"]  = "success";
                            $_SESSION["title"]  = "Success";
                            $_SESSION["msg"]    = "You have successfully create an application, Please wait for the email approval of your application.";
                            header("Location: pending");
                        }else{
                            $_SESSION["state"]  = "success";
                            $_SESSION["title"]  = "Success";
                            $_SESSION["msg"]    = "You have successfully create an application, Please wait for the email approval of your application.";
                            header("Location: pending");
                        }
                    }else{
                        $_SESSION["state"]  = "danger";
                        $_SESSION["title"]  = "Error";
                        $_SESSION["msg"]    = "Problem occured while saving data...";
                        header("Location: apply");
                    }
                }else{
                    $_SESSION["state"]  = "danger";
                    $_SESSION["title"]  = "Error";
                    $_SESSION["msg"]    = "Problem occured while saving data...";
                    header("Location: apply");
            }
        }else{
            $_SESSION["state"]  = "danger";
            $_SESSION["title"]  = "Error";
            $_SESSION["msg"]    = "There is already a pending application for the plate number, please see the pending section.";
            header("Location: apply");
        }
    }else{
        header('Location: 404');
    }
}else{
    $_SESSION["state"]  = "danger";
    $_SESSION["title"]  = "Error";
    $_SESSION["msg"]    = "CSRF: Verification has been unsuccessful";
    header("Location: apply");
}
?>