<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$newpassword    = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['newpassword'], ENT_QUOTES, 'UTF-8'));
$oldpassword    = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['oldpassword'], ENT_QUOTES, 'UTF-8'));
$encrypted_password = sha1(md5(sha1($oldpassword)));
if(!empty($newpassword) || !empty($oldpassword)){
    $response =  loginAdmin($mysqli, $id);
    if(!$response['error']){
        if($encrypted_password == $response['password']){
            $encrypted_newpassword = sha1(md5(sha1($newpassword)));
            $responsePassword = changeAdminPassword($mysqli, $id , $encrypted_newpassword);
            if(!$responsePassword['error']){
                $_SESSION["state"]  = "success";
                $_SESSION["title"]  = "Success";
                $_SESSION["msg"]    = "You have successfully change your password.";
                header("Location: change.password.php");
            }else{
                $_SESSION["state"]  = "danger";
                $_SESSION["title"]  = "Error";
                $_SESSION["msg"]    = "Problem occured while saving data...";
                header("Location: change.password.php");
            }
        }else{
            $_SESSION["state"]  = "danger";
            $_SESSION["title"]  = "Error";
            $_SESSION["msg"]    = "Current password incorrect...";
            header("Location: change.password.php");
        }
  }else{
    $_SESSION["state"]  = "danger";
    $_SESSION["title"]  = "Error";
    $_SESSION["msg"]    = "Problem occured while saving data...";
    header("Location: change.password.php");
  }
}else{
    $_SESSION["state"]  = "danger";
    $_SESSION["title"]  = "Error";
    $_SESSION["msg"]    = "Problem occured while saving data...";
    header("Location: change.password.php");
}
?>