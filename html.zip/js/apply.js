$(document).ready(function(){
    $(function() {
        $("#plate_number").keyup(function() {
            this.value = this.value.toLocaleUpperCase();
        });
        $("#plate_number").attr("maxlength", 20);
        $("#plate_number").on('keypress', function (event) {
            var regex = new RegExp("^[a-zA-Z0-9]+$");
            var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
            if (!regex.test(key)) {
            event.preventDefault();
            return false;
            }
        });
    });

    $('#photoviewer_or').simpleLightbox();

    $('#photoviewer_cr').simpleLightbox();

    $('#photoviewer_front').simpleLightbox();

    $('#photoviewer_rear').simpleLightbox();

    $('#photoviewer_side1').simpleLightbox();

    $('#photoviewer_side2').simpleLightbox();

    $('#photoviewer_front2').simpleLightbox();

    $('#photoviewer_back').simpleLightbox();

    $('#photoviewer_pf').simpleLightbox();

    $('#photoviewer_bc').simpleLightbox();

    $('#photoviewer_il').simpleLightbox();

    $('#photoviewer_af').simpleLightbox();

    if($('.uploaded_support').length == 1){
            $('#photoviewer_support1').simpleLightbox();
    }else  if($('.uploaded_support').length == 2){
            $('#photoviewer_support1').simpleLightbox();
            $('#photoviewer_support2').simpleLightbox();
    }else if($('.uploaded_support').length == 3){
            $('#photoviewer_support1').simpleLightbox();
            $('#photoviewer_support2').simpleLightbox();
            $('#photoviewer_support3').simpleLightbox();
    }else if($('.uploaded_support').length == 4){
            $('#photoviewer_support1').simpleLightbox();
            $('#photoviewer_support2').simpleLightbox();
            $('#photoviewer_support3').simpleLightbox();
            $('#photoviewer_support4').simpleLightbox();
    }

    function displayNotification(title1, msg, state){
        if(state == 'success'){
            iziToast.success({title: title1, message: msg, onClosing: function () {},});
        }else{
            iziToast.error({title: title1, message: msg, onClosing: function () {},});
        }
    return;
    }

    $('#owner').on('change', function() {
        switch(this.value){
            case "0":
                $("#support").removeClass("nd");
                break;
            case "1":
                $("#support").addClass("nd");
                break;
        }
    });


    $("#endorser_phone").keydown(function(event) {
        var ASCIICode = (event.which) ? event.which : event.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    });

    
    $("#endorse_by").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#motor_number").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#chassis_number").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#vehicle_model").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#vehicle_maker").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#vehicle_color").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#plate_number").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  



    var i, currentYear, startYear, endYear, newOption, dropdownYear;
    dropdownYear = $("#year_model");
    currentYear = (new Date()).getFullYear();
    startYear = currentYear - 50;
    endYear = currentYear + 0;

    for (i=startYear;i<=endYear;i++) {
        newOption = '<option value='+i+'>'+i+'</option>';
            if (i == currentYear) {
                newOption = '<option selected="true" value='+i+'>'+i+'</option>';
            }
        dropdownYear.append(newOption);
    }

    $('#decalForm').submit(function() {
        if ($.trim($("#plate_number").val()) === "" || $.trim($("#vehicle_color").val()) === "" || $.trim($("#vehicle_model").val()) === "" || $.trim($("#chassis_number").val()) === "" || $.trim($("#vehicle_maker").val()) === "" || $.trim($("#motor_number").val()) === "")  {
            return false;
        } 
        if($('.uploaded_af').length == 0){
            displayNotification("Error", "Please upload your Application Form!", "danger");
            return false;
        }
        var classification = $("#classification").val();
        if(classification == "1"){
            if($('.uploaded_mf').length == 0){
                displayNotification("Error", "Please upload the front of your Military ID", "danger");
                return false;
                }
            if($('.uploaded_mb').length == 0){
                displayNotification("Error", "Please upload the back of your Military ID", "danger");
                return false;
            }
        }else if(classification == "2"){
                if($('.uploaded_rf').length == 0){
                displayNotification("Error", "Please upload the front of your Retirement ID", "danger");
                return false;
                }
            if($('.uploaded_rb').length == 0){
                displayNotification("Error", "Please upload the back of your Retirement ID", "danger");
                return false;
            }
        }else if(classification == "3"){
            if($('.uploaded_resf').length == 0){
                displayNotification("Error", "Please upload the front of your Reservist ID", "danger");
                return false;
                }
            if($('.uploaded_resb').length == 0){
                displayNotification("Error", "Please upload the back of your Reservist ID", "danger");
                return false;
            }
        }else if(classification == "4"){
            if($('.uploaded_cf').length == 0){
                displayNotification("Error", "Please upload the front of your CivHR ID", "danger");
                return false;
                }
            if($('.uploaded_cb').length == 0){
                displayNotification("Error", "Please upload the back of your CivHR ID", "danger");
                return false;
            }
        }else if(classification == "5"){
            if($('.uploaded_pf').length == 0){
                displayNotification("Error", "Please upload your Service Contract!", "danger");
                return false;
                }
        }else if(classification == "6"){
            if($('.uploaded_df').length == 0){
                displayNotification("Error", "Please upload the front of your Dependent ID", "danger");
                return false;
                }
            if($('.uploaded_db').length == 0){
                displayNotification("Error", "Please upload the back of your Dependent ID!", "danger");
                return false;
            }
        }else if(classification == "7"){
            if($('.uploaded_drf').length == 0){
                displayNotification("Error", "Please upload the front of your Father/Mother's Retirement ID", "danger");
                return false;
                }
            if($('.uploaded_drb').length == 0){
                displayNotification("Error", "Please upload the back of your Father/Mother's Retirement ID!", "danger");
                return false;
            }
            if($('.uploaded_bc').length == 0){
                displayNotification("Error", "Please upload your Birth Certificate!", "danger");
                return false;
            }
        }else if(classification == "8"){
            if($('#endorse_by').val() == ''){
                displayNotification("Error", "Please enter name of your Endorser!", "danger");
                return false;
            }
            if($('#endorser_phone').val() == ''){
                displayNotification("Error", "Please enter your Endorser's Phone No.!", "danger");
                return false;
            }
            if($('.uploaded_dlf').length == 0){
                displayNotification("Error", "Please upload the front of your Driver's License!", "danger");
                return false;
                }
            if($('.uploaded_dlb').length == 0){
                displayNotification("Error", "Please upload the back of your Driver's License!", "danger");
                return false;
            }
            
        }else if(classification == "9"){
            if($('#endorse_by').val() == ''){
                displayNotification("Error", "Please enter name of your Endorser!", "danger");
                return false;
            }
            if($('#endorser_phone').val() == ''){
                displayNotification("Error", "Please enter your Endorser's Phone No.!", "danger");
                return false;
            }
            if($('.uploaded_tif').length == 0){
                displayNotification("Error", "Please upload the front of your Tenant Issued ID!", "danger");
                return false;
                }
            if($('.uploaded_tib').length == 0){
                displayNotification("Error", "Please upload the back of your Tenant Issued ID!", "danger");
                return false;
            }
            
        }else if(classification == "10"){
            if($('#endorse_by').val() == ''){
                displayNotification("Error", "Please enter name of your Endorser!", "danger");
                return false;
            }
            if($('#endorser_phone').val() == ''){
                displayNotification("Error", "Please enter your Endorser's Phone No.!", "danger");
                return false;
            }
            if($('.uploaded_dlf').length == 0){
                displayNotification("Error", "Please upload the front of your Driver's License!", "danger");
                return false;
                }
            if($('.uploaded_dlb').length == 0){
                displayNotification("Error", "Please upload the back of your Driver's License!", "danger");
                return false;
            }
            
        }

        if($('.uploaded_or').length == 0){
            displayNotification("Error", "Please upload your Official Receipt!", "danger");
            return false;
        }
        if($('.uploaded_cr').length == 0){
            displayNotification("Error", "Please upload your Certificate of Registration!", "danger");
            return false;
        }
        if($('.uploaded_front').length == 0){
            displayNotification("Error", "Please upload Front photo of your Vehicle!", "danger");
            return false;
        }
        if($('.uploaded_rear').length == 0){
            displayNotification("Error", "Please upload Rear photo of your Vehicle!", "danger");
            return false;
        }
        if($('.uploaded_sides').length <= 1){
            displayNotification("Error", "Please upload 2 Side photo of your Vehicle!", "danger");
            return false;
        }
        if($("#owner").val() == "0"){
            if($('.uploaded_support').length == 0){
                displayNotification("Error", "Please upload your supporting documents such as DOS, Authorization Letter, etc...", "danger");
                return false;
            }
        }
    });

    $("#submit-btn").click(function(){
        var classification      = $("#classification").val();
        var plate_number        = $("#plate_number").val();
        var vehicle_color       = $("#vehicle_color").val();
        var vehicle_model       = $("#vehicle_model").val();
        var chassis_number      = $("#chassis_number").val();
        var vehicle_maker       = $("#vehicle_maker").val();
        var motor_number        = $("#motor_number").val();
        if(plate_number.length == 0) {
            displayNotification("Error", "Please enter Plate No.!", "danger");
            return;
        } 
        if(vehicle_color.length == 0) {
            displayNotification("Error", "Please enter Vehicle Color!", "danger");
            return;
        } 
        if(vehicle_model.length == 0) {
            displayNotification("Error", "Please enter Vehicle Model!", "danger");
            return;
        } 
        if(chassis_number.length == 0) {
            displayNotification("Error", "Please enter Chassis No.!", "danger");
            return;
        } 
        if(vehicle_maker.length == 0) {
            displayNotification("Error", "Please enter Vehicle Manufacturer!", "danger");
            return;
        } 
        if(motor_number.length == 0) {
            displayNotification("Error", "Please enter Motor No.!", "danger");
            return;
        }
    });


    $('#logout-btn-nav').click(function(e) {
        swal({
            title: 'Are you sure?',
            text: 'It will automatically logout your account!',
            type: 'warning',
            buttons:{
                confirm: {
                    text : 'yes',
                    className : 'btn btn-success'
                },
                cancel: {
                    visible: true,
                    className: 'btn btn-danger',
                    text : 'No'
                }
            }
        }).then((confirm) => {
            if (confirm) {
                window.location='logout' 
            } else {
                swal.close();
            }
        });
    });

    $('#logout-btn').click(function(e) {
        swal({
            title: 'Are you sure?',
            text: 'It will automatically logout your account!',
            type: 'warning',
            buttons:{
                confirm: {
                    text : 'yes',
                    className : 'btn btn-success'
                },
                cancel: {
                    visible: true,
                    className: 'btn btn-danger',
                    text : 'No'
                }
            }
        }).then((confirm) => {
            if (confirm) {
                window.location='logout' 
            } else {
                swal.close();
            }
        });
    });

    
    var allCount = $("#count-all");

    if($("#request-li").hasClass('active')){
        allCount.addClass("nd");
    }
    $('#toggle-btn').click(function(e) {
        if(!$("#base").hasClass('show')){
            allCount.addClass("nd");
        } else {
            allCount.removeClass("nd");
        }
    });

});