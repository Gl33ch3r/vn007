<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
  header('Location: login');
}
include_once '../includes/anticsrf.php';
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
require_once "../mailer.php";
require_once "../otp.php";
$mysqli = db_connect($config);
$responseDeficiency = array();
$aid =  mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["id"], ENT_QUOTES, 'UTF-8'));
$remarks =  mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["remarks"], ENT_QUOTES, 'UTF-8'));
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
$responseDecalInfo = getDecalInformation($mysqli, $aid);
$responseUser =  getUserByID($mysqli, $responseDecalInfo["user_id"]);
$responseVehicleInfo = getVehicleInformation($mysqli, $responseDecalInfo["vehicle_id"]);
if($response['error']){
  $responseDeficiency["error"] = true;
  echo json_encode($responseDeficiency);
  return;
}
if($responseVehicleInfo['error']){
  $responseClaimed = true;
  echo json_encode($responseClaimed);
  return;
}

$email  = $responseUser["email"];
$subject = "Request Deficiency - Philippine Navy Decal System";
$content = "<font size='3' face='Courier New' >Dear ".$responseUser["firstname"].",<br><br>    We would like to inform you that your Decal request for the Vehicle with the following information below is still pending due to <i>".$remarks."</i>, Please update your decal request and resubmit.</font><br><br>
<center><table style='width:60%; font-family:Courier New, Courier, monospace; font-size: 18px;'>
    <tr><th style='border: 1px solid black;'>Plate No.</th><th style='border: 1px solid black;'>Maker</th><th style='border: 1px solid black;'>Vehicle Model</th> <th style='border: 1px solid black;'>Year Model</th> <th style='border: 1px solid black;'>Color</th></tr>
    <tr><td style='border: 1px solid black;'>".$responseVehicleInfo["plate_number"]."</td><td style='border: 1px solid black;'>".$responseVehicleInfo["vehicle_maker"]."</td><td style='border: 1px solid black;'>".$responseVehicleInfo["vehicle_model"]."</td><td style='border: 1px solid black;'>".$responseVehicleInfo["year_model"]."</td><td style='border: 1px solid black;'>".$responseVehicleInfo["vehicle_color"]."</td></tr>
    </table></center><br><hr style='border-bottom:#e4e4ed 5px dotted;border-width:0 0 5px 0'><br><i>
    <font size='3' face='Courier New' ><center>Note: Please check the remarks, upload the neccessary requirements and resubmit your decal request.</center></font></i>";

$responseRemarks = addRemarks($mysqli, $aid, $remarks);
if($responseRemarks["error"]){
  $responseDeficiency["error"] = true;
  echo json_encode($responseDeficiency);
  return;
}

if(ENABLE_SMS == '1'){
  $number  = $responseUser["mobile"];
  $textMessage = "Dear ".$responseUser["firstname"].", We would like to inform you that your Decal request for the Vehicle with plate number ".$responseVehicleInfo["plate_number"]." is is still pending due to ".$remarks.". Please check your request and resubmit your request. Thank you";
  sendTextMessage($number,  $textMessage);
}
addTimeLine($mysqli, $aid, $id, "4", "0", "4");
$responseMail = sendMail($email, $subject, $content);
echo json_encode($responseMail);
return;
 
