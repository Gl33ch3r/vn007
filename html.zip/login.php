<?php
include_once 'includes/csrf.php';
include_once 'includes/session.php';
include_once 'includes/constant.php';
$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);
if(MAINTENANCE == "1"){
  header("Location: maintenance");
  return;
}

$page=" - LOGIN";
include_once 'includes/header.php';

?>
<div id="main">
    <div class="sc-glUWqk gZBdDv">
      <div class="sc-jqCOkK sc-bbmXgH sc-drlKqa kMexyI">
        <div class="sc-jqCOkK sc-bbmXgH sc-gGBfsJ sc-bIqbHp eFtCXp">
        <img width="200" height="200" src="<?php echo SITE_LOGO; ?>" class="sc-RbTVP kBYGdh">
          <h2 class="sc-iQKALj sc-dEfkYy fqMEYe"><?php echo APP;  ?></h2>
          <form id="loginForm" method="POST">
            <?=$csrf->input('login');?>
            <input type="text" name="email" id="email" placeholder="Email" autocomplete="off" value="<?php echo  $_SESSION['email']; ?>" class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG boaKTO sc-chPdSV lYoTa"/><br>
            <input type="password" name="password" id="password" placeholder="Password" autocomplete="off"  class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG pass sc-chPdSV lYoTa2"/>
            <img id="pass-button" class="pass-button" src="/img/hidden.png">
            <br>
            <input type="text" id="captcha" name="captcha_challenge" autocomplete="off" placeholder="Enter Captcha" class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG boaKTO2 sc-chPdSV lYoTa2"/>
            <img src="captcha.php" id="captcha-image" alt="CAPTCHA" class="captcha-image"><img id="refresh-btn" class="refresh-button" src="img/refresh-icon.png"><br>
            <button class="sc-hEsumM sc-jxGEyO boaKTO jFTvbI sc-kAzzGY gXQAXS" type="button" id="login" disabled>LOGIN</button>
          </form>
          <div class="sc-jqCOkK sc-uJMKN sc-yZwTr dctPBU">
            <hr class="sc-fjhmcy hr-pad"><span>or</span>
            <hr class="sc-fjhmcy hr-pad">
          </div>
              <a href="/signup" class="sc-hEsumM sc-jxGEyO sc-hwcHae gtwSej sc-kAzzGY gXQAXS" type="button" title="">SIGN UP</a>
              <a href="/forgot" class="sc-hEsumM sc-jxGEyO sc-hwcHae gtwSej sc-kAzzGY gXQAXS" type="button" title="">FORGOT PASSWORD</a>
        </div>
      <?php 
          include_once 'includes/footer.php';
      ?>
      </div>
    </div>
</div>
<div class="overlay"></div>
</body>
  <script nonce="87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d" type="text/javascript" src="/assets/js/plugin/sweetalert/sweetalert.min.js"></script>
  <script  type="text/javascript" src="/dist/js/iziToast.min.js"></script>
  <script type="text/javascript" src="/js/login.js"></script>
</html>
