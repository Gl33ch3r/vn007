<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
  header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
include_once '../includes/SimpleXLSXGen.php';

$mysqli = db_connect($config);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$decalid = mysqli_real_escape_string($mysqli, htmlspecialchars($_GET["decalid"], ENT_QUOTES, 'UTF-8'));
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['$id']);
  include_once '../includes/header.login.location.php';
  return;
}
$responseDecalInfo =  getDecalInformation($mysqli, $decalid);
if($responseDecalInfo['error']){
    header('Location: ../404');
    return;
}

$responseAccount =  getUserByID($mysqli, $responseDecalInfo["user_id"]);
if($responseAccount['error']){
    header('Location: ../404');
    return;
}

$resVehicleInfo =  getVehicleInformation($mysqli, $responseDecalInfo["vehicle_id"]);
if($resVehicleInfo['error']){
    header('Location: ../404');
    return;
}

$decalinfo = [
    ['Applicant Name', 'Serial No.', 'Unit Assignment', 'Vehicle', 'Color', 'Plate No.']
  ];

$decalinfo = array_merge($decalinfo, array(array('Firstname/Name Ext/Surname/Middle Initials', '', '', 'Manufacturer - Model', '', '')));
$middleInitial = $responseAccount["middlename"] == "" ? "" : substr($responseAccount["middlename"], 0, 1);
$name = $responseAccount["firstname"]." ".$responseAccount["lastname"]." ". $middleInitial;
$serialNo = $responseAccount["serial_number"];
$unitName = $responseAccount["unit_name"];
$vehicle = $resVehicleInfo["vehicle_maker"]." - ". $resVehicleInfo["vehicle_model"];
$color =  $resVehicleInfo["vehicle_color"];
$plateNo =  $resVehicleInfo["plate_number"];
$decalinfo = array_merge($decalinfo, array(array($name,$serialNo,$unitName,$vehicle,$color,$plateNo)));
$xlsx = Shuchkin\SimpleXLSXGen::fromArray($decalinfo);
$xlsx->downloadAs($name.'.xlsx');
?>