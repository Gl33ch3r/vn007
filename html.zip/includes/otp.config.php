<?php
define('user', 'decalotp');
define('pass', 'Decal@2022!!!');
define('token', 'cjA3Ixa0S6SUJh25CiL4k3:APA91bGUXmI2i17Cr87fkyDkKC0S2_J9N8GCa84O3j-oW-kbfh89_pk8tTsObZJuc4hAzeOKYkJ2r48dflOgN4IYIb87i3xzVLIR_Ny6HPglOTtr9bD9FbClimQJ7dx_xTa0eQZq44x7');
define('server_key', 'AAAAaxPU7mY:APA91bHCwktGZ3PEEh4Lqb8X1GexBC7yRiVjSOxEmbwdPbWVBfxJEdwSB6x71P2h2OP3Ai5cOFhnkAhzgVtANixaOyV9AsPmNFsi-gg-DAPikWhsMVGuBdASvG_CPRYCCONGC4SnQyGm');
?>