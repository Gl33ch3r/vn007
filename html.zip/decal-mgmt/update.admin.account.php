<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id                 = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['id'], ENT_QUOTES, 'UTF-8'));
$profile            = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['uploaded_profile_file_name'], ENT_QUOTES, 'UTF-8'));
$account_name       = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["account_name"], ENT_QUOTES, 'UTF-8'));
$sio                = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["sio"], ENT_QUOTES, 'UTF-8'));
$role               = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["role"], ENT_QUOTES, 'UTF-8'));
if($role == "1"){
    $sio = "0";
}
$response = loginAdmin($mysqli, $id);
if($response['error']){
    session_destroy();
    unset($_SESSION['id']);
    include_once '../includes/header.login.location.php';
    return;
  }

$responseAdmin = updateAdminUserAccount($mysqli, $account_name, $profile, $sio, $role, $id);
if(!$responseAdmin['error']){
    $ipaddress = getPublicIP();
    $responseLogs = addLogs($mysqli, $response["id"], "Edited Admin User", $account_name, $ipaddress, "1");
    $_SESSION["state"]  = "success";
    $_SESSION["title"]  = "Success";
    $_SESSION["msg"]    = "You have successfully updated the account.";
    header("Location: edit.admin.account.php?id=".$id);
}else{
    $_SESSION["state"]  = "danger";
    $_SESSION["title"]  = "Error";
    $_SESSION["msg"]    = "Problem occured while saving data...";
    header("Location: edit.admin.account.php?id=".$id);
}


?>