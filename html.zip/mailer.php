<?php
require_once "vendor/autoload.php";
require_once "includes/constant.php";
require_once 'includes/config.php';
require_once "includes/functions.php";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

function sendMail($email, $subject, $content){
    $response = array();
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Mailer     = PROTOCOL;
    $mail->SMTPDebug  = 0;  
    $mail->SMTPAuth   = TRUE;
    $mail->SMTPSecure = "tls";
    $mail->Port       = PORT;
    $mail->Host       = MAILHOST;
    $mail->Username   = MAIL;
    $mail->Password   = PASSWORD;
    $mail->IsHTML(true);
    $mail->AddAddress($email, "");
    $mail->SetFrom(REPLYTO, APP);
    $mail->AddReplyTo(REPLYTO, APP);
    $mail->Subject = $subject;
    $mail->MsgHTML($content); 
    if($mail->Send()){
        $response["error"]              = false;
    }else{
        $response["error"]              = true;
    }
   return $response;
}
