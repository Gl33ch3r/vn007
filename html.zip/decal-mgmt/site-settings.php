<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['$id']);
  include_once '../includes/header.login.location.php';
}


include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
<div class="overlay"></div>
<div class="wrapper">
        <?php include "../includes/navbar-admin.php" ?>
		<?php include "../includes/sidebar-admin.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<div class="card" id="siteSettingForm">
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Site Settings</h4>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
										<div class="col-md-5 mx-auto">	
                                            <div class="form-group">
												<label class="form-label">Site Status</label>
												<div class="selectgroup w-100">
													<label class="selectgroup-item">
														<input type="radio" id="maintenance" name="maintenance" value="0" class="selectgroup-input" <?php echo MAINTENANCE == "0" ? "checked" : "" ?>>
														<span class="selectgroup-button selectgroup-button-icon">Live Mode</span>
													</label>
													<label class="selectgroup-item">
														<input type="radio" id="maintenance" name="maintenance" value="1" class="selectgroup-input" <?php echo MAINTENANCE == "1" ? "checked" : "" ?>>
														<span class="selectgroup-button selectgroup-button-icon">Maintenance Mode</span>
													</label>
												</div>
											</div>
                                            <div class="form-group">
												<label for="account_name">Site Name</label>
												<input type="text" class="form-control" id="site_name" name="site_name" placeholder="Enter Site Name" value="<?php echo APP; ?>" >
											</div>
											<div class="form-group">
												<label for="username">Admin Site Name</label>
												<input type="text" class="form-control" id="admin_site_name" name="admin_site_name" placeholder="Enter Admin Site Name" value="<?php echo ADMIN_TITLE; ?>" >
											</div>
                                            <div class="form-group">
												<label for="email">Site Logo</label>
											</div>
                                            <div class="form-group" id="select_file_sitelogo" style="display: none;">
                                                    
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Images</button>
                                                        <input id="sitelogoupload" type="file" name="sitelogo_file" accept="image/x-png, image/gif, image/jpeg">
                                                    </div>
                                                    <!-- The global progress bar -->
                                                    <br>
                                                    <div id="progress_sitelogo" class="progress" style="display: none;">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                            </div>
                                            <div id="uploaded_images_sitelogo" class="form-group">
                                                <div class="uploaded_sitelogo avatar avatar-xxxl"> 
                                                   <input type="text" value="<?php echo SITE_LOGO ?>" name="uploaded_sitelogo_name" id="uploaded_sitelogo_name" hidden=""> 
                                                   <a target="_blank" id="photoviewer_sitelogo" href="<?php echo SITE_LOGO ?>">
                                                        <img src="<?php echo SITE_LOGO ?>" class="avatar-img rounded">
                                                    </a> 
                                                    <a class="img_rmv btn">
                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                    </a> 
                                                </div>
                                            </div>
                                            <div class="form-group">
												<label for="email">Site Favico Logo</label>
											</div>
                                            <div class="form-group" id="select_file_favico" style="display: none;">
                                                    
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Images</button>
                                                        <input id="favicoupload" type="file" name="favico_file" accept="image/x-png, image/gif, image/jpeg">
                                                    </div>
                                                    <!-- The global progress bar -->
                                                    <br>
                                                    <div id="progress_favico" class="progress" style="display: none;">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                            </div>
                                            <div id="uploaded_images_favico" class="form-group">
                                                <div class="uploaded_favico avatar avatar-xxl"> 
                                                   <input type="text" value="<?php echo ICO ?>" name="uploaded_favico_name" id="uploaded_favico_name" hidden=""> 
                                                   <a target="_blank" id="photoviewer_favico" href="<?php echo ICO ?>">
                                                        <img src="<?php echo ICO ?>" class="avatar-img rounded">
                                                    </a> 
                                                    <a class="img_rmv btn">
                                                        <i class="fas fa-trash-alt" style="font-size:18px;color:red"></i>
                                                    </a> 
                                                </div>
                                            </div>
                                            <br>
                                            <div class="card-action">
                                                <div class="d-flex justify-content-center">
                                                    <button type="button" id="save-site-btn" class="btn btn-success btn-round pr-5 pl-5"><i class="far fa-save"></i>  Save</button>
                                                    
                                                </div>
                                            </div>
										</div>
								</div>
                            </div>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "../includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<script src="../dist/js/iziToast.min.js"></script>
    <script src="js/upload.admin.js"></script>
    <script>
		$(document).ready(function(){
            var gallery = $('#photoviewer_sitelogo').simpleLightbox();
        });
        $(document).ready(function(){
            var gallery = $('#photoviewer_favico').simpleLightbox();
        });
		
        
	  	function displayNotification(title1, msg, state){
            if(state == 'success'){
                iziToast.success({title: title1, message: msg, onClosing: function () {},});
            }else{
                iziToast.error({title: title1, message: msg, onClosing: function () {},});
            }
           
           return;
        }
        $('input:radio[name="maintenance"]').change(function() {
            if ($(this).val() == '1') {
                var site_status1 = "1";
            } else {
                var site_status1 = "0";
            }
        });
       
        $("#save-site-btn").click(function () {
            if($.trim($("#site_name").val()) === "") {
                displayNotification("Error", "Please enter Site Name...", "danger");
                return;
            } 
            if($.trim($("#admin_site_name").val()) === "") {
                displayNotification("Error", "Please enter Admin Site Name...", "danger");
                return;
            } 
            if($.trim($("#uploaded_sitelogo_name").val()) === "") {
                displayNotification("Error", "Please upload Site Logo...", "danger");
                return;
            } 
            if($.trim($("#uploaded_favico_name").val()) === "") {
                displayNotification("Error", "Please upload Favico Logo...", "danger");
                return;
            } 
            var radioValue = $("input[name='maintenance']:checked").val();
            var site_name = $("#site_name").val();
            var admin_site_name =  $("#admin_site_name").val();
            var sitelogo = $("#uploaded_sitelogo_name").val();
            var favico =  $("#uploaded_favico_name").val();
            $.ajax({
                type: "POST",
                url: "save.site-settings.php",
                data: { 'site_status': radioValue, 'site_name': site_name, 'admin_site_name': admin_site_name, 'uploaded_sitelogo_name': sitelogo, 'uploaded_favico_name': favico },
                dataType : 'json',
                cache: false,
                success: function(response) {
                    if(response.error){
                        iziToast.error({title: response.title, message: response.msg, onClosing: function () {},});
                    }else{
                        iziToast.success({title:  response.title, message: response.msg, onClosing: function () {},});
                    }
                },failure: function (response) {
                    swal("Internal Error","Oops, something went wrong.", "error")
                }
            });
        });
</script>
<script src="../js/search.js"></script>
</body>
</html
