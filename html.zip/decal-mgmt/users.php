<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/anticsrf.php';
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response["user_role"] == "0"){
    header('Location: ../404');
}
if($response['error']){
  session_destroy();
  unset($_SESSION['id']);
  include_once '../includes/header.login.location.php';
}
include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
	<div class="wrapper">
		<?php include "../includes/navbar-admin.php" ?>
		<?php include "../includes/sidebar-admin.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Users</h4>
									</div>
								</div>
								<div class="card-body">
									<div class="table-responsive">
                                        <table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
                                                    <th>Profile</th>
													<th>Lastname</th>
                                                    <th>Firstname</th>
													<th>Middlename</th>
													<th>Status</th>
													<th style="width: 10%">Action</th>
												</tr>
											</thead>
											<tbody>
												<?php
													$responseAccount = getAllUsers($mysqli);
													while($u = mysqli_fetch_array($responseAccount)) {
														$status        		= $u["is_activated"];
                                                        $profile_pic        = $u["profile_pic"];
                                                        $lastname           = $u["lastname"];
                                                        $firstname          = $u["firstname"];
                                                        $middlename         = $u["middlename"];
														$uid         		= $u["id"];
														if($status == "0"){
															$stataFlag = "<span class='align-middle' style='color:#ffad46!important; font-weight:700'>Not Activated</span>";
														}else if($status == "1"){
															$stataFlag = "<span class='align-middle' style='color:#31ce36!important; font-weight:700'>Enabled</span>";
														}else if($status == "2"){
															$stataFlag = "<span class='align-middle' style='color:#f25961!important; font-weight:700'>Disabled</span>";
														}
														$is_setup =  $u["is_setup"];
												if($is_setup == "1"){
												?>
												<tr>
													<td>
                                                    <div class="profile-picture text-center">
                                                        <div class="avatar avatar-xl" style="margin-top: 10px; margin-bottom: 10px;">
															<a id="photoviewer" href="<?php echo $profile_pic; ?>">
																<img src="<?php echo $profile_pic; ?>" alt="..." id="profile" class="avatar-img rounded">
															</a>
                                                        </div>
                                                    </div>
                                                    </td>
                                                    <td><?php echo $lastname  ?></td>
													<td><?php echo $firstname ?></td>
													<td><?php echo $middlename ?></td>
													<td id="flag_<?php echo $uid; ?>"><?php echo $stataFlag ?>
													<td id="action_<?php echo $uid; ?>">
														<div class="form-button-action">
															<a type="button" data-toggle="tooltip"  href="view-user.php?id=<?php echo $uid; ?>" title="" class="btn btn-link btn-success" data-original-title="View">
																<i class="far fa-eye"></i>
                                                            </a>
															<?php if($status == "1"){ ?>
															<a type="button" data-toggle="tooltip" onclick="disableUser('<?php echo $uid; ?>');"  title="" class="btn btn-link btn-danger" data-original-title="Disable User">
																<i  class="fas fa-user-slash"></i>
                                                            </a>
															<?php }else{ ?>
															<a type="button" data-toggle="tooltip" onclick="activateUser('<?php echo $uid; ?>');"  title="" class="btn btn-link btn-success" data-original-title="Activate User">
																<i  class="fas fa-user-check"></i>
                                                            </a>
															<?php } ?>
														</div>
													</td>
												</tr>

												<?php } 
												}
												?>
												
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "../includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>

	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<script >
		 $(document).ready(function(){
            var gallery = $('#photoviewer').simpleLightbox();
         });

		$(document).ready(function() {
			$('#basic-datatables').DataTable({
			});
		});

		function disableUser(uid){
					swal({
						text: "Are you sure you want to disable this account?",
						type: 'warning',
						buttons:{
							cancel: {
								visible: true,
								text : 'No, cancel!',
								className: 'btn btn-danger'
							},        			
							confirm: {
								text : 'Yes, disable it!',
								className : 'btn btn-success'
							}
						}
					}).then((willDelete) => {
						if (willDelete) {
							$.ajax({
        						type: "POST",
        						url: "disable.user.php",
        						data: { 'id': uid },
								dataType : 'json',
        						cache: false,
        						success: function(response) {
									document.getElementById("flag_"+response.id).innerHTML = "<span class='align-middle' style='color:#f25961!important; font-weight:700'>Disabled</span>";
            						document.getElementById("action_"+response.id).innerHTML = '<div class="form-button-action"><a type="button" data-toggle="tooltip"  href="view-user.php?id='+response.id+'" title="" class="btn btn-link btn-success" data-original-title="View"><i class="far fa-eye"></i></a><a type="button" id="action_'+response.id+'" data-toggle="tooltip" onclick="activateUser('+response.id+');"  title="" class="btn btn-link btn-success" data-original-title="Enable User"><i  class="fas fa-user-check"></i></a></div>';
									swal("Sccess!","Account successfully disabled.","success")
        						},
        						failure: function (response) {
            						swal("Internal Error","Oops, something went wrong.", "error")
       							}
    						});

						}
					});
		}


		function activateUser(uid){
					swal({
						text: "Are you sure you want to enable this account?",
						type: 'warning',
						buttons:{
							cancel: {
								visible: true,
								text : 'No, cancel!',
								className: 'btn btn-danger'
							},        			
							confirm: {
								text : 'Yes, enable it!',
								className : 'btn btn-success'
							}
						}
					}).then((willDelete) => {
						if (willDelete) {
							$.ajax({
        						type: "POST",
        						url: "enable.user.php",
								data: { 'id': uid },
								dataType : 'json',
        						cache: false,
        						success: function(response) {
									document.getElementById("flag_"+response.id).innerHTML = "<span class='align-middle' style='color:#31ce36!important; font-weight:700'>Enabled</span>";
            						document.getElementById("action_"+response.id).innerHTML = '<div class="form-button-action"><a type="button" data-toggle="tooltip"  href="view-user.php?id='+response.id+'" title="" class="btn btn-link btn-success" data-original-title="View"><i class="far fa-eye"></i></a><a type="button" id="action_'+response.id+'" data-toggle="tooltip" onclick="disableUser('+response.id+');"  title="" class="btn btn-link btn-danger" data-original-title="Disable User"><i  class="fas fa-user-slash"></i></a></div>';
									swal("Sccess!","Account successfully enabled.","success")
        						},
        						failure: function (response) {
            						swal("Internal Error","Oops, something went wrong.", "error")
       							}
    						});

						}
					});
		}


		function displayNotification(title, msg, state, icon){
            var content = {};
			content.message = msg;
			content.title = title;
			content.icon = icon;
            $.notify(content,{
				type: state,
				placement: {
					from: 'bottom',
					align: 'right'
				},
				time: 1000,
				delay: 0,
			});
           return;
        }
	
	</script>
		<script>
	<?php
		if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
			$state 	= $_SESSION["state"];
			$msg 	= $_SESSION["msg"];
			$title 	= $_SESSION["title"];

			if($state == "success"){
				$icon = "fas fa-check";
			}else if($state == "warning"){
				$icon = "fas fa-exclamation-circle";
			}else if($state == "danger"){
				$icon = "fas fa-exclamation-triangle";
			}?>
				displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>", "<?php echo $icon; ?>");
	<?php } ?>
	</script>

	<?php
		unset($_SESSION["state"]);
		unset($_SESSION["msg"]);
		unset($_SESSION["title"]);
	?>
	<script src="../js/search.js"></script>
</body>
</html>