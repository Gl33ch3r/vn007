<?php
session_start();
if(!isset($_GET['id'])){
    echo '<script>window.location="../404"</script>';
}
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$admin_userid =  mysqli_real_escape_string($mysqli, htmlspecialchars($_GET["id"], ENT_QUOTES, 'UTF-8'));
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['$id']);
  include_once '../includes/header.login.location.php';
}

$responseAccount =  loginAdmin($mysqli, $admin_userid);
if($responseAccount['error']){
    header('Location: ../404');
}
include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
<div class="wrapper">
        <?php include "../includes/navbar-admin.php" ?>
		<?php include "../includes/sidebar-admin.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<form class="card" id="profileAdminForm" method="post" action="update.admin.account.php">
                            <input type="hidden" name="token" id="token" value="<?php echo $_SESSION["token"]?>"/>
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Add Admin Account</h4>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6 mx-auto">
                                        <div class="form-group">
                                        </div> 
                                            <div class="form-group" id="select_file_support">
                                                    <div class="profile-picture text-center">
                                                        <div class="avatar avatar-xxxl">
                                                            <a target="_blank" id="photoviewer" href="<?php echo $responseAccount['profile']; ?>">
                                                                <img src="<?php echo $responseAccount['profile']; ?>" alt="..." id="profile" class="avatar-img rounded-circle">
                                                            </a> 
                                                            <div class="inner">
                                                                <input id="profileupload" class="inputfile" type="file" name="profile_file" accept="image/x-png, image/gif, image/jpeg">
                                                                <label>
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
                                                                        <path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
                                                                    </svg>

                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <br>
                                                    <div id="progress_profile" class="progress" style="display: none;">
                                                    <br>
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    <div id="files_profile" class="files"></div>
                                                    <input type="text" name="uploaded_profile_file_name" id="uploaded_profile_file_name" value="<?php echo $responseAccount['profile']; ?>" hidden>
                                                    <input type="text" name="id"  value="<?php echo $admin_userid; ?>" hidden>
                                            
                                            
                                            </div>
                                            <div class="form-group">
												<label for="account_name">Account Name</label>
												<input type="text" class="form-control" id="account_name" name="account_name" placeholder="Enter Account Name" value="<?php echo $responseAccount['account_name'] ?>" >
											</div>
                                            <div class="form-group">
												<label for="role">Role</label>
												<select class="form-control" onchange="handleSelectChange(event)" id="role" name="role">
                                                <?php $type = getAllRoles($mysqli, $responseAccount['user_role']);
                                                foreach ($type as $value){
                                                        echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['role'].'</option>';
                                                } ?>
												</select>
											</div>
                                            <div class="form-group" id="sio" style="display:none;">
												<label for="selectSIO">Select SIO</label>
												<select class="form-control"  name="sio" id="selectSIO">
                                                <?php $sios = getAllSios($mysqli,  $responseAccount['sio_id']);
                                                foreach ($sios as $value){
                                                        echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['sios'].'</option>';
                                                } ?>
												</select>
											</div>
                                            <br>
                                            <br>
											<div class="card-action">
                                                <div class="d-flex justify-content-center">
                                                    <button type="button" data-toggle="modal" data-target="#changePasswordModal" class="btn btn-primary btn-round pr-3 pl-3 ml-1 mr-1">Change Password</button>
                                                    <button type="submit" id="submit-btn" class="btn btn-success btn-round pr-5 pl-5 ml-1 mr-1">Submit</button>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <br>
                                                <br>
                                            </div>
										</div>
								</div>
                            </form>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "../includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>

      <!----- START CHANGE PASSWORD MODAL ------>
  <div class="modal fade" id="changePasswordModal" role="dialog" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header no-bd">
				<h3 class="modal-title" style="color:black;">
					Change Password
				</h3>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
            <form>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>New Password</label>
                                <input type="hidden" name="token" id="token" value="<?php echo $_SESSION["token"]?>"/>
                                <input type="hidden" name="id_adminuser" id="id_adminuser" value="<?php echo $admin_userid ?>"/>
                                <input id="newpassword" placeholder="Enter New password" name="newpassword" type="password" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Confirm New Password</label>
                                <input id="cnewpassword" placeholder="Enter Confirm new password" name="cnewpassword" type="password" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer no-bd">
                    <button type="button" id="change-password" class="btn btn-primary">Change</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </form>
		</div>
	</div>
</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<script src="../dist/js/iziToast.min.js"></script>
    <script src="js/upload.admin.js"></script>
    <script>





        $(document).ready(function(){
            var gallery = $('#photoviewer').simpleLightbox();
        });
		
        <?php  if($responseAccount['user_role'] == "0"){ ?>
            document.getElementById("sio").style.display = "";
        <?php }else{ ?>
            document.getElementById("sio").style.display = "none";
        <?php } ?>
        function handleSelectChange(event) {
            var selectElement = event.target;
            var value = selectElement.value;
            if(value == "3" || value == "4"){
                document.getElementById("sio").style.display = "";
            }else  if(value == "1" || value == "2"){
                document.getElementById("sio").style.display = "none";
            }
        }
        
	  	function displayNotification(title1, msg, state, icon){
            if(state == 'success'){
                iziToast.success({title: title1, message: msg, onClosing: function () {},});
            }else{
                iziToast.error({title: title1, message: msg, onClosing: function () {},});
            }
           
           return;
        }


        function handleEnter (field, event) {
        var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
            if (keyCode == 13) {
                var i;
                for (i = 0; i < field.form.elements.length; i++)
                    if (field == field.form.elements[i])
                        break;
                i = (i + 1) % field.form.elements.length;
                field.form.elements[i].focus();
                return false;
            } else
                return true;
        }      

        $('#profileAdminForm').submit(function() {
            if ($.trim($("#account_name").val()) === "" )  {
                return false;
            }
        });

        $("#change-password").click(function () {
    
                if($.trim($("#newpassword").val()) === ""){
                    displayNotification("Error", "Please enter New Password!", "danger");
                    return false;
                }
                if($.trim($("#cnewpassword").val()) === ""){
                    displayNotification("Error", "Please enter Confirm New Password!", "danger");
                    return false;
                }

                if($.trim($("#newpassword").val()) != $.trim($("#cnewpassword").val())){
                    displayNotification("Error", "Passwords do not match!", "danger");
                    return false;
                }
                $("#changePasswordModal").modal('hide')
                var newpassword = $("#newpassword").val();
                var token = $("#token").val();
                var id = $("#id_adminuser").val();
                $.ajax({
                    type: "POST",
                    url: "change.admin.password.php",
                    data: { 'id': id, 'newpassword': newpassword, 'token': token },
                    dataType : 'json',
                    cache: false,
                    success: function(response) {
                        if(response.error){
                            swal({
                                title: "Error!",
                                text: "Error occurred while change password.",
                                icon: "error",
                                closeOnClickOutside: false,
                                buttons: {
                                    confirm2: {
                                        text: "Ok",
                                        value: true,
                                            visible: true,
                                            className: "btn btn-danger",
                                            closeModal: true
                                    }
                                }
                                }).then(confirm2 => {
                                    
                                });
                        }else{
                            swal({
                                title: "Good job!",
                                text: "You have successfully change password.",
                                icon: "success",
                                closeOnClickOutside: false,
                                buttons: {
                                    confirm2: {
                                        text: "Ok",
                                        value: true,
                                            visible: true,
                                            className: "btn btn-success",
                                            closeModal: true
                                    }
                                }
                                }).then(confirm2 => {
                                   
                                });
                            }
                            document.getElementById("newpassword").value = "";
                            document.getElementById("cnewpassword").value = "";
                        },
                        failure: function (response) {
                            swal("Internal Error","Oops, something went wrong.", "error")
                        }
                    });
            });


      
        var submitBtn = document.getElementById('submit-btn');
        submitBtn.addEventListener('click', () => {
            var account_name = document.getElementById("account_name").value;
            if(account_name.length == 0) {
                displayNotification("Error", "Please enter Account Name...", "danger", "fas fa-exclamation-triangle");
                return;
            } 
        });
    </script>
<script>
	<?php
		if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
			$state 	= $_SESSION["state"];
			$msg 	= $_SESSION["msg"];
			$title 	= $_SESSION["title"];

			if($state == "success"){
				$icon = "fas fa-check";
			}else if($state == "warning"){
				$icon = "fas fa-exclamation-circle";
			}else if($state == "danger"){
				$icon = "fas fa-exclamation-triangle";
			}?>
				displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>", "<?php echo $icon; ?>");
	<?php } ?>
	</script>

	<?php
        unset($_SESSION["user"]);
		unset($_SESSION["account_name"]);
		unset($_SESSION["profile"]);
        unset($_SESSION["sio"]);
		unset($_SESSION["role"]);
		unset($_SESSION["email"]);
		unset($_SESSION["state"]);
		unset($_SESSION["msg"]);
		unset($_SESSION["title"]);
	?>
    <script src="../js/search.js"></script>
</body>
</html>