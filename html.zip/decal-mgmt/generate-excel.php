<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
include_once '../includes/SimpleXLSXGen.php';
use Shuchkin\SimpleXLSXGen;
$mysqli = db_connect($config);
if(isset($_GET["yearfrom"]) && isset($_GET["yearto"])){
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$fromOld = mysqli_real_escape_string($mysqli, htmlspecialchars($_GET["yearfrom"], ENT_QUOTES, 'UTF-8'));
$toOld = mysqli_real_escape_string($mysqli, htmlspecialchars($_GET["yearto"], ENT_QUOTES, 'UTF-8'));
$from =  strtotime($fromOld.' 00:00:00');
$to = strtotime($toOld.' 23:59:59');
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['$id']);
  include_once '../includes/header.login.location.php';
}
       
        $decalinfoApproved = [
            ['<center><b>Applicant\'s Name</b></center>','<center><b>Rank</b></center>','<center><b>Serial No.</b></center>', '<center><b>BOS</b></center>', '<center><b>Unit Assignment/Address</b></center>', '<center><b>Personnel Classification</b></center>', '<center><b>Vehicle\n(Manufacturer-Make)</b></center>','<center><b>Color</b></center>', '<center><b>Plate No.</b></center>']
        ];
     
        $user_role = $response['user_role'];
		$sio_id = $response['sio_id'];
		if($user_role == "1"){
			$responseDecalInfoApproved = getAllApprovedDecalInformationReport($mysqli, "0", $from, $to);
		}else{
			$responseDecalInfoApproved = getAllApprovedDecalInformationReportSio($mysqli, "0", $from, $to, $sio_id);
		}
		while($u = mysqli_fetch_array($responseDecalInfoApproved)) {
			$vehicle_id         = $u["vehicle_id"];
			$status        		= $u["status"];
			$aid                = $u["application_id"];
			$uid                = $u["user_id"];
			$responseVehicle = getVehicleInformation($mysqli, $vehicle_id);
			$responseApplicant = getUserByID($mysqli, $uid);
			if($responseApplicant["classification"] == "1" || $responseApplicant["classification"] == "4" || $responseApplicant["classification"] == "5") {
				$address = $responseApplicant["unit_address"];
			}else{
				$address = $responseApplicant["address"];
			}

            $serialNo = " ".$responseApplicant["serial_number"]." ";
            if($responseApplicant["classification"] == "1"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                }else{
                    $bos = "";
                }
            }else if ($responseApplicant["classification"] == "2"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN (Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                }else{
                    $bos = "";
                }
            }else if($responseApplicant["classification"] == "3"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                  
                }else{
                    $bos = "";
                }
            }else if($responseApplicant["classification"] == "4" || $responseApplicant["classification"] == "5"){
                $rank = "CivHR";
                $bos = "NONE";
            }else{
                $bos = "NONE";
                $rank = "NONE";
            }
            
          
            if($responseApplicant["classification"] == "1" || $responseApplicant["classification"] == "2" || $responseApplicant["classification"] == "4" || $responseApplicant["classification"] == "5"){
                $unitName   = $responseApplicant["unit_name"];
            }else{
                $unitName   = $responseApplicant["address"];
            }
            if($responseApplicant["classification"] == "1" || $responseApplicant["classification"] == "3" || $responseApplicant["classification"] == "4"){
                $serialNo   = $responseApplicant["serial_number"];
            }else{
                $serialNo   = "NONE";
            }
            $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
            $name       = $responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"]; 
            $vehicle    = $responseVehicle["vehicle_maker"]." - ". $responseVehicle["vehicle_model"];
            $color      = $responseVehicle["vehicle_color"];
            $plateNo    = $responseVehicle["plate_number"];
            $classification = $responseApplicant["classification"];
            $decalinfoApproved = array_merge($decalinfoApproved, array(array("<left>".$name."</left>", "<left>".$rank."</left>", "<left>".$serialNo."</left>", "<left>".$bos."</left>", "<left>".$unitName."</left>", "<left>".getClassification($mysqli, $classification)["name"]."</left>", "<left>".$vehicle."</left>", "<left>".$color."</left>", "<left>".$plateNo."</left>")));
        }


        
        $decalinfoClaimed = [
            ['<center><b>Name</b></center>', '<center><b>UnitAdd/Address for Retired and Sponsored Civilians</b></center>', '<center><b>Vehicle</b></center>', '<center><b>Plate No.</b></center>','<center><b>Decal Type</b></center>', '<center><b>Decal No.</b></center>', '<center><b>Sponsor</b></center>', '<center><b>Sponsor\'n Contact N.</b></center>', '<center><b>Year</b></center>']
        ];
     
        $user_role = $response['user_role'];
		$sio_id = $response['sio_id'];
		if($user_role == "1"){
			$responseDecalInfoApproved = getAllApprovedDecalInformationReport($mysqli, "1", $from, $to);
		}else{
			$responseDecalInfoApproved = getAllApprovedDecalInformationReportSio($mysqli, "1", $from, $to, $sio_id);
		}
		while($u = mysqli_fetch_array($responseDecalInfoApproved)) {
			$vehicle_id         = $u["vehicle_id"];
			$status        		= $u["status"];
			$aid                = $u["application_id"];
            $uid                = $u["user_id"];

            
			$responseVehicle = getVehicleInformation($mysqli, $vehicle_id);
            $responseApplicant = getUserByID($mysqli, $uid);

            $serialNo = " ".$responseApplicant["serial_number"]." ";
            if($responseApplicant["classification"] == "1"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                }else{
                    $bos = "";
                }
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo.$bos;  
            }else if ($responseApplicant["classification"] == "2"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN (Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                }else{
                    $bos = "";
                }
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo.$bos;  
            }else if($responseApplicant["classification"] == "3"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                  
                }else{
                    $bos = "";
                }
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo.$bos;  
            }else if($responseApplicant["classification"] == "4" || $responseApplicant["classification"] == "5"){
                $rank = "CivHR";
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo;  
            }else{
                $bos = "";
                $rank = "";
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"];  
            }
      
			if($responseApplicant["classification"] == "1" || $responseApplicant["classification"] == "4" || $responseApplicant["classification"] == "5") {
				$address = $responseApplicant["unit_address"];
			}else{
				$address = $responseApplicant["address"];
			}
			$sponsored = $u["endorse_by"] == "" ?  "NONE" : $u["endorse_by"];
			$sponsors_contact = $u["endorser_contact"] == "" ? "NONE" : $u["endorser_contact"];
           
            $vehicle = $responseVehicle["vehicle_maker"] .'/'. $responseVehicle["vehicle_model"].'/'.$responseVehicle["vehicle_color"].'/'.$responseVehicle["year_model"];
            $decalinfoClaimed = array_merge($decalinfoClaimed, array(array("<left>".$name."</left>", "<left>".$address."</left>", "<left>".$vehicle."</left>", "<left>".$responseVehicle['plate_number']."</left>", "<left>".$u['category']."</left>", "<left>".$u['decal_number']."</left>", "<left>".$sponsored."</left>", "<left>".$sponsors_contact."</left>", "<left>".date('Y', strtotime($u["create_at"]))."</left>")));
        }


        $decalinfoTimeline = [
            ['<center><b>APPLICANT NAME</b></center>', '<center><b>PLATE NUMBER</b></center>', '<center><b>VEHICLE INFO(MAKE/MODEL/COLOR/YEAR)</b></center>', '<center><b>DECAL NUMBER</b></center>','<center><b>SIO</b></center>', '<center><b>DATE APPLIED</b></center>', '<center><b>DATE ENDORSED BY POIC ASST</b></center>', '<center><b>DATE ENDORSED BY ASST HAWKEYE</b></center>', '<center><b>DATE ENDORSED BY POIC CIB</b></center>', '<center><b>DATE APPROVED BY HAWKEYE OFFICER</b></center>', '<center><b>CLAIMED DATE</b></center>']
        ];

        if($user_role == "1"){
			$responseDecalInfoTimeline = getAllApprovedDecalInformationReport($mysqli, "1", $from, $to);
		}else{
			$responseDecalInfoTimeline = getAllApprovedDecalInformationReportSio($mysqli, "1", $from, $to, $sio_id);
		}
		while($u = mysqli_fetch_array($responseDecalInfoTimeline)) {
			$vehicle_id         = $u["vehicle_id"];
			$status        		= $u["status"];
			$aid                = $u["application_id"];
			$uid                = $u["user_id"];
            $sid                = $u["sio_id"];
            $endorsePoicAsst    = getTimelineData($mysqli, $aid, "3", "1")["what_time"];
            $endorseAsstHawk    = getTimelineData($mysqli, $aid, "2", "1")["what_time"];
            $endorseAsstCIB     = getTimelineData($mysqli, $aid, "1", "1")["what_time"];
            $approved           = getTimelineData($mysqli, $aid, "4", "2")["what_time"];
            $sio_name           = getSioName($mysqli, $sid)["sio_name"];
			$responseVehicle = getVehicleInformation($mysqli, $vehicle_id);
			$responseApplicant = getUserByID($mysqli, $uid);
			if($responseApplicant["classification"] == "1" || $responseApplicant["classification"] == "4" || $responseApplicant["classification"] == "5") {
				$address = $responseApplicant["unit_address"];
			}else{
				$address = $responseApplicant["address"];
			}

            $serialNo = " ".$responseApplicant["serial_number"]." ";
            if($responseApplicant["classification"] == "1"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                }else{
                    $bos = "";
                }
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo.$bos;  
            }else if($responseApplicant["classification"] == "2"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN (Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                }else{
                    $bos = "";
                }
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo.$bos;  
            }else if($responseApplicant["classification"] == "3"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                  
                }else{
                    $bos = "";
                }
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo.$bos;  
            }else if($responseApplicant["classification"] == "4" || $responseApplicant["classification"] == "5"){
                $rank = "CivHR";
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo;  
            }else{
                $bos = "";
                $rank = "";
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"];  
            }
			$sponsored = $u["endorse_by"] == "" ?  "NONE" : $u["endorse_by"];
			$sponsors_contact = $u["endorser_contact"] == "" ? "NONE" : $u["endorser_contact"];
            
            $vehicle = $responseVehicle["vehicle_maker"] .'/'. $responseVehicle["vehicle_model"].'/'.$responseVehicle["vehicle_color"].'/'.$responseVehicle["year_model"];
            $decalinfoTimeline = array_merge($decalinfoTimeline, array(array("<left>".$name."</left>", "<left>".$responseVehicle['plate_number']."</left>", "<left>".$vehicle."</left>", "<left>".$u['decal_number']."</left>", "<left>".$sio_name."</left>", "<left>".$u['create_at']."</left>", "<left>".$endorsePoicAsst."</left>", "<left>".$endorseAsstHawk."</left>", "<left>".$endorseAsstCIB."</left>", "<left>".$approved."</left>", "<left>".$u['date_claimed']."</left>")));
        }
        
        $decalinfoRejected = [
            ['<center><b>Name</b></center>', '<center><b>Unit Address/Address for Ritired/Sponsored Civilians</b></center>', '<center><b>Vehicle</b></center>', '<center><b>Plate No.</b></center>', '<center><b>Remarks</b></center>', '<center><b>Sponsor</b></center>', '<center><b>Sponsors Contact #</b></center>', '<center><b>Year</b></center>']
        ];
        if($user_role == "1"){
             $responseDecalInfo = getAllDecalInformationReport($mysqli, "2", $from, $to);
        }else{
             $responseDecalInfo = getAllDecalInformationReportSio($mysqli, "2", $from, $to, $sio_id);
        }
		while($u = mysqli_fetch_array($responseDecalInfo)) {
			$vehicle_id         = $u["vehicle_id"];
			$status        		= $u["status"];
			$aid                = $u["application_id"];
            $uid                = $u["user_id"];
			$responseVehicle = getVehicleInformation($mysqli, $vehicle_id);
            $responseApplicant = getUserByID($mysqli, $uid);
			if($responseApplicant["classification"] == "1" || $responseApplicant["classification"] == "4" || $responseApplicant["classification"] == "5") {
				$address = $responseApplicant["unit_address"];
			}else{
				$address = $responseApplicant["address"];
			}
            $serialNo = " ".$responseApplicant["serial_number"]." ";
            if($responseApplicant["classification"] == "1"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                }else{
                    $bos = "";
                }
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo.$bos;  
            }else if ($responseApplicant["classification"] == "2"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN (Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF(Ret)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                }else{
                    $bos = "";
                }
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo.$bos;  
            }else if($responseApplicant["classification"] == "3"){
                if($responseApplicant["bos"] == "1"){
                    $bos = "PN(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "ADM";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "VADM";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "RADM";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "COMMO";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "CAPT";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "CDR";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "LCDR";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "LT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "LTJG";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "ENS";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "MCPO";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SCPO";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "CPO";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "PO1";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "PO2";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "PO3";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "SN1";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "SN2";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "ASN";
                    }
                }else if($responseApplicant["bos"] == "2"){
                    $bos = "PN(M)(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "3"){
                    $bos = "PA(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "Cpl";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "Pfc";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Pvt";
                    }
                }else if($responseApplicant["bos"] == "4"){
                    $bos = "PAF(Res)";
                    if($responseApplicant["rank"] == "1"){
                        $rank = "GEN";
                    }else if($responseApplicant["rank"] == "2"){
                        $rank = "LTGEN";
                    }else if($responseApplicant["rank"] == "3"){
                        $rank = "MGEN";
                    }else if($responseApplicant["rank"] == "4"){
                        $rank = "BGEN";
                    }else if($responseApplicant["rank"] == "5"){
                        $rank = "COL";
                    }else if($responseApplicant["rank"] == "6"){
                        $rank = "LTCOL";
                    }else if($responseApplicant["rank"] == "7"){
                        $rank = "MAJ";
                    }else if($responseApplicant["rank"] == "8"){
                        $rank = "CPT";
                    }else if($responseApplicant["rank"] == "9"){
                        $rank = "1LT";
                    }else if($responseApplicant["rank"] == "10"){
                        $rank = "2LT";
                    }else if($responseApplicant["rank"] == "11"){
                        $rank = "CMS";
                    }else if($responseApplicant["rank"] == "12"){
                        $rank = "SMS";
                    }else if($responseApplicant["rank"] == "13"){
                        $rank = "1stSgt";
                    }else if($responseApplicant["rank"] == "14"){
                        $rank = "MSg";
                    }else if($responseApplicant["rank"] == "15"){
                        $rank = "TSg";
                    }else if($responseApplicant["rank"] == "16"){
                        $rank = "SSg";
                    }else if($responseApplicant["rank"] == "17"){
                        $rank = "Sgt";
                    }else if($responseApplicant["rank"] == "18"){
                        $rank = "A1c";
                    }else if($responseApplicant["rank"] == "19"){
                        $rank = "A2c";
                    }else if($responseApplicant["rank"] == "20"){
                        $rank = "Am";
                    }
                  
                }else{
                    $bos = "";
                }
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo.$bos;  
            }else if($responseApplicant["classification"] == "4" || $responseApplicant["classification"] == "5"){
                $rank = "CivHR";
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $rank == "" ? "" : $rank." ".$responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"].$serialNo;  
            }else{
                $bos = "";
                $rank = "";
                $middleInitial = $responseApplicant["middlename"] == "" ? "" : " ".substr($responseApplicant["middlename"], 0, 1);
                $name       = $responseApplicant["firstname"]. $middleInitial." ".$responseApplicant["lastname"];  
            }
            
           
			$sponsored = $u["endorse_by"] == "" ?  "NONE" : $u["endorse_by"];
			$sponsors_contact = $u["endorser_contact"] == "" ? "NONE" : $u["endorser_contact"];
            $vehicle = $responseVehicle["vehicle_maker"] .'/'. $responseVehicle["vehicle_model"].'/'.$responseVehicle["vehicle_color"].'/'.$responseVehicle["year_model"];

            $decalinfoRejected = array_merge($decalinfoRejected, array(array($name, $address, $vehicle, "<left>". $responseVehicle["plate_number"]."</left>", $u["remarks"], $sponsored, $sponsors_contact, date('Y', strtotime($u["create_at"])))));
   
        }
        $xlsx = new SimpleXLSXGen();
        $xlsx -> setDefaultFont( 'Courier New' );
        $xlsx  ->setDefaultFontSize( 14 );
        $xlsx->addSheet( $decalinfoApproved, 'APPROVED' );
        $xlsx->addSheet( $decalinfoClaimed, 'CLAIMED' );
        $xlsx->addSheet( $decalinfoRejected, 'REJECTED');
        $xlsx->addSheet( $decalinfoTimeline, 'TIMELINES');
        $xlsx->downloadAs('Decal Report'.$fromOld.'-'.$toOld.'.xlsx');
    
  
}
?>