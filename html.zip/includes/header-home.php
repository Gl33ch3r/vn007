<?php
if(MAINTENANCE == "1"){
	header("Location: maintenance");
	return;
}
if(!$response['is_setup']){
	header("Location: setup");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self' 'nonce-8db0369dff542ac448aa8f9e8ceaece603fe3de4ea9afbea19a46f4b87f4959b' 'nonce-87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d'; style-src 'self' 'nonce-87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d'; font-src 'self'; connect-src 'self'; img-src 'self' data:; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none';"/>
	<title><?php echo APP . " - " . $response["firstname"]; ?></title>
	<meta name="copyright" content="Philippine Navy Electronic Decal System">
    <meta name="author" content="Technical Intelligence Branch - N2 - GL33CH3R">
    <META name="revised" content="MARCH 2022">
	<link rel="icon" href="<?php echo ICO ?>" type="image/x-icon"/>
	<script type="text/javascript" src="/assets/js/plugin/webfont/webfont.min.js"></script>
	<script type="text/javascript" src="/assets/js/plugin/webfont/webfont.load.js"></script>
	<link rel="stylesheet" href="/css/loading.css" type='text/css'/>
	<link rel="stylesheet" href="/assets/css/font.nunito.css" type='text/css'/>
	<link rel="stylesheet" href="/assets/css/bootstrap.min.css" type='text/css'/>
	<link rel="stylesheet" href="/assets/css/atlantis.min.css" type='text/css'/>
	<link rel="stylesheet" href="/assets/css/demo.css" type='text/css'/>
    <link rel="stylesheet" href="/dist/css/iziToast.min.css" type='text/css'/>
	<link rel='stylesheet' href='/simplelightbox/dist/simple-lightbox.min.css' type='text/css'/>
	<script type="text/javascript" src="/js/jquery.min.js"></script>
	<script type="text/javascript" src="/dist/assets/jquery-file-upload/js/vendor/jquery.ui.widget.js"></script>
    <script type="text/javascript" src="/dist/assets/jquery-file-upload/js/jquery.iframe-transport.js"></script>
    <script type="text/javascript" src="/dist/assets/jquery-file-upload/js/jquery.fileupload.js"></script>
    <script type="text/javascript" src="/simplelightbox/dist/simple-lightbox.jquery.min.js"></script>
	<script type="text/javascript" src="/js/loading.js"></script>
</head>