<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
if(isset($_POST["yearfrom"]) && isset($_POST["yearto"])){
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$fromOld = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["yearfrom"], ENT_QUOTES, 'UTF-8'));
$toOld = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["yearto"], ENT_QUOTES, 'UTF-8'));
$from =  strtotime($fromOld.' 00:00:00');
$to = strtotime($toOld.' 23:59:59');
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['$id']);
  include_once '../includes/header.login.location.php';
}
$ipaddress = getPublicIP();
$responseLogs = addLogs($mysqli, $id, "generate report", "", $ipaddress, "1");
include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
	<div class="wrapper">
		<div class="main">
			<div class="content">
				<div class="page-inner">
					<div class="row">
					    <div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Generate Report - <?php echo $statusFlag; ?> Request (<?php echo $fromOld ?> to <?php echo $toOld ?>)</h4>

										<a class="btn btn-primary btn-round ml-auto pl-5 pr-5" href="generate-excel.php?yearfrom=<?php echo $fromOld ?>&yearto=<?php echo $toOld ?>">
											<i class="flaticon-download"></i>
											Export
										</a>
									</div>
								</div>
								<div class="card-body">
                                    <div class="table-responsive">
                                        <table id="basic-datatables" class="display table table-striped table-hover" >
                                        <thead>
												<tr>
													<th>Name</th>
                                                    <th>Unit Address/Address for Ritired/Sponsored Civilians</th>
													<th>Vehicle</th>
													<th>Plate No.</th>
													<th>Sponsor</th>
													<th>Sponsor's Contact #</th>
													<th>Year</th>
													<th>Status</th>
													
												</tr>
											</thead>
											<tbody>
												<?php
													  $user_role = $response['user_role'];
                                                      $sio_id = $response['sio_id'];
                                                      if($user_role == "1"){
                                                          $responseDecalInfo = getDecalInformationReport($mysqli, $from, $to);
                                                      }else{
                                                          $responseDecalInfo = getDecalInformationReportSio($mysqli, $from, $to, $sio_id);
                                                      }
													while($u = mysqli_fetch_array($responseDecalInfo)) {
														$vehicle_id         = $u["vehicle_id"];
														$status        		= $u["status"];
														$aid                = $u["application_id"];
                                                        $uid                = $u["user_id"];
														$is_claimed 		= $u["is_claimed"];
														$responseVehicle = getVehicleInformation($mysqli, $vehicle_id);
                                                        $responseApplicant = getUserByID($mysqli, $uid);
                                                        if($status == "1" && $is_claimed){
															$stataFlag = "<span class='align-middle' style='color:#31ce36!important; font-weight:700'>Claimed</span>";
														}else if($status == "1" && !$is_claimed){
															$stataFlag = "<span class='align-middle' style='color:#31ce36!important; font-weight:700'>Approved</span>";
														}else if($status == "2"){
															$stataFlag = "<span class='align-middle' style='color:#f25961!important; font-weight:700'>Rejected</span>";
														}
														
												?>
												<tr>
													<td><?php echo $responseApplicant["lastname"] .", ". $responseApplicant["firstname"] ?></td>
													<?php if($responseApplicant["classification"] == "1" || $responseApplicant["classification"] == "4" || $responseApplicant["classification"] == "5") { ?>
													<td><?php echo $responseApplicant["unit_address"] ?></td>
													<?php }else{ ?>
													<td><?php echo $responseApplicant["address"] ?></td>
													<?php } ?>
                                                    <td><?php echo $responseVehicle["vehicle_maker"]."/". $responseVehicle["vehicle_model"]."/".$responseVehicle["vehicle_color"]."/".$responseVehicle["year_model"] ?></td>
													<td><?php echo $responseVehicle["plate_number"] ?></td>
													<td><?php echo $u["endorse_by"] == "" ?  "NONE" : $u["endorse_by"] ?></td>
													<td><?php echo $u["endorser_contact"] == "" ? "NONE" : $u["endorser_contact"] ?></td>
													<td><?php echo date('Y', strtotime($u["create_at"])) ?></td>
													<td><?php echo $stataFlag ?></td>
												</tr>

												<?php } ?>
												
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
			
				</div>
			</div>
		</div>		
	</div>

	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<script src="../dist/js/iziToast.min.js"></script>
	<script >
        $('#download-report').on('click', function () {
            $.ajax({
                url: 'generate-excel.php',
                method: 'POST',
                data: { 'status': '<?php echo $status ?>', 'yearfrom': '<?php echo $fromOld ?>', 'yearto': '<?php echo $toOld ?>' },
                xhrFields: {
                    responseType: 'blob'
                },
                success: function (data) {
                    var a = document.createElement('a');
                    var today = new Date();
                    var dd = today.getDate();
                    var mm = today.getMonth() + 1;
                    var yyyy = today.getFullYear();
                    if (dd < 10) {
                        dd = '0' + dd;
                    }
                    if (mm < 10) {
                        mm = '0' + mm;
                    }
                    var today = dd + '/' + mm + '/' + yyyy;
                    var url = window.URL.createObjectURL(data);
                    a.href = url;
                    a.download = '<?php echo $statusFlag ?> - '+today+'.xls';
                    document.body.append(a);
                    a.click();
                    a.remove();
                    window.URL.revokeObjectURL(url);
                }
            });
        });
		$(document).ready(function() {
			$('#basic-datatables').DataTable({"order": [[ 5, "desc" ]], searching: false, lengthMenu: [10, 20, 50, 100, 200, 500], "pageLength": 50});
		});
		function displayNotification(title, msg, state, icon){
			if(state == 'success'){
                iziToast.success({title: title1, message: msg, onClosing: function () {},});
            }else{
                iziToast.error({title: title1, message: msg, onClosing: function () {},});
            }
           return;
        }
	</script>
		<script>
	<?php
		if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
			$state 	= $_SESSION["state"];
			$msg 	= $_SESSION["msg"];
			$title 	= $_SESSION["title"];

			if($state == "success"){
				$icon = "fas fa-check";
			}else if($state == "warning"){
				$icon = "fas fa-exclamation-circle";
			}else if($state == "danger"){
				$icon = "fas fa-exclamation-triangle";
			}?>
				displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>", "<?php echo $icon; ?>");
	<?php } ?>
	</script>

	<?php
		unset($_SESSION["state"]);
		unset($_SESSION["msg"]);
		unset($_SESSION["title"]);
	?>
</body>
</html>
<?php }else{
    header("Location: 404.php");
} ?>