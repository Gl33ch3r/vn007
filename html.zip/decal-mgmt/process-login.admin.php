<?php
include_once '../includes/csrf.php';
include_once '../includes/admin-session.php';
require_once '../includes/config.php';
require_once "../includes/functions.php";
include_once '../includes/constant.php';
$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);

$mysqli = db_connect($config);
$responseLogin = array();
$ipaddress = getPublicIP();

if(!$csrf->validate('login-admin')) {
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "CSRF: Verification has been unsuccessful";
  echo json_encode($responseLogin);
  return;
}
if(!isset($_POST['username']) && !isset($_POST['password']) && !isset($_POST['captcha'])){
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "Error Occurred while logging in!";
  echo json_encode($responseLogin);
  return;
}

$username           = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['username'], ENT_QUOTES, 'UTF-8'));
$password           = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['password'], ENT_QUOTES, 'UTF-8'));
$captcha_challenge  = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['captcha'], ENT_QUOTES, 'UTF-8'));
$encrypted_password = sha1(md5(sha1($password)));

if(isset($captcha_challenge) && $captcha_challenge != $_SESSION['captcha_text']) {
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "Incorrect Captcha, Please try again!";
  unset ($_SESSION["captcha_text"]);
  echo json_encode($responseLogin);
  return;
}

if(empty($username) || empty($password)){
  $responseLogin['msg']       = "Please enter username and password!";
  $responseLogin["error"]     = true;
  echo json_encode($responseLogin);
  return;
}

$response = adminLogin($mysqli, $username);
if($response['error']){
  $responseLogin['msg']       = "Incorrect username or password!";
  $responseLogin["error"]     = true;
  echo json_encode($responseLogin);
  return;
}

if($encrypted_password != $response['password']){
  $responseLogs = addLogs($mysqli, $response["id"], "Authentication", "Invalid Password", $ipaddress, "1");
  $responseLogin['msg']       = "Incorrect username or password!";
  $responseLogin["error"]     = true;
  echo json_encode($responseLogin);
  return;
}


if(!$response['is_enabled']){
  $responseLogs = addLogs($mysqli, $response["id"], "Authentication", "Disabled Account", $ipaddress, "1");
  $responseLogin['msg']       = "Account Disabled, Please contact Administrator.";
  $responseLogin["error"]     = true;
  echo json_encode($responseLogin);
  return;
}

$_SESSION['id']    = $response['id'];
setcookie("user_a", generateActivationCode() , $week->getTimestamp(), "/", null, true, null);
$responseLogs = addLogs($mysqli, $response["id"], "Authentication", "Authenticated", $ipaddress, "1");


if($response["user_role"] == "1" || $response["user_role"] == "5"){
  $responseLogin["error"] = false;
  $responseLogin["location"] ="dashboard";
  echo json_encode($responseLogin);
}else{
  $responseLogin["error"] = false;
  $responseLogin["location"] ="pending"; 
  echo json_encode($responseLogin);
}


?>