<?php
include_once 'includes/csrf.php';
include_once 'includes/session.php';
include_once 'includes/constant.php';
include_once 'includes/antiflood.php';
$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);
if(MAINTENANCE == "1"){
  header("Location: maintenance");
  return;
}

$page=" - SIGNUP";
include_once 'includes/header.php';

?>
<div id="main">
    <div class="sc-glUWqk gZBdDv">
      <div class="sc-jqCOkK sc-bbmXgH sc-drlKqa kMexyI">
        <div class="sc-jqCOkK sc-bbmXgH sc-gGBfsJ sc-bIqbHp eFtCXp">
        <img width="200" height="200" src="<?php echo SITE_LOGO; ?>" class="sc-RbTVP kBYGdh">
        <h1 class="sc-iQKALj sc-dEfkYy fqMEYe"><?php echo APP;  ?></h1>
          <div id ="message" class="message"></div>
          <form id="signUpForm" method="POST">
          <?=$csrf->input('signup');?>
          <input type="text" name="email" id="email" placeholder="Email" class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG boaKTO sc-chPdSV lYoTa"/><br>
          <input type="text" id="captcha" name="captcha_challenge" autocomplete="off" placeholder="Enter Captcha" class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG boaKTO2 sc-chPdSV lYoTa2"/>
          <img src="captcha.php" id="captcha-image" alt="CAPTCHA" class="captcha-image"><img id="refresh-btn" class="refresh-button" src="img/refresh-icon.png"><br>
          <br>
          <div class="terms">
          <span>By clicking SIGN UP, you agree to our <a href="" id="terms-link" target="_blank" rel="nofollow">Terms</a> and <a href="" id="privacy-link" target="_blank" rel="nofollow">Privacy Policy</a>.</span>
          </div>
          <button id="signup" class="sc-hEsumM sc-jxGEyO boaKTO jFTvbI sc-kAzzGY gXQAXS" type="button" disabled>SIGN UP</button>
          </form>
          <div class="sc-jqCOkK sc-uJMKN sc-yZwTr dctPBU">
            <hr class="sc-fjhmcy hr-pad"><span>or</span>
            <hr class="sc-fjhmcy hr-pad">
          </div>
          <a href="/login" class="sc-hEsumM sc-jxGEyO sc-hwcHae gtwSej sc-kAzzGY gXQAXS" type="button">LOGIN</a>
          <a href="/forgot" class="sc-hEsumM sc-jxGEyO sc-hwcHae gtwSej sc-kAzzGY gXQAXS" type="button">FORGOT PASSWORD</a>
        </div>
        <?php 
          include_once 'includes/footer.php';
      ?>
      </div>
    </div>
</div>
<div class="overlay"></div>
</body>
<script nonce="87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d" type="text/javascript" src="/assets/js/plugin/sweetalert/sweetalert.min.js"></script>
  <script type="text/javascript" src="/js/signup.js"></script>
  <script type="text/javascript" src="/dist/js/iziToast.min.js"></script>
</html>
