<?php

$message = array();
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
  $fullurl = "https"; 
}else{
  $fullurl = "http"; 
}
    
$fullurl .= "://"; 
$fullurl .= $_SERVER['HTTP_HOST'];
$fullurl .= "/"; 

if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['file']['tmp_name'];
    $fileName = $_FILES['file']['name'];
    $fileSize = $_FILES['file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."PROFILEFILE". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
    }else{
      if (in_array($fileExtension, $allowedfileExtensions)){
        // directory in which the uploaded file will be moved
        $uploadFileDir = './uploads/profile/';
        $dest_path = $uploadFileDir . $newFileName;
        if(move_uploaded_file($fileTmpPath, $dest_path)){
          $message['error'] = false;
           $message['path'] = $fullurl.$dest_path;
        }else{
          $message['error'] = true;
          $message['msg'] = '100000';
        }
      }else{
        $message['error'] = true;
        $message['msg'] = '100001';
      }
    }
   
  }else if(isset($_FILES['or_file']) && $_FILES['or_file']['error'] === UPLOAD_ERR_OK){
       // get details of the uploaded file
    $fileTmpPath = $_FILES['or_file']['tmp_name'];
    $fileName = $_FILES['or_file']['name'];
    $fileSize = $_FILES['or_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."ORFILE". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg', 'pdf');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
    }else{
      if (in_array($fileExtension, $allowedfileExtensions)){
        // directory in which the uploaded file will be moved
        $uploadFileDir = './uploads/or/';
        $dest_path = $uploadFileDir . $newFileName;
   
        if(move_uploaded_file($fileTmpPath, $dest_path)){
          $message['error'] = false;
           $message['path'] = $fullurl.$dest_path;
        }else{
          $message['error'] = true;
          $message['msg'] = '100000';
        }
      }else{
        $message['error'] = true;
        $message['msg'] = '100001';
      }
    }
   
  }else if(isset($_FILES['cr_file']) && $_FILES['cr_file']['error'] === UPLOAD_ERR_OK){
   // get details of the uploaded file
   $fileTmpPath = $_FILES['cr_file']['tmp_name'];
   $fileName = $_FILES['cr_file']['name'];
   $fileSize = $_FILES['cr_file']['size'];
   $fileNameCmps = explode(".", $fileName);
   $fileExtension = strtolower(end($fileNameCmps));
   // sanitize file-name
   $newFileName = date("Y")."CRFILE". md5(time() . $fileName) . '.' . $fileExtension;
   // check if file has one of the following extensions
   $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg', 'pdf');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
    }else{
    if (in_array($fileExtension, $allowedfileExtensions)){
      // directory in which the uploaded file will be moved
      $uploadFileDir = './uploads/cr/';
      $dest_path = $uploadFileDir . $newFileName;
      if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
      }else{
        $message['error'] = true;
        $message['msg'] = '100000';
      }
    }else{
      $message['error'] = true;
      $message['msg'] = '100001';
    }
  }
 
  }else if(isset($_FILES['support_file']) && $_FILES['support_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['support_file']['tmp_name'];
    $fileName = $_FILES['support_file']['name'];
    $fileSize = $_FILES['support_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."SDFILE". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg', 'pdf');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/sd/';
       $dest_path = $uploadFileDir . $newFileName;
       if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
       }else{
        $message['error'] = true;
        $message['msg'] = '100000';
       }
     }else{
      $message['error'] = true;
      $message['msg'] = '100001';
     }
   }
  
   }else if(isset($_FILES['front_file']) && $_FILES['front_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['front_file']['tmp_name'];
    $fileName = $_FILES['front_file']['name'];
    $fileSize = $_FILES['front_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."VIHECLEFILEFRONT". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/vehicle/';
       $dest_path = $uploadFileDir . $newFileName;
       if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
       }else{
        $message['error'] = true;
        $message['msg'] = '100000';
       }
     }else{
      $message['error'] = true;
      $message['msg'] = '100001';
     }
   }
  
   }else if(isset($_FILES['rear_file']) && $_FILES['rear_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['rear_file']['tmp_name'];
    $fileName = $_FILES['rear_file']['name'];
    $fileSize = $_FILES['rear_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."VIHECLEFILEREAR". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/vehicle/';
       $dest_path = $uploadFileDir . $newFileName;
       if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
       }else{
        $message['error'] = true;
        $message['msg'] = '100000';
       }
     }else{
      $message['error'] = true;
      $message['msg'] = '100001';
     }
   }
  
   }else if(isset($_FILES['sides_file']) && $_FILES['sides_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['sides_file']['tmp_name'];
    $fileName = $_FILES['sides_file']['name'];
    $fileSize = $_FILES['sides_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."VIHECLEFILESIDES". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/vehicle/';
       $dest_path = $uploadFileDir . $newFileName;
  
       if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
       }else{
        $message['error'] = true;
        $message['msg'] = '100000';
       }
     }else{
      $message['error'] = true;
      $message['msg'] = '100001';
     }
   }
  
   }else if(isset($_FILES['id_back_file']) && $_FILES['id_back_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['id_back_file']['tmp_name'];
    $fileName = $_FILES['id_back_file']['name'];
    $fileSize = $_FILES['id_back_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."IDBACkFILE". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/id/';
       $dest_path = $uploadFileDir . $newFileName;
  
       if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
       }else{
        $message['error'] = true;
        $message['msg'] = '100000';
       }
     }else{
      $message['error'] = true;
      $message['msg'] = '100001';
     }
   }
  
   }else if(isset($_FILES['id_front_file']) && $_FILES['id_front_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['id_front_file']['tmp_name'];
    $fileName = $_FILES['id_front_file']['name'];
    $fileSize = $_FILES['id_front_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."IDFRONTFILE-". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/id/';
       $dest_path = $uploadFileDir . $newFileName;
  
       if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
       }else{
        $message['error'] = true;
        $message['msg'] = '100000';
       }
     }else{
      $message['error'] = true;
      $message['msg'] = '100001';
     }
   }
  
   }else if(isset($_FILES['id_service_file']) && $_FILES['id_service_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['id_service_file']['tmp_name'];
    $fileName = $_FILES['id_service_file']['name'];
    $fileSize = $_FILES['id_service_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."SERVICECONTRACTFILE". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/service-contract/';
       $dest_path = $uploadFileDir . $newFileName;
  
       if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
       }else{
        $message['error'] = true;
        $message['msg'] = '100000';
       }
     }else{
      $message['error'] = true;
      $message['msg'] = '100001';
     }
   }
  
   }else if(isset($_FILES['id_birth_file']) && $_FILES['id_birth_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['id_birth_file']['tmp_name'];
    $fileName = $_FILES['id_birth_file']['name'];
    $fileSize = $_FILES['id_birth_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."BIRTHCERTIFICATEFILE". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/birth-certificate/';
       $dest_path = $uploadFileDir . $newFileName;
  
       if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
       }else{
        $message['error'] = true;
        $message['msg'] = '100000';
       }
     }else{
      $message['error'] = true;
      $message['msg'] = '100001';
     }
   }
  
   }else if(isset($_FILES['id_af_file']) && $_FILES['id_af_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['id_af_file']['tmp_name'];
    $fileName = $_FILES['id_af_file']['name'];
    $fileSize = $_FILES['id_af_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."APPLICATIONFORMFILE". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg', 'pdf');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/application-form/';
       $dest_path = $uploadFileDir . $newFileName;
  
       if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
       }else{
        $message['error'] = true;
        $message['msg'] = '100000';
       }
     }else{
      $message['error'] = true;
      $message['msg'] = '100001';
     }
   }
  
   }else if(isset($_FILES['profile_file']) && $_FILES['profile_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['profile_file']['tmp_name'];
    $fileName = $_FILES['profile_file']['name'];
    $fileSize = $_FILES['profile_file']['size'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    // sanitize file-name
    $newFileName = date("Y")."PROFILE". md5(time() . $fileName) . '.' . $fileExtension;
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
    if($fileSize > 64000000){
      $message['error'] = true;
      $message['msg'] = '100002';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/profile/';
       $dest_path = $uploadFileDir . $newFileName;
  
       if(move_uploaded_file($fileTmpPath, $dest_path)){
        $message['error'] = false;
         $message['path'] = $fullurl.$dest_path;
       }else{
        $message['error'] = true;
        $message['msg'] = '100000';
       }
     }else{
      $message['error'] = true;
      $message['msg'] = '100001';
     }
   }
  }else{
    $message['error'] = true;
    $message['msg'] = '100000';
  }
echo json_encode($message);
?>