var max_uploads_profile = 1
var max_uploads_support = 4
var max_uploads_sides = 2

function getExtension(path) {
    var basename = path.split(/[\\/]/).pop(),  // extract file name from full path ...
                                               // (supports `\\` and `/` separators)
        pos = basename.lastIndexOf(".");       // get last position of `.`

    if (basename === "" || pos < 1)            // if file name is empty or ...
        return "";                             //  `.` not found (-1) or comes first (0)

    return basename.slice(pos + 1);            // extract extension ignoring `.`
}

$(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#orupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
              iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
            }else if(data['result']['error'] && data['result']['msg'] == '100001'){
              iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
            }else if(data['result']['error'] && data['result']['msg'] == '100002'){
              iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
            }else{
                if(getExtension(data['result']['path']) == "pdf"){
                    $('#uploaded_images_or').append('<div class="uploaded_or avatar avatar-xxxl"> <input type="text" value="'+data['result']['path']+'" name="uploaded_or_name" id="uploaded_or_name" hidden> <a target="_blank" href="'+data['result']['path']+'"><img src="/img/pdf_icon.png" class="avatar-img rounded"/></a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                    if($('.uploaded_or').length >= max_uploads_profile){
                        $('#select_file_or').hide();
                    }else{
                        $('#select_file_or').show();
                    }
                }else{
                    $('#uploaded_images_or').append('<div class="uploaded_or avatar avatar-xxxl"> <input type="text" value="'+data['result']['path']+'" name="uploaded_or_name" id="uploaded_or_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"><img src="'+data['result']['path']+'" class="avatar-img rounded"/></a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                    if($('.uploaded_or').length >= max_uploads_profile){
                        $('#select_file_or').hide();
                    }else{
                        $('#select_file_or').show();
                    }
                }
            }
            $('#progress_or .progress-bar').css(
                'width',
                0 + '%'
            ).show();
            $.each(data.result.files, function (index, file) {
                $('<p/>').text(file.name).appendTo('#files_or');
            });
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_or .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_or" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_or').length >= max_uploads_profile){
        $('#select_file_or').hide();
    }else{
        $('#select_file_or').show();
    }
  });

  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#crupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                if(getExtension(data['result']['path']) == "pdf"){
                    $('#uploaded_images_cr').append('<div class="uploaded_cr avatar avatar-xxxl"> <input type="text" value="'+data['result']['path']+'" name="uploaded_cr_name" id="uploaded_cr_name" hidden> <a target="_blank" href="'+data['result']['path']+'"><img src="/img/pdf_icon.png" class="avatar-img rounded"/></a>  <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                    if($('.uploaded_cr').length >= max_uploads_profile){
                        $('#select_file_cr').hide();
                    }else{
                        $('#select_file_cr').show();
                    }
                }else{
                    $('#uploaded_images_cr').append('<div class="uploaded_cr avatar avatar-xxxl"> <input type="text" value="'+data['result']['path']+'" name="uploaded_cr_name" id="uploaded_cr_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"><img src="'+data['result']['path']+'" class="avatar-img rounded"/></a>  <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                    if($('.uploaded_cr').length >= max_uploads_profile){
                        $('#select_file_cr').hide();
                    }else{
                        $('#select_file_cr').show();
                    }
                }
            }
            $('#progress_cr .progress-bar').css(
                'width',
                0 + '%'
            ).show();
            $.each(data.result.files, function (index, file) {
                $('<p/>').text(file.name).appendTo('#files_cr');
            });
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_cr .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_cr" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_cr').length >= max_uploads_profile){
        $('#select_file_cr').hide();
    }else{
        $('#select_file_cr').show();
    }
  });

  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#frontupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_front').append('<div class="uploaded_front avatar avatar-xxxl"> <input type="text" value="'+data['result']['path']+'" name="uploaded_front_name" id="uploaded_front_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"><img src="'+data['result']['path']+'" class="avatar-img rounded"/></a>  <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_front').length >= max_uploads_profile){
                    $('#select_file_front').hide();
                }else{
                    $('#select_file_front').show();
                }
            }
            $('#progress_front .progress-bar').css(
                'width',
                0 + '%'
            ).show();
            $.each(data.result.files, function (index, file) {
                $('<p/>').text(file.name).appendTo('#files_front');
            });
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_front .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_front" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_front').length >= max_uploads_profile){
        $('#select_file_front').hide();
    }else{
        $('#select_file_front').show();
    }
  });

  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#rearupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_rear').append('<div class="uploaded_rear avatar avatar-xxxl"> <input type="text" value="'+data['result']['path']+'" name="uploaded_rear_name" id="uploaded_rear_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"><img src="'+data['result']['path']+'" class="avatar-img rounded"/></a>  <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_rear').length >= max_uploads_profile){
                    $('#select_file_rear').hide();
                }else{
                    $('#select_file_rear').show();
                }
            }
            $('#progress_rear .progress-bar').css(
                'width',
                0 + '%'
            ).show();
            $.each(data.result.files, function (index, file) {
                $('<p/>').text(file.name).appendTo('#files_rear');
            });
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_rear .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_rear" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_rear').length >= max_uploads_profile){
        $('#select_file_rear').hide();
    }else{
        $('#select_file_rear').show();
    }
  });

  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#sidesupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_sides').append('<div class="uploaded_sides avatar avatar-xxxl"> <input type="text" value="'+data['result']['path']+'" name="uploaded_sides_name[]" id="uploaded_sides_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"><img src="'+data['result']['path']+'" class="avatar-img rounded"/></a>  <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a></div>&nbsp; &nbsp;');
                if($('.uploaded_sides').length >= max_uploads_sides){
                    $('#select_file_sides').hide();
                }else{
                    $('#select_file_sides').show();
                }
            }
            $('#progress_sides .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_sides .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_sides" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_sides').length >= max_uploads_sides){
        $('#select_file_sides').hide();
    }else{
        $('#select_file_sides').show();
    }
  });

  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#supportupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                if(getExtension(data['result']['path']) == "pdf"){
                    $('#uploaded_images_support').append('<div class="uploaded_support avatar avatar-xxxl"> <input type="text" value="'+data['result']['path']+'" name="uploaded_support_name[]" id="uploaded_support_name[]" hidden> <a target="_blank" href="'+data['result']['path']+'"><img src="/img/pdf_icon.png" class="avatar-img rounded"/></a>  <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a></div>&nbsp; &nbsp;');
                    if($('.uploaded_support').length >= max_uploads_support){
                        $('#select_file_support').hide();
                    }else{
                        $('#select_file_support').show();
                    }
                }else{
                    $('#uploaded_images_support').append('<div class="uploaded_support avatar avatar-xxxl"> <input type="text" value="'+data['result']['path']+'" name="uploaded_support_name[]" id="uploaded_support_name[]" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"><img src="'+data['result']['path']+'" class="avatar-img rounded"/></a>  <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a></div>&nbsp; &nbsp;');
                    if($('.uploaded_support').length >= max_uploads_support){
                        $('#select_file_support').hide();
                    }else{
                        $('#select_file_support').show();
                    }
                }
            }
            $('#progress_support .progress-bar').css(
                'width',
                0 + '%'
            ).show();
            $.each(data.result.files, function (index, file) {
                $('<p/>').text(file.name).appendTo('#files_support');
            });
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_support .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_support" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_support').length >= max_uploads_support){
        $('#select_file_support').hide();
    }else{
        $('#select_file_support').show();
    }
  });


  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#profileupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                document.getElementById("profile_pic").src=data['result']['path'];
                document.getElementById("photoviewer").href = data['result']['path'];
                document.getElementById("uploaded_profile_file_name").setAttribute('value', data['result']['path']);
            }
            $('#progress_profile .progress-bar').css(
                'width',
                0 + '%'
            ).show();
            $.each(data.result.path.files, function (index, file) {
                $('<p/>').text(file.name).appendTo('#files_profile');
            });
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_profile .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });


  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#mfupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_mf').append('<div class="uploaded_mf avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_mf_name" id="uploaded_mf_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_mf').length >= max_uploads_profile){
                    $('#select_file_mf').hide();
                }else{
                    $('#select_file_mf').show();
                }
            }
            $('#progress_mf .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_mf .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_mf" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_mf').length >= max_uploads_profile){
        $('#select_file_mf').hide();
    }else{
        $('#select_file_mf').show();
    }
  });

  
  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#mbupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_mb').append('<div class="uploaded_mb avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_mb_name" id="uploaded_mb_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_mb').length >= max_uploads_profile){
                    $('#select_file_mb').hide();
                }else{
                    $('#select_file_mb').show();
                }
            }
            $('#progress_mb .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_mb .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_mb" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_mb').length >= max_uploads_profile){
        $('#select_file_mb').hide();
    }else{
        $('#select_file_mb').show();
    }
  });
  


  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#rfupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_rf').append('<div class="uploaded_rf avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_rf_name" id="uploaded_rf_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_rf').length >= max_uploads_profile){
                    $('#select_file_rf').hide();
                }else{
                    $('#select_file_rf').show();
                }
            }
            $('#progress_rf .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_rf .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_rf" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_rf').length >= max_uploads_profile){
        $('#select_file_rf').hide();
    }else{
        $('#select_file_rf').show();
    }
  });

  
  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#rbupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_rb').append('<div class="uploaded_rb avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_rb_name" id="uploaded_rb_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_rb').length >= max_uploads_profile){
                    $('#select_file_rb').hide();
                }else{
                    $('#select_file_rb').show();
                }
            }
            $('#progress_rb .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_rb .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_rb" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_rb').length >= max_uploads_profile){
        $('#select_file_rb').hide();
    }else{
        $('#select_file_rb').show();
    }
  });
  

  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#resfupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_resf').append('<div class="uploaded_resf avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_resf_name" id="uploaded_resf_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_resf').length >= max_uploads_profile){
                    $('#select_file_resf').hide();
                }else{
                    $('#select_file_resf').show();
                }
            }
            $('#progress_resf .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_resf .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_resf" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_resf').length >= max_uploads_profile){
        $('#select_file_resf').hide();
    }else{
        $('#select_file_resf').show();
    }
  });

  
  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#resbupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_resb').append('<div class="uploaded_resb avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_resb_name" id="uploaded_resb_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_resb').length >= max_uploads_profile){
                    $('#select_file_resb').hide();
                }else{
                    $('#select_file_resb').show();
                }
            }
            $('#progress_resb .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_resb .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_resb" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_resb').length >= max_uploads_profile){
        $('#select_file_resb').hide();
    }else{
        $('#select_file_resb').show();
    }
  });

  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#cfupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_cf').append('<div class="uploaded_cf avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_cf_name" id="uploaded_cf_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_cf').length >= max_uploads_profile){
                    $('#select_file_cf').hide();
                }else{
                    $('#select_file_cf').show();
                }
            }
            $('#progress_cf .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_cf .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_cf" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_cf').length >= max_uploads_profile){
        $('#select_file_cf').hide();
    }else{
        $('#select_file_cf').show();
    }
  });

  
  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#cbupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_cb').append('<div class="uploaded_cb avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_cb_name" id="uploaded_cb_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_cb').length >= max_uploads_profile){
                    $('#select_file_cb').hide();
                }else{
                    $('#select_file_cb').show();
                }
            }
            $('#progress_cb .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_cb .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_cb" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_cb').length >= max_uploads_profile){
        $('#select_file_cb').hide();
    }else{
        $('#select_file_cb').show();
    }
  });


  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#pfupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_pf').append('<div class="uploaded_pf avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_pf_name" id="uploaded_pf_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_pf').length >= max_uploads_profile){
                    $('#select_file_pf').hide();
                }else{
                    $('#select_file_pf').show();
                }
            }
            $('#progress_pf .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_pf .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_pf" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_pf').length >= max_uploads_profile){
        $('#select_file_pf').hide();
    }else{
        $('#select_file_pf').show();
    }
  });


  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#dfupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_df').append('<div class="uploaded_df avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_df_name" id="uploaded_df_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_df').length >= max_uploads_profile){
                    $('#select_file_df').hide();
                }else{
                    $('#select_file_df').show();
                }
            }
            $('#progress_df .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_df .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_df" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_df').length >= max_uploads_profile){
        $('#select_file_df').hide();
    }else{
        $('#select_file_df').show();
    }
  });

  
  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#dbupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_db').append('<div class="uploaded_db avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_db_name" id="uploaded_db_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_db').length >= max_uploads_profile){
                    $('#select_file_db').hide();
                }else{
                    $('#select_file_db').show();
                }
            }
            $('#progress_db .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_db .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_db" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_db').length >= max_uploads_profile){
        $('#select_file_db').hide();
    }else{
        $('#select_file_db').show();
    }
  });


  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#drfupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_drf').append('<div class="uploaded_drf avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_drf_name" id="uploaded_drf_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_drf').length >= max_uploads_profile){
                    $('#select_file_drf').hide();
                }else{
                    $('#select_file_drf').show();
                }
            }
            $('#progress_drf .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_drf .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_drf" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_drf').length >= max_uploads_profile){
        $('#select_file_drf').hide();
    }else{
        $('#select_file_drf').show();
    }
  });

  
  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#drbupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_drb').append('<div class="uploaded_drb avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_drb_name" id="uploaded_drb_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_drb').length >= max_uploads_profile){
                    $('#select_file_drb').hide();
                }else{
                    $('#select_file_drb').show();
                }
            }
            $('#progress_drb .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_drb .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_drb" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_drb').length >= max_uploads_profile){
        $('#select_file_drb').hide();
    }else{
        $('#select_file_drb').show();
    }
  });


  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#bcupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_bc').append('<div class="uploaded_bc avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_bc_name" id="uploaded_bc_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_bc').length >= max_uploads_profile){
                    $('#select_file_bc').hide();
                }else{
                    $('#select_file_bc').show();
                }
            }
            $('#progress_bc .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_bc .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_bc" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_bc').length >= max_uploads_profile){
        $('#select_file_bc').hide();
    }else{
        $('#select_file_bc').show();
    }
  });


  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#dlfupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_dlf').append('<div class="uploaded_dlf avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_dlf_name" id="uploaded_dlf_name" hidden> <a target="_blank" id="photoviewer" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_dlf').length >= max_uploads_profile){
                    $('#select_file_dlf').hide();
                }else{
                    $('#select_file_dlf').show();
                }
            }
            $('#progress_dlf .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_dlf .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_dlf" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_dlf').length >= max_uploads_profile){
        $('#select_file_dlf').hide();
    }else{
        $('#select_file_dlf').show();
    }
  });

  
  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#dlbupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_dlb').append('<div class="uploaded_dlb avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_dlb_name" id="uploaded_dlb_name" hidden> <a target="_blank" id="photoviewer_dlb" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_dlb').length >= max_uploads_profile){
                    $('#select_file_dlb').hide();
                }else{
                    $('#select_file_dlb').show();
                }
            }
            $('#progress_dlb .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_dlb .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_dlb" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_dlb').length >= max_uploads_profile){
        $('#select_file_dlb').hide();
    }else{
        $('#select_file_dlb').show();
    }
  });


  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#afupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                if(getExtension(data['result']['path']) == "pdf"){
                    $('#uploaded_images_af').append('<div class="uploaded_af avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_af_name" id="uploaded_af_name" hidden> <a href="'+data['result']['path']+'" target="_blank"> <img src="/img/pdf_icon.png" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                    if($('.uploaded_af').length >= max_uploads_profile){
                        $('#select_file_af').hide();
                    }else{
                        $('#select_file_af').show();
                    }
                }else{
                    $('#uploaded_images_af').append('<div class="uploaded_af avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_af_name" id="uploaded_af_name" hidden> <a target="_blank" id="photoviewer_af" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                    if($('.uploaded_af').length >= max_uploads_profile){
                        $('#select_file_af').hide();
                    }else{
                        $('#select_file_af').show();
                    }
                }
            }
            $('#progress_af .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_af .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_af" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_af').length >= max_uploads_profile){
        $('#select_file_af').hide();
    }else{
        $('#select_file_af').show();
    }
  });


  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#tifupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_tif').append('<div class="uploaded_tif avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_tif_name" id="uploaded_tif_name" hidden> <a target="_blank" id="photoviewer_tif" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_tif').length >= max_uploads_profile){
                    $('#select_file_tif').hide();
                }else{
                    $('#select_file_tif').show();
                }
            }
            $('#progress_tif .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_tif .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_tif" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_tif').length >= max_uploads_profile){
        $('#select_file_tif').hide();
    }else{
        $('#select_file_tif').show();
    }
  });

  
  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = '/upload';
    $('#tibupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
            if(data['result']['error'] && data['result']['msg'] == '100000'){
                iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100001'){
                iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
              }else if(data['result']['error'] && data['result']['msg'] == '100002'){
                iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
              }else{
                $('#uploaded_images_tib').append('<div class="uploaded_tib avatar-id avatar-new"> <input type="text" value="'+data['result']['path']+'" name="uploaded_tib_name" id="uploaded_tib_name" hidden> <a target="_blank" id="photoviewer_tib" href="'+data['result']['path']+'"> <img src="'+data['result']['path']+'" class="avatar-img rounded"/> </a> <a class="img_rmv btn"><i class="fas fa-trash-alt removebtn"></i></a> </div>');
                if($('.uploaded_tib').length >= max_uploads_profile){
                    $('#select_file_tib').hide();
                }else{
                    $('#select_file_tib').show();
                }
            }
            $('#progress_tib .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_tib .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_tib" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_tib').length >= max_uploads_profile){
        $('#select_file_tib').hide();
    }else{
        $('#select_file_tib').show();
    }
  });
