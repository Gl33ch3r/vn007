<?php
$config['db']['host'] = 'localhost';
$config['db']['name'] = 'decal';
$config['db']['user'] = 'root';
$config['db']['pass'] = '';
$config['db']['charset'] = 'utf8mb4';
$week = new DateTime('+1 week');
?>