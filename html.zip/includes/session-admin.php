<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING ^ E_DEPRECATED);
session_start();
ini_set("session.cookie_secure", 1);
include_once '../includes/config.php';
include_once '../includes/functions.php';
$mysqli = db_connect($config);
if(isset($_COOKIE['user_a']) && isset($_SESSION['id'])){
    $response =  loginAdmin($mysqli, $id);
    if($response["user_role"] == "1" || $response["user_role"] == "5"){
        header('Location: dashboard');
      }else{
        header('Location: pending');  
      }
}
?>