<!-- Sidebar -->
<div class="sidebar sidebar-style-2" data-background-color="dark2">
	<div class="sidebar-wrapper scrollbar scrollbar-inner">
		<div class="sidebar-content">
			<ul class="nav nav-primary">
				<?php $curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);  ?>
				<li id="request-li" class="nav-item <?php if($curPageName == 'pending.php' || $curPageName == 'rejected.php' || $curPageName == 'approved.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "pending.php" || base64_decode($_GET['from']) ==  "approved.php" || base64_decode($_GET['from']) ==  "rejected.php"))) echo 'active' ?> submenu">
					<a id="toggle-btn" data-toggle="collapse" href="#base">
						<i class="fas fa-list-alt"></i>
						<?php 
						$pending_count  = getAllDecalCountUser($mysqli, "1", PENDING, $response["id"]);
						$approved_count = getAllDecalCountUser($mysqli, "0", APPROVED, $response["id"]);
						$rejected_count = getAllDecalCountUser($mysqli, "0", REJECTED, $response["id"]);
						$all_count =  $pending_count + $approved_count + $rejected_count; 
						if($all_count > "0"){
							$a_count = "<span id='count-all' class='badge badge-success'>".$all_count."</span>";
						}else{
							$a_count = "";
						}
						?>
						<p>Decal Request</p>
						<?php echo $a_count ?>
						<span class="caret"></span>
					</a>
					<div class="collapse <?php if($curPageName == 'pending.php' || $curPageName == 'rejected.php' || $curPageName == 'approved.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "pending.php" || base64_decode($_GET['from']) ==  "approved.php" || base64_decode($_GET['from']) ==  "rejected.php")))  echo 'show' ?>" id="base">
						<ul class="nav nav-collapse">
							<li <?php if($curPageName == 'pending.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "pending.php" ))) echo 'class="active"'; ?>>
									<?php $pending_count = getAllDecalCountUser($mysqli, "1", PENDING, $response["id"]);
										if($pending_count > "0"){
											$p_count = "<span class='badge badge-success'>".$pending_count."</span>";
										}else{
											$p_count = "";
										}
									?>
								<a href="/pending">
									<i class="icon-hourglass"></i>
									<p>Pending</p>
									<?php echo $p_count ?>
								</a>
							</li>
							
							<li <?php if($curPageName == 'rejected.php'  || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "rejected.php" ))) echo 'class="active"'; ?>>
									<?php $rejected_count = getAllDecalCountUser($mysqli, "0", REJECTED, $response["id"]);
										if($rejected_count > "0"){
											$r_count = "<span class='badge badge-success'>".$rejected_count."</span>";
										}else{
											$r_count = "";
										}
									?>
								<a href="/rejected">
									<i class="icon-ban"></i>
									<p>Rejected</p>
									<?php echo $r_count ?>
								</a>
							</li>
							
							<li <?php if($curPageName == 'approved.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "approved.php" ))) echo 'class="active"'; ?>>
									<?php $approved_count = getAllDecalCountUser($mysqli, "0", APPROVED, $response["id"]);
										if($approved_count > "0"){
											$a_count = "<span class='badge badge-success'>".$approved_count."</span>";
										}else{
											$a_count = "";
										}
									?>
								<a href="/approved">
									<i class="icon-like"></i>
									<p>Approved</p>
									<?php echo $a_count ?>
								</a>
							</li>

						</ul>
					</div>
				</li>
				<li class="nav-item <?php if($curPageName == 'apply.php') echo 'active'; ?> ">
					<a href="/apply">
						<i class="fas fa-plus-circle"></i>
						<p>Apply Decal</p>
					</a>
				</li>
				<li class="nav-item <?php if($curPageName == 'history.php' || (isset($_GET['from']) && (base64_decode($_GET['from']) ==  "history.php" ))) echo 'active'; ?> ">
					<a href="/history">
						<i class="fas fa-history"></i>
						<p>Transaction History</p>
					</a>
				</li>
				<li class="nav-item">
					<a href="#" id="logout-btn">
						<i class="fas fa-sign-out-alt"></i>
						<p>Logout</p>
					</a>
				</li>
			</ul>
		</div>
	</div>
</div>
<!-- End Sidebar -->