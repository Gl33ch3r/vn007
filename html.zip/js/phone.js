$(document).ready(function () {
    $('#phone').on('keypress', function (e) {
        var ingnore_key_codes = [34, 39];
        if ($.inArray(e.which, ingnore_key_codes) >= 0) {
            e.preventDefault();
        } 
    });
        
   
    $("#phone").keyup(function () {
        validate();
    });
   

    $("#verify").click(function () {
        if ($.trim($("#phone").val()) === "") {
            return false;
        }
        var phone = $("#phone").val();
        var csrftoken = $("#csrftoken").val();
      
    });
   
       
})

function validate() {
    let phone = $("#phone").val();
    if (phone == "") {
        $("#phone").css("border","1px solid red");
        $("#verify").prop('disabled', true);
    }else{
        $("#phone").css("border","none");
        $("#verify").prop('disabled', false);
    }
}
