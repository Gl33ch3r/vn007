<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING ^ E_DEPRECATED);
session_start();
ini_set("session.cookie_secure", 1);
if(isset($_COOKIE['user_c']) && isset($_SESSION['email'])){
    header('Location: pending');
}
?>