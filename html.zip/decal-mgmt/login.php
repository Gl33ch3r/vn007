<?php
include_once '../includes/csrf.php';
include_once '../includes/admin-session.php';
include_once '../includes/constant.php';
include_once '../includes/header-login-admin.php';
$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);
?>
<div id="main">
    <div class="sc-glUWqk gZBdDv">
      <div class="sc-jqCOkK sc-bbmXgH sc-drlKqa kMexyI">
        <div class="sc-jqCOkK sc-bbmXgH sc-gGBfsJ sc-bIqbHp eFtCXp">
        <img width="200" height="200" src="<?php echo SITE_LOGO; ?>" class="sc-RbTVP kBYGdh">
          <h2 class="sc-iQKALj sc-dEfkYy fqMEYe"><?php echo ADMIN_TITLE;  ?></h2>
          <form id="loginAdminForm" method="POST">
            <?=$csrf->input('login-admin');?>
            <input type="text" name="username" id="username" autocomplete="off" placeholder="Username" value="<?php echo  $_SESSION['username']; ?>"class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG boaKTO sc-chPdSV lYoTa"/><br>
            <input type="password" name="password" id="password" placeholder="Password" autocomplete="off"  class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG pass sc-chPdSV lYoTa2"/>
            <img id="pass-button" class="pass-button" src="/img/hidden.png">
            <br>
            <input type="text" id="captcha" name="captcha_challenge" autocomplete="off" placeholder="Enter Captcha" class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG boaKTO2 sc-chPdSV lYoTa2"/>
            <img src="../captcha.php" id="captcha-image" alt="CAPTCHA" class="captcha-image"><img id="refresh-btn" class="refresh-button" src="/img/refresh-icon.png"><br>
            <button class="sc-hEsumM sc-jxGEyO boaKTO jFTvbI sc-kAzzGY gXQAXS" type="button" id="login-admin" disabled>LOGIN</button>
          </form>
          <div class="sc-jqCOkK sc-uJMKN sc-yZwTr dctPBU">
          
          </div>
          <div class="sc-jqCOkK sc-uJMKN sc-yZwTr dctPBU">
          
          </div>
             
        </div>
      <?php include_once '../includes/footer.php'; ?>
      </div>
    </div>
</div>
<div class="overlay"></div>
</body>
  <script src="../dist/js/iziToast.min.js"></script>
  <script src="../js/login-admin.js"></script>
</html>
