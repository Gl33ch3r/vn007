
function handleEnter (field, event) {
   var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
   if (keyCode == 13) {
      var i;
      for (i = 0; i < field.form.elements.length; i++)
         if (field == field.form.elements[i])
            break;
      i = (i + 1) % field.form.elements.length;
      field.form.elements[i].focus();
      return false;
   } 
   else
   return true;
}      

function stopEnterKey(evt) {
   var evt = (evt) ? evt : ((event) ? event : null);
   var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
   if ((evt.keyCode == 13) && (node.type == "text")) { return false; }
   if ((evt.keyCode == 13) && (node.type == "date")) { return false; }
}
document.onkeypress = stopEnterKey;

const phoneInputField = document.querySelector("#phone");
   const phoneInput = window.intlTelInput(phoneInputField, {
      preferredCountries: ["ph","us"],
     utilsScript:
       "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
   });

var e = document.getElementById("decal_type");

var mil = document.getElementById("mil");
var chr = document.getElementById("chr");
var others = document.getElementById("others");
function decalTypeFunction(chosen) {
   if(e.value == "Military"){
      document.getElementById("next-btn").disabled = false; 
      mil.classList.add('step');
      chr.classList.remove('step');
      chr.style.display = "none";
      others.classList.remove('step');
      others.style.display = "none";
   }else if(e.value =="AFP-CHR"){
      document.getElementById("next-btn").disabled = false; 
      chr.classList.add('step');
      mil.classList.remove('step');
      mil.style.display = "none";
      others.classList.remove('step');
      others.style.display = "none";
   }else if(e.value=="Civilian"){
      document.getElementById("next-btn").disabled = false; 
      others.classList.add('step');
      chr.classList.remove('step');
      mil.classList.remove('step');
      mil.style.display = "none";
      chr.style.display = "none";
   }
}

const progress = (value) => {
    document.getElementsByClassName('progress-bar')[0].style.width = `${value}%`;
 }


 
    let step = document.getElementsByClassName('step');
    let prevBtn = document.getElementById('prev-btn');
    let nextBtn = document.getElementById('next-btn');
    let submitBtn = document.getElementById('submit-btn');
    let form = document.getElementsByTagName('form')[0];
    let preloader = document.getElementById('preloader-wrapper');
    let bodyElement = document.querySelector('body');
    let succcessDiv = document.getElementById('success');
  
    form.onsubmit = () => { return false }
 
    let current_step = 0;
    let stepCount = 5
    step[current_step].classList.add('d-block');
    if(current_step == 0){
       prevBtn.classList.add('d-none');
       submitBtn.classList.add('d-none');
       nextBtn.classList.add('d-inline-block');
    }

    
 
 
    nextBtn.addEventListener('click', () => {
      var email_x = document.getElementById("email").value;
      var fname_x = document.getElementById("firstname").value;
      var lname_x = document.getElementById("lastname").value;
      var mname_x = document.getElementById("middlename").value;
      var address_x = document.getElementById("address").value;
      var bday_x = document.getElementById("birthdate").value;
      var profile_x = document.getElementById("uploaded_profile_file_name").value;

      var bos_m = document.getElementById("bos_m");
      var rank_m = document.getElementById("rank_m");
      var date_enlisted_m = document.getElementById("date_enlisted_m").value;
      var date_retired_m = document.getElementById("date_retired_m").value;
      var serial_number_m = document.getElementById("serial_number_m").value;
      var designation_m = document.getElementById("designation_m").value;
      var unit_m = document.getElementById("unit_m").value;
      var unit_address_m = document.getElementById("unit_address_m").value;
      var unit_phone_m = document.getElementById("unit_phone_m").value;

      var bos_c = document.getElementById("bos_c");
      var date_employed_c = document.getElementById("date_employed_c").value;
      var date_retired_c = document.getElementById("date_retired_c").value;
      var serial_number_c = document.getElementById("civ_number_c").value;
      var designation_c = document.getElementById("designation_c").value;
      var unit_c = document.getElementById("unit_c").value;
      var unit_address_c = document.getElementById("unit_address_c").value;
      var unit_phone_c = document.getElementById("unit_phone_c").value;

      var company_designation = document.getElementById("company_designation").value;
      var company_name = document.getElementById("company_name").value;
      var company_address = document.getElementById("company_address").value;
      var company_phone = document.getElementById("company_phone").value;

      var plate_number = document.getElementById("plate_number").value;
      var color = document.getElementById("color").value;
      var maker = document.getElementById("maker").value;
      var motor_number = document.getElementById("motor_number").value;
      var model = document.getElementById("model").value;
      var chassis_number = document.getElementById("chassis_number").value;
      var year_model = document.getElementById("year_model").value;
      var rp_plate_number = document.getElementById("rp_plate_number").value;

      var or_file = document.getElementById("uploaded_or_file_name").value;
      var cr_file = document.getElementById("uploaded_cr_file_name").value;
      var dos_file = document.getElementById("uploaded_dos_file_name").value;
      var car_file = document.getElementById("image_number").value;
      var id_file = document.getElementById("uploaded_id_file_name").value;


      filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      if(lname_x.length == 0){
         iziToast.error({title: 'Error', message: 'Please input Lastname!', });     
         return;
      }
      if(fname_x.length == 0){
         iziToast.error({title: 'Error', message: 'Please input Firstname!', });     
         return;
      }
      if(mname_x.length == 0){
         iziToast.error({title: 'Error', message: 'Please input Middlename!', });     
         return;
      }

      if(address_x.length == 0){
         iziToast.error({title: 'Error', message: 'Please input your Complete address!', });     
         return;
      }

      if (!filter.test(email_x)) {
         iziToast.error({title: 'Error', message: 'Please input valid Email address!', });     
         return;
      }

      if(phoneInput.getNumber().length == 0){
         iziToast.error({title: 'Error', message: 'Please input valid Phone number!', });     
         return;
      }

      if(bday_x.length == 0){
         iziToast.error({title: 'Error', message: 'Please input your date of birth!', });     
         return;
      }
      if(e.selectedIndex == 0){
         iziToast.error({title: 'Error', message: 'Please select Decal type!', });     
         return;
      }

      if(profile_x.length == 0){
         iziToast.error({title: 'Error', message: 'Please upload your 2x2 picture!!', });     
         return;
      }

      if(e.selectedIndex == 1 && current_step == 1){
         if(bos_m.selectedIndex == 0){
            iziToast.error({title: 'Error', message: 'Please select Branch of Service!', });     
            return;
         }
         if(rank_m.selectedIndex == 0){
            iziToast.error({title: 'Error', message: 'Please select your rank!', });     
            return;
         }
         if(date_enlisted_m.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your date of Enlistment/Commission!', });     
            return;
         }
         if(date_retired_m.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your date of Retirement!', });     
            return;
         }
         if(serial_number_m.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Serial Number!', });     
            return;
         }
         if(designation_m.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Designation/Office!', });     
            return;
         }
         if(unit_m.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Unit!', });     
            return;
         }
         if(unit_address_m.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Unit Address!', });     
            return;
         }
         if(unit_phone_m.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Unit Phone Number!', });     
            return;
         }
      }


      if(e.selectedIndex == 2 && current_step == 1){
         if(bos_c.selectedIndex == 0){
            iziToast.error({title: 'Error', message: 'Please select Branch of Service!', });     
            return;
         }
         if(date_employed_c.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your date of Employment!', });     
            return;
         }
         if(date_retired_c.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your date of Retirement!', });     
            return;
         }
         if(serial_number_c.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your CIV Number!', });     
            return;
         }
         if(designation_c.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Designation/Office!', });     
            return;
         }
         if(unit_c.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Unit!', });     
            return;
         }
         if(unit_address_c.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Unit Address!', });     
            return;
         }
         if(unit_phone_c.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Unit Phone Number!', });     
            return;
         }
      }

      if(e.selectedIndex == 3 && current_step == 1){
         if(company_designation.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Designation/Office!', });     
            return;
         }
         if(company_name.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Company Name!', });     
            return;
         }
         if(company_address.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Company Address!', });     
            return;
         }
         if(company_phone.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Company Phone Number!', });     
            return;
         }
      }

      if(current_step == 2){
         if(plate_number.length == 0){
            iziToast.error({title: 'Error', message: 'Please input your Plate No.!', });     
            return;
         }
         if(color.length == 0){
            iziToast.error({title: 'Error', message: 'Please input color of your Car/Motorcycle!', });     
            return;
         }  
         if(maker.length == 0){
            iziToast.error({title: 'Error', message: 'Please input Car/Motocycle Manufacturer!', });     
            return;
         }
         if(motor_number.length == 0){
            iziToast.error({title: 'Error', message: 'Please input Motor No.!', });     
            return;
         }
         if(model.length == 0){
            iziToast.error({title: 'Error', message: 'Please input Model!', });     
            return;
         }
         if(chassis_number.length == 0){
            iziToast.error({title: 'Error', message: 'Please input Chassis No.!', });     
            return;
         }
         if(year_model.length == 0){
            iziToast.error({title: 'Error', message: 'Please input Year Model!', });     
            return;
         }
         if(rp_plate_number.length == 0){
            iziToast.error({title: 'Error', message: 'Please input RP Plate No./CS STICKER!', });     
            return;
         }
      }

      
      if(current_step == 3){
         if(or_file.length == 0){
            iziToast.error({title: 'Error', message: 'Please upload Vihecle OR!', });     
            return;
         }
         if(cr_file.length == 0){
            iziToast.error({title: 'Error', message: 'Please upload Vihecle CR!', });     
            return;
         }
         if(dos_file.length == 0){
            iziToast.error({title: 'Error', message: 'Please upload Vihecle Deed of Sale!', });     
            return;
         }
      }

      if(current_step == 4){
         if(car_file != 3){
            iziToast.error({title: 'Error', message: 'Please upload 3 Sides of Vihecle!', });     
            return;
         }
         if(id_file.length == 0){
            iziToast.error({title: 'Error', message: 'Please upload Valid ID!', });     
            return;
         }
      }
    
    
       current_step++;
       let previous_step = current_step - 1;
       if(( current_step > 0) && (current_step <= stepCount)){
         prevBtn.classList.remove('d-none');
         prevBtn.classList.add('d-inline-block');
         step[current_step].classList.remove('d-none');
         step[current_step].classList.add('d-block');
         step[previous_step].classList.remove('d-block');
         step[previous_step].classList.add('d-none');
         if (current_step == stepCount){
           submitBtn.classList.remove('d-none');
           submitBtn.classList.add('d-inline-block');
           nextBtn.classList.remove('d-inline-block');
           nextBtn.classList.add('d-none');
         }
       } else {
         if(current_step > stepCount){
             form.onsubmit = () => { return true }
         }
       }
     progress((100 / stepCount) * current_step);
     });
 
 
    prevBtn.addEventListener('click', () => {
      if(current_step > 0){
         current_step--;
         let previous_step = current_step + 1; 
         prevBtn.classList.add('d-none');
         prevBtn.classList.add('d-inline-block');
         step[current_step].classList.remove('d-none');
         step[current_step].classList.add('d-block')
         step[previous_step].classList.remove('d-block');
         step[previous_step].classList.add('d-none');
         if(current_step < stepCount){
            submitBtn.classList.remove('d-inline-block');
            submitBtn.classList.add('d-none');
            nextBtn.classList.remove('d-none');
            nextBtn.classList.add('d-inline-block');
            prevBtn.classList.remove('d-none');
            prevBtn.classList.add('d-inline-block');
         } 
      }
 
      if(current_step == 0){
         prevBtn.classList.remove('d-inline-block');
         prevBtn.classList.add('d-none');
      }
     progress((100 / stepCount) * current_step);
    });
 
 
 /*submitBtn.addEventListener('click', () => {
     preloader.classList.add('d-block');
 
     const timer = ms => new Promise(res => setTimeout(res, ms));
 
     timer(3000)
       .then(() => {
            bodyElement.classList.add('loaded');
       }).then(() =>{
           step[stepCount].classList.remove('d-block');
           step[stepCount].classList.add('d-none');
           prevBtn.classList.remove('d-inline-block');
           prevBtn.classList.add('d-none');
           submitBtn.classList.remove('d-inline-block');
           submitBtn.classList.add('d-none');
           succcessDiv.classList.remove('d-none');
           succcessDiv.classList.add('d-block');
       })
       
 });*/
 