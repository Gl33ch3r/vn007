<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <link rel="icon" type="image/png" href="<?php echo ICO ?>">
    <title><?php echo APP;  ?></title>   
    <link rel="stylesheet" href="../css/container.css" type='text/css'/>
    <link rel="stylesheet" href="../css/loading.css" type='text/css'/>
    <link rel="stylesheet" href="../assets/css/font.nunito.css" type='text/css'/>
    <script type="text/javascript" src="../js/jquery.min.js"></script>
    <link rel="stylesheet" href="../css/all.css" type='text/css'/>
    <link rel="stylesheet" href="../css/bootstrap.min.css" type='text/css'/>
    <link rel="stylesheet" href="../dist/css/iziToast.min.css" type='text/css'/>
    <script type="text/javascript" src="../js/loading.js"></script>
  </head>
    <body>