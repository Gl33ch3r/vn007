
<?php
header("Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'none'; font-src 'none'; connect-src 'none'; img-src 'none'; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none'; frame-ancestors 'none'; form-action 'none';");
include_once 'includes/csrf.php';
session_start();
if(!isset($_COOKIE['user_c']) && !isset($_SESSION['email'])){
  header('Location: /login');
}
include_once 'includes/config.php';
include_once 'includes/functions.php';
include_once 'includes/constant.php';
$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);
if(MAINTENANCE == "1"){
	header("Location: /maintenance");
	return;
}
$mysqli = db_connect($config);
$responseProfile = array();

if(!$csrf->validate('profile')) {
  $responseProfile["error"] = true;
  $responseProfile["msg"] = "CSRF: Verification has been unsuccessful";
  echo json_encode($responseProfile);
  return;
}

$email = mysqli_real_escape_string($mysqli, $_SESSION["email"]);
$response =  loginAccount($mysqli, $email);

if($response['error']){
  $responseProfile["error"] = true;
  $responseProfile["msg"] = "Problem occured while saving data...";
  echo json_encode($responseProfile);
  return; 
}

$profile          = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['uploaded_profile_file_name'], ENT_QUOTES, 'UTF-8'));
$lastname         = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['lastname'], ENT_QUOTES, 'UTF-8'));
$firstname        = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['firstname'], ENT_QUOTES, 'UTF-8'));
$middlename       = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['middlename'], ENT_QUOTES, 'UTF-8'));
$address          = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['address'], ENT_QUOTES, 'UTF-8'));
$mobile           = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['phone'], ENT_QUOTES, 'UTF-8'));
$birthdate        = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['birthdate'], ENT_QUOTES, 'UTF-8'));

$classification   = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['classification'], ENT_QUOTES, 'UTF-8'));

$dependent_of   = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['dependent_of'], ENT_QUOTES, 'UTF-8'));
$bos            = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['bos'], ENT_QUOTES, 'UTF-8'));
$rank           = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['rank'], ENT_QUOTES, 'UTF-8'));
$date_enlisted  = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['date_enlisted'], ENT_QUOTES, 'UTF-8'));
$date_retired   = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['date_retired'], ENT_QUOTES, 'UTF-8'));
$serial_number  = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['serial_number'], ENT_QUOTES, 'UTF-8'));
$designation    = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['designation'], ENT_QUOTES, 'UTF-8'));
$unit           = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['unit'], ENT_QUOTES, 'UTF-8'));
$unit_mobile    = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['unit_mobile'], ENT_QUOTES, 'UTF-8'));
$unit_address   = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['unit_address'], ENT_QUOTES, 'UTF-8'));


$responseUser = updateUserProfile($mysqli, $email, $lastname, $firstname, $middlename, $address, $mobile,  $birthdate, $profile, $dependent_of, $bos, $rank, $date_enlisted, $date_retired, $serial_number, $designation, $unit, $unit_address, $unit_mobile, $classification);
if($responseUser['error']){
    $responseProfile["error"] = true;
    $responseProfile["msg"] = "Problem occured while saving data...";
    echo json_encode($responseProfile);
    return; 
}

$responseProfile["error"] = false;
$responseProfile["msg"] = "You successfully update your profile account";
echo json_encode($responseProfile);
?>