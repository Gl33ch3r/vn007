<?php
session_start();
if(!isset($_GET['id'])){
    echo '<script>window.location="../404"</script>';
}
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$userid =  mysqli_real_escape_string($mysqli, $_GET["id"]);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['id']);
  include_once '../includes/header.login.location.php';
  return;
}

$responseAccount =  getUserByID($mysqli, $userid);
if($responseAccount['error']){
    header('Location: ../404');
    return;
}
include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
<div class="wrapper">
    <?php include "../includes/navbar-admin.php" ?>
	<?php include "../includes/sidebar-admin.php"; ?>
    <div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<div class="card" >
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Profile Account of <?php echo $responseAccount["firstname"] ?></h4>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6 mx-auto">
                                            <div class="form-group" id="select_file_support">
                                                    <div class="profile-picture text-center">
                                                        <div class="avatar avatar-xxxl">
                                                            <a id="photoviewer" href="<?php echo $responseAccount['profile_pic']; ?>">
                                                                <img src="<?php echo $responseAccount['profile_pic']; ?>" alt="..." id="profile_pic" class="avatar-img rounded-circle">
                                                            </a> 
                                                        </div>
                                                    </div>
                                                    
                                            </div>
											<div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <label for="lastname">Lastname</label>
                                                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Enter Lastname" value="<?php echo $responseAccount['lastname']; ?>" disabled>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="firstname">Firstname</label>
                                                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Enter Firstname" value="<?php echo $responseAccount['firstname']; ?>" disabled>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="middlename">Middlename</label>
                                                        <input type="text" class="form-control" id="middlename" name="middlename" placeholder="Enter Middlename" value="<?php echo $responseAccount['middlename']; ?>" disabled>
                                                    </div>
                                                </div>
                                            </div>
                                           
											<div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="phone">Mobile Number</label>
                                                        <input class="form-control" placeholder="9xxxxxxxxx" id="phone" name="phone" type="phone" onkeypress="return onlyNumberKey(event)" maxlength="13"  value="<?php echo $responseAccount['mobile']; ?>" disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="birthdate">Birthdate</label>
                                                        <input class="form-control" placeholder="DD/MM/YYYY" onkeypress="return handleEnter(this, event)" id="birthdate" style="color-scheme: dark;" name="birthdate" type="date" value="<?php echo $responseAccount['birthdate']; ?>" disabled>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
												<label for="address">Complete Address</label>
												<textarea type="text" class="form-control" id="address" name="address" placeholder="Enter Complete Address" disabled><?php echo $responseAccount['address']; ?> </textarea>
											</div>
                                            <div class="form-group">
												<label for="classification">Select Personnel Classification</label>
												<select class="form-control" onchange="handleSelectChange(event)" name="classification" id="classification" disabled>
                                                <?php $type = getAllClassification($mysqli, $responseAccount['classification']);
                                                foreach ($type as $value){
                                                        echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                } ?>
												</select>
											</div>
                                            <div id="active">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="bos_a">Branch of Service</label>
                                                            <select class="form-control" name="bos_a" id="bos_a" disabled>
                                                            <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                            foreach ($type as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="rank_a">Select Rank</label>
                                                            <select class="form-control" name="rank_a" id="rank_a" disabled>
                                                            <?php $ranks = getAllRanks($mysqli, $responseAccount['rank']);
                                                            foreach ($ranks as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['rank'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="date_enlisted_a">Date Enlisted</label>
                                                            <input class="form-control"  placeholder="dd/mm/yyyy" onkeypress="return handleEnter(this, event)"  value="<?php echo $responseAccount['date_enlisted'] ?>" id="date_enlisted_a" style="color-scheme: dark;" name="date_enlisted_a" type="date" disabled>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="date_retired_a">Date Retired</label>
                                                            <input class="form-control"  placeholder="dd/mm/yyyy" onkeypress="return handleEnter(this, event)" value="<?php echo $responseAccount['date_retired'] ?>" id="date_retired_a" style="color-scheme: dark;" name="date_retired_a" type="date" disabled>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="serial_number_a">Serial Number</label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $responseAccount['serial_number'] ?>" id="serial_number_a" name="serial_number_a" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="designation_a">Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_a" name="designation_a" value="<?php echo $responseAccount['designation'] ?>" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_a">Unit Assignment</label>
                                                    <input type="text" class="form-control" id="unit_a" name="unit_a" value="<?php echo $responseAccount['unit_name'] ?>" placeholder="Enter Unit Assignment" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_mobile_a">Unit Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" onkeypress="return onlyNumberKey(event)" maxlength="13" value="<?php echo $responseAccount['unit_mobile'] ?>" id="unit_mobile_a" name="unit_mobile_a" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_address_a">Unit Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_a" name="unit_address_a" placeholder="Enter Unit Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="retired" style="display:none;">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="bos_b">Branch of Service</label>
                                                            <select class="form-control" name="bos_b" id="bos_b" disabled>
                                                            <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                            foreach ($type as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="rank_b">Select Rank</label>
                                                            <select class="form-control" name="rank_b" id="rank_b" disabled>
                                                            <?php $ranks = getAllRanks($mysqli, $responseAccount['rank']);
                                                            foreach ($ranks as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['rank'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group" id="reservist_sn" style="display:none">
                                                    <label for="serial_number_b">Serial Number</label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $responseAccount['serial_number'] ?>" id="serial_number_b" name="serial_number_b" type="text" disabled>
                                                </div>

                                                <div class="form-group" id="des">
                                                    <label for="designation_b">Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_b" value="<?php echo $responseAccount['designation'] ?>" name="designation_b" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_b">Company Name</label>
                                                    <input type="text" class="form-control" id="unit_b" name="unit_b" value="<?php echo $responseAccount['unit_name'] ?>" placeholder="Enter Company Name" disabled>
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_b">Company Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $responseAccount['unit_mobile'] ?>"  onkeypress="return onlyNumberKey(event)" maxlength="13" id="unit_mobile_b" name="unit_mobile_b" type="text" disabled>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_b">Company Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_b" name="unit_address_b" placeholder="Enter Company Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="chr" style="display:none;">
                                                <div class="form-group">
                                                    <label for="bos_c">Branch of Service</label>
                                                    <select class="form-control" name="bos_c" id="bos_c" disabled>
                                                    <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                        foreach ($type as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                        } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="date_enlisted_c">Date Employed</label>
                                                            <input class="form-control"  placeholder="dd/mm/yyyy" value="<?php echo $responseAccount['date_enlisted'] ?>" onkeypress="return handleEnter(this, event)"  id="date_enlisted_c" style="color-scheme: dark;" name="date_enlisted_c" type="date" disabled>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="date_retired_c">Date Retired</label>
                                                            <input class="form-control"  placeholder="dd/mm/yyyy" value="<?php echo $responseAccount['date_retired'] ?>" onkeypress="return handleEnter(this, event)"  id="date_retired_c" style="color-scheme: dark;" name="date_retired_c" type="date" disabled>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group" id="chrid">
                                                    <label for="serial_number_c">CivHR Number</label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $responseAccount['serial_number'] ?>" id="serial_number_c" name="serial_number_c" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="designation_c">Designation/Office</label>
                                                    <input type="text" class="form-control" value="<?php echo $responseAccount['designation'] ?>" id="designation_c" name="designation_c" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_c">Unit Assignment</label>
                                                    <input type="text" class="form-control"  value="<?php echo $responseAccount['unit_name'] ?>" id="unit_c" name="unit_c" placeholder="Enter Unit Assignment" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_mobile_c">Unit Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $responseAccount['unit_mobile'] ?>" onkeypress="return onlyNumberKey(event)" maxlength="13" id="unit_mobile_c" name="unit_mobile_c" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_address_c">Unit Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_c" name="unit_address_c" placeholder="Enter Unit Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="dependent_active" style="display:none;">
                                                <div class="form-group">
                                                    <label for="dependent_of_d">Dependent of?</label>
                                                    <input class="form-control"  placeholder="Dependent of?" value="<?php echo $responseAccount['dependent_of'] ?>" id="dependent_of_d" name="dependent_of_d" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="bos_d">Branch of Service</label>
                                                    <select class="form-control" name="bos_d" id="bos_d" disabled>
                                                    <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                        foreach ($type as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                        } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="serial_number_d">Serial Number</label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $responseAccount['serial_number'] ?>" id="serial_number_d" name="serial_number_d" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="designation_d">Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_d" value="<?php echo $responseAccount['designation'] ?>" name="designation_d" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_d">Unit Assignment</label>
                                                    <input type="text" class="form-control" id="unit_d"  value="<?php echo $responseAccount['unit_name'] ?>" name="unit_d" placeholder="Enter Unit Assignment" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_mobile_d">Unit Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $responseAccount['unit_mobile'] ?>" onkeypress="return onlyNumberKey(event)" maxlength="13" id="unit_mobile_d" name="unit_mobile_d" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_address_d">Unit Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_d" name="unit_address_d" placeholder="Enter Unit Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="dependent_retired" style="display:none;">
                                                <div class="form-group">
                                                    <label for="dependent_of_e">Dependent of?</label>
                                                    <input class="form-control"  placeholder="Dependent of?" value="<?php echo $responseAccount['dependent_of'] ?>" id="dependent_of_e" name="dependent_of_e" type="text" disabled>
                                                </div>
                                                <div class="form-group">
                                                    <label for="bos_e">Branch of Service</label>
                                                    <select class="form-control" name="bos_e" id="bos_e" disabled>
                                                    <?php $type = getAllBos($mysqli, $responseAccount['bos']);
                                                        foreach ($type as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                        } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group" id="des">
                                                    <label for="designation_e">Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_e" value="<?php echo $responseAccount['designation'] ?>" name="designation_e" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_e">Company Name</label>
                                                    <input type="text" class="form-control" id="unit_e" value="<?php echo $responseAccount['unit_name'] ?>" name="unit_e" placeholder="Enter Company Name" disabled>
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_e">Company Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $responseAccount['unit_mobile'] ?>"  onkeypress="return onlyNumberKey(event)" maxlength="13" id="unit_mobile_e" name="unit_mobile_e" type="text" disabled>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_e">Company Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_e" name="unit_address_e" placeholder="Enter Company Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                            </div>
                                            <div id="others" style="display:none;">
                                                <div class="form-group" id="des">
                                                    <label for="designation_f">Designation/Office</label>
                                                    <input type="text" class="form-control" id="designation_f" value="<?php echo $responseAccount['designation'] ?>" name="designation_f" placeholder="Enter Designation/Office" disabled>
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_f">Company Name</label>
                                                    <input type="text" class="form-control" id="unit_f" value="<?php echo $responseAccount['unit_name'] ?>" name="unit_f" placeholder="Enter Company Name" disabled>
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_f">Company Mobile Number</label>
                                                    <input class="form-control" placeholder="639xxxxxxxxx"  value="<?php echo $responseAccount['unit_mobile'] ?>" onkeypress="return onlyNumberKey(event)" maxlength="13" id="unit_mobile_f" name="unit_mobile_f" type="text" disabled>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_f">Company Address</label>
                                                    <textarea type="text" class="form-control" id="unit_address_f" name="unit_address_f" placeholder="Enter Company Address" disabled><?php echo $responseAccount['unit_address'] ?></textarea>
                                                </div>
                                               
                                            </div>
                                            <br>
										</div>
								    </div>
                                </div>
                            </div>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
        </div>
		
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
    <script src="../dist/js/iziToast.min.js"></script>

<script src="../js/upload.js"></script>
<script>
        
     $(document).ready(function(){
        var gallery = $('#photoviewer').simpleLightbox();
     });
    var active = document.getElementById("active");
    var retired = document.getElementById("retired");
    var chr = document.getElementById("chr");
    var chrid = document.getElementById("chrid");
    var dep_a = document.getElementById("dependent_active");
    var dep_r = document.getElementById("dependent_retired");
    var others = document.getElementById("others");

    var reservist_sn = document.getElementById("reservist_sn");


    var value = "<?php echo $responseAccount['classification'] ?>";

    if(value == "1"){
        active.style.display = "";
        retired.style.display = "none";
        chr.style.display = "none";
        dep_a.style.display = "none";
        dep_r.style.display = "none";
        others.style.display = "none";
    }else  if(value == "2"){
        active.style.display = "none";
        retired.style.display = "";
        reservist_sn.style.display= "none";
        chr.style.display = "none";
        dep_a.style.display = "none";
        dep_r.style.display = "none";
        others.style.display = "none";
    }else  if(value == "3"){
        active.style.display = "none";
        retired.style.display = "";
        reservist_sn.style.display= "";
        chr.style.display = "none";
        dep_a.style.display = "none";
        dep_r.style.display = "none";
        others.style.display = "none";
    }else  if(value == "4"){
        active.style.display = "none";
        retired.style.display = "none";
        chr.style.display = "";
        chrid.style.display = "";
        dep_a.style.display = "none";
        dep_r.style.display = "none";
        others.style.display = "none";
    }else  if(value == "5"){
        active.style.display = "none";
        retired.style.display = "none";
        chr.style.display = "";
        chrid.style.display = "none";
        dep_a.style.display = "none";
        dep_r.style.display = "none";
        others.style.display = "none";
    }else  if(value == "6"){
        active.style.display = "none";
        retired.style.display = "none";
        chr.style.display = "none";
        dep_a.style.display = "";
        dep_r.style.display = "none";
        others.style.display = "none";
    }else  if(value == "7"){
        active.style.display = "none";
        retired.style.display = "none";
        chr.style.display = "none";
        dep_a.style.display = "none";
        dep_r.style.display = "";
        others.style.display = "none";
    }else{
        active.style.display = "none";
        retired.style.display = "none";
        chr.style.display = "none";
        dep_a.style.display = "none";
        dep_r.style.display = "none";
        others.style.display = "";
    }
    function handleSelectChange(event) {
        var selectElement = event.target;
        var value = selectElement.value;
        if(value == "1"){
            active.style.display = "";
            retired.style.display = "none";
            chr.style.display = "none";
            dep_a.style.display = "none";
            dep_r.style.display = "none";
            others.style.display = "none";
        }else  if(value == "2"){
            active.style.display = "none";
            retired.style.display = "";
            reservist_sn.style.display= "none";
            chr.style.display = "none";
            dep_a.style.display = "none";
            dep_r.style.display = "none";
            others.style.display = "none";
        }else  if(value == "3"){
            active.style.display = "none";
            retired.style.display = "";
            reservist_sn.style.display= "";
            chr.style.display = "none";
            dep_a.style.display = "none";
            dep_r.style.display = "none";
            others.style.display = "none";
        }else  if(value == "4"){
            active.style.display = "none";
            retired.style.display = "none";
            chr.style.display = "";
            chrid.style.display = "";
            dep_a.style.display = "none";
            dep_r.style.display = "none";
            others.style.display = "none";
        }else  if(value == "5"){
            active.style.display = "none";
            retired.style.display = "none";
            chr.style.display = "";
            chrid.style.display = "none";
            dep_a.style.display = "none";
            dep_r.style.display = "none";
            others.style.display = "none";
        }else  if(value == "6"){
            active.style.display = "none";
            retired.style.display = "none";
            chr.style.display = "none";
            dep_a.style.display = "";
            dep_r.style.display = "none";
            others.style.display = "none";
        }else  if(value == "7"){
            active.style.display = "none";
            retired.style.display = "none";
            chr.style.display = "none";
            dep_a.style.display = "none";
            dep_r.style.display = "";
            others.style.display = "none";
        }else{
            active.style.display = "none";
            retired.style.display = "none";
            chr.style.display = "none";
            dep_a.style.display = "none";
            dep_r.style.display = "none";
            others.style.display = "";
        }
    }

    function onlyNumberKey(evt) {
      var ASCIICode = (evt.which) ? evt.which : evt.keyCode
      if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
          return false;
      return true;
  }

  function displayNotification(title1, msg, state, icon){
        if(state == 'success'){
            iziToast.success({title: title1, message: msg, onClosing: function () {},});
        }else{
            iziToast.error({title: title1, message: msg, onClosing: function () {},});
        }
       
       return;
    }


    function handleEnter (field, event) {
    var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
        if (keyCode == 13) {
            var i;
            for (i = 0; i < field.form.elements.length; i++)
                if (field == field.form.elements[i])
                    break;
            i = (i + 1) % field.form.elements.length;
            field.form.elements[i].focus();
            return false;
        } else
            return true;
    }      

    $('#profileForm').submit(function() {
        if ($.trim($("#firstname").val()) === "" || $.trim($("#lastname").val()) === "" || $.trim($("#lastname").val()) === "" || $.trim($("#middlename").val()) === "" || $.trim($("#address").val()) === "" || $.trim($("#birthdate").val()) === "" || $.trim($("#phone").val()) === "")  {
            return false;
        }

        if(document.getElementById("classification").value=="1"){
            if ($.trim($("#bos_a").val()) === "" || $.trim($("#rank_a").val()) === "" || $.trim($("#date_enlisted_a").val()) === "" || $.trim($("#date_retired_a").val()) === "" || $.trim($("#serial_number_a").val()) === "" || $.trim($("#designation_a").val()) === "" || $.trim($("#unit_a").val()) === "" || $.trim($("#unit_mobile_a").val()) === "" || $.trim($("#unit_address_a").val()) === "")  {
                return false;
            }
        }else if(document.getElementById("classification").value=="2"){
            if ($.trim($("#bos_b").val()) === "" || $.trim($("#rank_b").val()) === "" || $.trim($("#designation_b").val()) === "" || $.trim($("#unit_b").val()) === "" || $.trim($("#unit_mobile_b").val()) === "" || $.trim($("#unit_address_b").val()) === "")  {
                return false;
            }
        }else if(document.getElementById("classification").value=="3"){
            if ($.trim($("#bos_b").val()) === "" || $.trim($("#rank_b").val()) === "" || $.trim($("#serial_number_b").val()) === "" || $.trim($("#designation_b").val()) === "" || $.trim($("#unit_b").val()) === "" || $.trim($("#unit_mobile_b").val()) === "" || $.trim($("#unit_address_b").val()) === "")  {
                return false;
            }
        }else if(document.getElementById("classification").value=="4"){
            if ($.trim($("#bos_c").val()) === "" || $.trim($("#date_enlisted_c").val()) === "" || $.trim($("#date_retired_c").val()) === "" || $.trim($("#serial_number_c").val()) === "" || $.trim($("#designation_c").val()) === "" || $.trim($("#unit_c").val()) === "" || $.trim($("#unit_mobile_c").val()) === "" || $.trim($("#unit_address_c").val()) === "")  {
                return false;
            }
        }else if(document.getElementById("classification").value=="5"){
            if ($.trim($("#bos_c").val()) === "" || $.trim($("#date_enlisted_c").val()) === "" || $.trim($("#date_retired_c").val()) === "" || $.trim($("#designation_c").val()) === "" || $.trim($("#unit_c").val()) === "" || $.trim($("#unit_mobile_c").val()) === "" || $.trim($("#unit_address_c").val()) === "")  {
                return false;
            }
        }else if(document.getElementById("classification").value=="6"){
            if ($.trim($("#dependent_of_d").val()) === ""  || $.trim($("#bos_d").val()) === ""  || $.trim($("#serial_number_d").val()) === "" || $.trim($("#designation_d").val()) === "" || $.trim($("#unit_d").val()) === "" || $.trim($("#unit_mobile_d").val()) === "" || $.trim($("#unit_address_d").val()) === "")  {
                return false;
            }
        }else if(document.getElementById("classification").value=="7"){
            if ($.trim($("#dependent_of_e").val()) === ""  || $.trim($("#bos_e").val()) === "" || $.trim($("#designation_e").val()) === "" || $.trim($("#unit_e").val()) === "" || $.trim($("#unit_mobile_e").val()) === "" || $.trim($("#unit_address_e").val()) === "")  {
                return false;
            }
        }else{
            if ($.trim($("#designation_f").val()) === "" || $.trim($("#unit_f").val()) === "" || $.trim($("#unit_mobile_f").val()) === "" || $.trim($("#unit_address_f").val()) === "")  {
                return false;
            }
        }
    });
    
  
    var submitBtn = document.getElementById('submit-btn');
    submitBtn.addEventListener('click', () => {
        var fname = document.getElementById("firstname").value;
        var lname = document.getElementById("lastname").value;
        var mname = document.getElementById("middlename").value;
        var address = document.getElementById("address").value;
        var birthdate = document.getElementById("birthdate").value;
        var phone = document.getElementById("phone").value;
      
        if(lname.length == 0) {
            displayNotification("Error", "Please enter Lastname!", "danger", "fas fa-exclamation-triangle");
            return;
        } 
        if(fname.length == 0) {
            displayNotification("Error", "Please enter Firstname!", "danger", "fas fa-exclamation-triangle");
            return;
        } 
        if(mname.length == 0) {
            displayNotification("Error", "Please enter Middlename!", "danger", "fas fa-exclamation-triangle");
            return;
        } 
        if(address.length == 0) {
            displayNotification("Error", "Please enter Complete Address!", "danger", "fas fa-exclamation-triangle");
            return;
        } 

        if(phone.length == 0) {
            displayNotification("Error", "Please enter Mobile Number!", "danger", "fas fa-exclamation-triangle");
            return;
        } 

        if(birthdate.length == 0) {
            displayNotification("Error", "Please enter Birthdate!", "danger", "fas fa-exclamation-triangle");
            return;
        } 

        if(document.getElementById("classification").value=="1"){
            if ($.trim($("#date_enlisted_a").val()) === "")  {
                displayNotification("Error", "Please enter your Enlistment Date!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#date_retired_a").val()) === "")  {
                displayNotification("Error", "Please enter your Retirement Date!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#serial_number_a").val()) === "")  {
                displayNotification("Error", "Please enter your Serial Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#designation_a").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_a").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_mobile_a").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_address_a").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
        }else if(document.getElementById("classification").value=="2"){
            if ($.trim($("#designation_b").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_b").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_mobile_b").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_address_b").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
        }else if(document.getElementById("classification").value=="3"){
            if ($.trim($("#serial_number_b").val()) === "")  {
                displayNotification("Error", "Please enter your Serial Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#designation_b").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_b").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_mobile_b").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_address_b").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
        }else if(document.getElementById("classification").value=="4"){
            if ($.trim($("#date_enlisted_c").val()) === "")  {
                displayNotification("Error", "Please enter your Employment Date!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#date_retired_c").val()) === "")  {
                displayNotification("Error", "Please enter your Retirement Date!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#serial_number_c").val()) === "")  {
                displayNotification("Error", "Please enter your CivHR Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#designation_c").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_mobile_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_address_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
        }else if(document.getElementById("classification").value=="5"){
            if ($.trim($("#date_enlisted_c").val()) === "")  {
                displayNotification("Error", "Please enter your Employment Date!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#date_retired_c").val()) === "")  {
                displayNotification("Error", "Please enter your Retirement Date!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#designation_c").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_mobile_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_address_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
        }else if(document.getElementById("classification").value=="6"){
          
            if ($.trim($("#dependent_of_d").val()) === "")  {
                displayNotification("Error", "Please enter Dependent of?", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#serial_number_d").val()) === "")  {
                displayNotification("Error", "Please enter your Serial Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#designation_d").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_d").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_mobile_d").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_address_d").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
        }else if(document.getElementById("classification").value=="7"){
            if ($.trim($("#dependent_of_e").val()) === "")  {
                displayNotification("Error", "Please enter Dependent of?", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#designation_e").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_e").val()) === "")  {
                displayNotification("Error", "Please enter your Company Name", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_mobile_e").val()) === "")  {
                displayNotification("Error", "Please enter your Company Mobile Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_address_e").val()) === "")  {
                displayNotification("Error", "Please enter your Company Address!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
        }else{
            if ($.trim($("#designation_f").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_f").val()) === "")  {
                displayNotification("Error", "Please enter your Company Name!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_mobile_f").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Company Number!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
            if ($.trim($("#unit_address_f").val()) === "")  {
                displayNotification("Error", "Please enter your Company Address!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
        }
       
    });
</script>
<script>
<?php
    if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
        $state 	= $_SESSION["state"];
        $msg 	= $_SESSION["msg"];
        $title 	= $_SESSION["title"];

        if($state == "success"){
            $icon = "fas fa-check";
        }else if($state == "warning"){
            $icon = "fas fa-exclamation-circle";
        }else if($state == "danger"){
            $icon = "fas fa-exclamation-triangle";
        }?>
            displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>", "<?php echo $icon; ?>");
<?php } ?>
</script>

<?php
    unset($_SESSION["state"]);
    unset($_SESSION["msg"]);
    unset($_SESSION["title"]);
?>
<script src="../js/search.js"></script>
</body>
</html>