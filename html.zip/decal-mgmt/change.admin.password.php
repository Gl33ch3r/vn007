<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$response = array();
$newpassword    = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['newpassword'], ENT_QUOTES, 'UTF-8'));
$id    = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['id'], ENT_QUOTES, 'UTF-8'));
if(!empty($newpassword) || !empty($id)){
    $encrypted_newpassword = sha1(md5(sha1($newpassword)));
    $responsePassword = changeAdminPassword($mysqli, $id , $encrypted_newpassword);
    if(!$responsePassword['error']){
        $response['error'] = false;
    }else{
        $response['error'] = true;
    }
}else{
    $response['error'] = true;
}
echo json_encode($response);
?>