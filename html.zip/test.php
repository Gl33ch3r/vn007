<?php
date_default_timezone_set('America/Manila');



// Open PHPMailer
/*use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'repo/phpmailer/src/PHPMailer.php';
require 'repo/phpmailer/src/SMTP.php';
require 'repo/phpmailer/src/Exception.php';

// Settings
$mail = new PHPMailer();
$mail->SetLanguage("en"); 
$mail->IsSMTP(); 
$mail->Host = "mail.nav.ph";
$mail->SMTPSecure = "tls";
$mail->Port = 25; 
$mail->SMTPAuth = true;
$mail->Username = "jconadera@nav.ph"; // don't hide, please
$mail->Password = "BloodSec1968!!!!!"; // don't hide, please
$mail->setFrom('edecal@navy.ph', 'eDecal System');
$mail->AddAddress("jconadera@gmail.com", "");
$mail->IsHTML = true ;
$mail->Subject = "Test Subject";
$mail->Body = "Test Message" ;
$mail->AltBody = $mensagem ;
$mail->SMTPDebug = 2;

if(!$mail->Send())
 { 
 echo "Sending error"; // Error message
 echo "Mailer Error: " . $mail->ErrorInfo; 
 } 
 else {
	 echo "Email Sent"; // Success message
 }
 */
require_once "otp.php";
$responseTXT = sendTextMessage("09980804178",  "test");

echo json_encode($responseTXT);