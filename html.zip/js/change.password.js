$(document).ready(function(){
    function displayNotification(title1, msg, state, icon){
        if(state == 'success'){
            iziToast.success({title: title1, message: msg, onClosing: function () {},});
        }else{
            iziToast.error({title: title1, message: msg, onClosing: function () {},});
        }
       
       return;
    }
    $('#changePasswordForm').submit(function() {
        if ($.trim($("#oldpassword").val()) === "" || $.trim($("#password").val()) === "" || $.trim($("#cpassword").val()) === "")  {
            return false;
        }
    });

    $('#changePasswordForm').submit(function() {
        if ($.trim($("#cpassword").val()) != $.trim($("#password").val()))  {
            displayNotification("Error", "Password do not match!", "danger", "fas fa-exclamation-triangle");
            return false;
        }
    });
    
  
    $("#submit-btn").click(function(){
        var oldpassword = $("#oldpassword").val();
        var csrftoken = $("#csrftoken").val();
        var password = $("#password").val();
        var cpassword = $("#cpassword").val();
      
        if(oldpassword.length == 0) {
            displayNotification("Error", "Please enter Current Password!", "danger", "fas fa-exclamation-triangle");
            return;
        } 
        if(password.length == 0) {
            displayNotification("Error", "Please enter New Password!", "danger", "fas fa-exclamation-triangle");
            return;
        } 
        if(cpassword.length == 0) {
            displayNotification("Error", "Please enter Confirm Password!", "danger", "fas fa-exclamation-triangle");
            return;
        } 
       
        $.ajax({
            type: "POST",
            url: "process-changepass.php",
            data: { 'password': password, 'cpassword': cpassword, 'csrftoken': csrftoken, 'oldpassword': oldpassword},
            dataType : 'json',
            cache: false,
            success: function(response) {
                if(response.error){
                    iziToast.error({title: 'OK', message: response.msg, onClosing: function () {},});
                }else{
                    swal({
                        allowOutsideClick: false,
                        closeOnClickOutside: false,
                        title: "Good job!",
                        text: response.msg,
                        icon: "success",
                        timer: 2000,
                        showConfirmButton: false
                      }).then(() => { window.location = response.location });
                }
            },
            failure: function (response) {
                swal("Internal Error","Oops, something went wrong.", "error")
              }
        });
      });
    $('#logout-btn-nav').click(function(e) {
        swal({
            title: 'Are you sure?',
            text: 'It will automatically logout your account!',
            type: 'warning',
            buttons:{
                confirm: {
                    text : 'yes',
                    className : 'btn btn-success'
                },
                cancel: {
                    visible: true,
                    className: 'btn btn-danger',
                    text : 'No'
                }
            }
        }).then((confirm) => {
            if (confirm) {
                window.location='/logout' 
            } else {
                swal.close();
            }
        });
    });

    $('#logout-btn').click(function(e) {
        swal({
            title: 'Are you sure?',
            text: 'It will automatically logout your account!',
            type: 'warning',
            buttons:{
                confirm: {
                    text : 'yes',
                    className : 'btn btn-success'
                },
                cancel: {
                    visible: true,
                    className: 'btn btn-danger',
                    text : 'No'
                }
            }
        }).then((confirm) => {
            if (confirm) {
                window.location='/logout' 
            } else {
                swal.close();
            }
        });
    });

    var allCount = $("#count-all");
    if($("#request-li").hasClass('active')){
        allCount.css("display","none");
    }
    $('#toggle-btn').click(function(e) {
        if(!$("#base").hasClass('show')){
            allCount.css("display","none");
        } else {
            allCount.css("display","");
        }
    });
});