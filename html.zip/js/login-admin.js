$(document).ready(function () {
    
    $('#loginAdminForm').submit(function() {
        if ($.trim($("#username").val()) === "" || $.trim($("#password").val()) === ""  || $.trim($("#captcha").val()) === "") {
            return false;
        }
    });


    $(function() {
        $("#captcha").keyup(function() {
            this.value = this.value.toLocaleUpperCase();
        });
        $("#captcha").attr("maxlength", 6);
    });
    

    $('#username').on('keypress', function (e) {
        var ingnore_key_codes = [34, 39];
        if ($.inArray(e.which, ingnore_key_codes) >= 0) {
            e.preventDefault();
        } 
    });
        
    $('#password').on('keypress', function (e) {
        var ingnore_key_codes = [34, 39];
        if ($.inArray(e.which, ingnore_key_codes) >= 0) {
            e.preventDefault();
        } 
    });
        
    $('#captcha').on('keypress', function (e) {
        var ingnore_key_codes = [34, 39];
        if ($.inArray(e.which, ingnore_key_codes) >= 0) {
            e.preventDefault();
        }
    });
    $("#refresh-btn").click(function(){
        $("#captcha-image").attr("src", '../captcha.php?' + Date.now());
    });
    $("#username").keyup(function () {
        validate();
    });
    $("#password").keyup(function () {
        validate();
    });
    $("#captcha").keyup(function () {
        validate();
    });

    $("#login-admin").click(function () {
        if ($.trim($("#username").val()) === "" || $.trim($("#password").val()) === "" || $.trim($("#captcha").val()) === "") {
            return false;
        }
        var csrftoken = $("#csrftoken").val();
        var username = $("#username").val();
        var password = $("#password").val();
        var captcha = $("#captcha").val();
        $.ajax({
            type: "POST",
            url: "process-login.admin.php",
            data: { 'username': username, 'password': password, 'captcha': captcha, 'csrftoken': csrftoken },
            dataType : 'json',
            cache: false,
            success: function(response) {
                if(response.error){
                    $("#captcha").val("");
                    $("#captcha-image").attr("src", '../captcha.php?' + Date.now());
                    iziToast.error({title: 'OK', message: response.msg, onClosing: function () {},});
                }else{
                    window.location=response.location; 
                }
            },
            failure: function (response) {
                swal("Internal Error","Oops, something went wrong.", "error")
               }
        });
    });


    $("#pass-button").on('click', function(event) {
        event.preventDefault();
        if($('#password').attr("type") == "text"){
            $('#password').attr('type', 'password');
            $('#pass-button').attr("src","/img/hidden.png");
        }else if($('#password').attr("type") == "password"){
            $('#password').attr('type', 'text');
            $('#pass-button').attr("src","/img/eye.png");
        }
    });
})

function validate() {
    let username = $("#username").val();
    let password = $("#password").val();
    let captcha = $("#captcha").val();
    if (username != "" && password != "" && captcha != "") {
        $("#username").css("border","none");
        $("#password").css("border","none");
        $("#captcha").css("border","none");
        $("#login-admin").prop('disabled', false);
        return true;
    } 
    if (username == "") {
        $("#username").css("border","1px solid red");
        $("#login-admin").prop('disabled', true);
    }else{
        $("#username").css("border","none");
    }

    if (password == "") {
        $("#password").css("border","1px solid red");
        $("#login-admin").prop('disabled', true);
    }else{
        $("#password").css("border","none");
    }

    if (captcha == "") {
        $("#captcha").css("border","1px solid red");
        $("#login-admin").prop('disabled', true);
    }else{
        $("#captcha").css("border","none");
    }
}
