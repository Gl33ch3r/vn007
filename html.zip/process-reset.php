<?php
header("Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'none'; font-src 'none'; connect-src 'none'; img-src 'none'; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none'; frame-ancestors 'none'; form-action 'none';");
include_once 'includes/csrf.php';
include_once 'includes/session.php';
include_once 'includes/constant.php';
require_once 'includes/config.php';
require_once "includes/functions.php";

$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);

if(MAINTENANCE == "1"){
  header("Location: maintenance");
  return;
}

$mysqli = db_connect($config);
$responseReset = array();

if (!$csrf->validate('reset')) {
    $responseReset['msg']       = "CSRF: Verification has been unsuccessful";
    $responseReset['error']     = true; 
    echo json_encode($responseReset);
    return;
}

if(!isset($_POST['password'])  && !isset($_POST['cpassword']) && !isset($_POST['email']) && !isset($_POST['code'])){
    $responseReset['msg']       = "Error Occurred while logging in!";
    $responseReset['error']     = true; 
    echo json_encode($responseReset);
    return;
}

$password   = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['password'], ENT_QUOTES, 'UTF-8'));
$cpassword  = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['cpassword'], ENT_QUOTES, 'UTF-8'));
$email      = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8'));
$code       = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['code'], ENT_QUOTES, 'UTF-8'));

$number             = preg_match('@[0-9]@', $password);
$uppercase          = preg_match('@[A-Z]@', $password);
$lowercase          = preg_match('@[a-z]@', $password);
$specialChars       = preg_match('@[^\w]@', $password);

if(!resetCheck($mysqli, $email, $code)){
    $responseReset['msg']       = "Error occured while changing password.";
    $responseReset['error']     = true; 
    echo json_encode($responseReset);
    return;
}


if(strlen($password) < 8 || !$number || !$uppercase || !$lowercase || !$specialChars) {
    $msg = "Password must be at least 8 characters in length and must contain at least one number, one upper case letter, one lower case letter and one special character.";
    $responseReset['msg']       = $msg;
    $responseReset['error']     = true;
    echo json_encode($responseReset);
    return;
}

if($password != $cpassword){
    $responseReset['msg']        = "Password do not match!";
    $responseReset['error']      = true;
    echo json_encode($responseReset);
    return;
}


$encrypted_password = sha1(md5(sha1($password)));
$response = updateUserAccount($mysqli, $email, $code, $encrypted_password);
if($response['error']){
    $responseReset['msg']       = "Error occured while changing password.";
    $responseReset['error']     = true; 
    echo json_encode($responseReset);
    return;
}
$responseReset["location"]      = "login";
$responseReset['msg']           = "You have successfully change your password.";
$responseReset['error']         = false;
echo json_encode($responseReset);
?>