var max_uploads_profile = 1
var max_uploads_support = 3
var max_uploads_sides = 2
function get_extension( url ) {
  return url.split(/[#?]/)[0].split('.').pop().trim();
}
  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = 'upload.php';
    $('#profileupload').fileupload({
        url: url,
        dataType: 'html',
        done: function (e, data) {
            if(data['result'] == 'FAILED'){
              iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
            }else if(data['result'] == 'INVALID_MIME'){
              iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
            }else if(data['result'] == 'FAILED_FILE_TOO_BIG'){
              iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
            }else{
                $('#uploaded_profile_file_name').val(data['result']);
                document.getElementById("profile").src = data['result'];
            }
            $('#progress_profile .progress-bar').css(
                'width',
                0 + '%'
            ).show();
            $.each(data.result.files, function (index, file) {
                $('<p/>').text(file.name).appendTo('#files_profile');
            });
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_support .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });



  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = 'upload.php';
    $('#sitelogoupload').fileupload({
        url: url,
        dataType: 'html',
        done: function (e, data) {
            if(data['result'] == 'FAILED'){
              iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
            }else if(data['result'] == 'INVALID_MIME'){
              iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
            }else if(data['result'] == 'FAILED_FILE_TOO_BIG'){
              iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
            }else{
                $('#uploaded_images_sitelogo').append('<div class="uploaded_sitelogo avatar avatar-xxxl"> <input type="text" value="'+data['result']+'" name="uploaded_sitelogo_name" id="uploaded_sitelogo_name" hidden> <a target="_blank" id="photoviewer_sitelogo" href="'+data['result']+'"><img src="'+data['result']+'" class="avatar-img rounded"/></a> <a class="img_rmv btn"><i class="fas fa-trash-alt" style="font-size:18px;color:red"></i></a> </div>');
                if($('.uploaded_sitelogo').length >= max_uploads_profile){
                    $('#select_file_sitelogo').hide();
                }else{
                    $('#select_file_sitelogo').show();
                }
            }
            $('#progress_sitelogo .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_sitelogo .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_sitelogo" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_sitelogo').length >= max_uploads_profile){
        $('#select_file_sitelogo').hide();
    }else{
        $('#select_file_sitelogo').show();
    }
  });



  $(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = 'upload.php';
    $('#favicoupload').fileupload({
        url: url,
        dataType: 'html',
        done: function (e, data) {
            if(data['result'] == 'FAILED'){
              iziToast.error({title: 'Error', message: 'Server error, Error occured while uploading...', });     
            }else if(data['result'] == 'INVALID_MIME'){
              iziToast.error({title: 'Error', message: 'Invalid file format, Only accepts gif, png, jpg, jpeg...', });     
            }else if(data['result'] == 'FAILED_FILE_TOO_BIG'){
              iziToast.error({title: 'Error', message: 'File File Size is very big...', });     
            }else{
                $('#uploaded_images_favico').append('<div class="uploaded_favico avatar avatar-xxl"> <input type="text" value="'+data['result']+'" name="uploaded_favico_name" id="uploaded_favico_name" hidden> <a target="_blank" id="photoviewer_favico" href="'+data['result']+'"><img src="'+data['result']+'" class="avatar-img rounded"/></a> <a class="img_rmv btn"><i class="fas fa-trash-alt" style="font-size:18px;color:red"></i></a> </div>');
                if($('.uploaded_favico').length >= max_uploads_profile){
                    $('#select_file_favico').hide();
                }else{
                    $('#select_file_favico').show();
                }
            }
            $('#progress_favico .progress-bar').css(
                'width',
                0 + '%'
            ).show();
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress_favico .progress-bar').css(
                'width',
                progress + '%'
            );
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
  });
  $( "#uploaded_images_favico" ).on( "click", ".img_rmv", function() {
    $(this).parent().remove();
    if($('.uploaded_favico').length >= max_uploads_profile){
        $('#select_file_favico').hide();
    }else{
        $('#select_file_favico').show();
    }
  });