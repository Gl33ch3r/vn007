  <!----- START CLAIM MODAL ------>
  <div class="modal fade" id="searchModal" role="dialog" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header no-bd">
				<h3 class="modal-title" style="color:black;">
					Search Vechicle
				</h3>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
            <form>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Plate No.</label>
                                <input id="plate_number" placeholder="Enter Plate No." name="plate_number" type="text" class="form-control" style="color-scheme: dark;" required>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer no-bd">
                    <button type="button" id="search" class="btn btn-primary">Search</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </form>
		</div>
	</div>
</div>

<div id="searchResultModal" class="modal fade" role="dialog" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 700px">
      <div id="search-content" class="modal-content"></div>
    </div>
</div>