<?php
session_start();
require_once('includes/config.php');
require_once "includes/functions.php";
$mysqli = db_connect($config);
$ipaddress = getPublicIP();
$response = loginAccount($mysqli, $_SESSION['email']);
$responseLogs = addLogs($mysqli, $response['id'], "logout", "", $ipaddress, "0");

if(!$responseLogs["error"]){
    session_destroy();
    unset($_SESSION['email']);
    setcookie("user_c", "", time() - 3600);
    header("Location: /");
}else{
    session_destroy();
    unset($_SESSION['email']);
    setcookie("user_c", "", time() - 3600);
    header("Location: /");
}
?>