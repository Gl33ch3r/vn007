<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/anticsrf.php';
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['$id']);
  include_once '../includes/header.login.location.php';
}
include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
<div class="wrapper">
        <?php include "../includes/navbar-admin.php" ?>
		<?php include "../includes/sidebar-admin.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<form class="card" id="profileAdminForm" method="post" action="save.profile.php">
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Edit Admin Account</h4>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
								
										<div class="col-md-5 mx-auto">	
                                        <div class="form-group">
                                        </div> 
                                            <div class="form-group" id="select_file_support">
													<div class="profile-picture text-center">
                                                        <div class="avatar avatar-xxxl">
                                                            <a target="_blank" id="photoviewer" href="<?php echo $response['profile']; ?>">
                                                                <img src="<?php echo $response['profile']; ?>" alt="..." id="profile" class="avatar-img rounded-circle">
                                                            </a> 
                                                            <div class="inner">
                                                                <input id="profileupload" class="inputfile" type="file" name="profile_file" accept="image/x-png, image/gif, image/jpeg">
                                                                <label>
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
                                                                        <path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
                                                                    </svg>

                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <br>
                                                    <div id="progress_profile" class="progress" style="display: none;">
                                                    <br>
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    <div id="files_profile" class="files"></div>
                                                    <input type="text" name="uploaded_profile_file_name" id="uploaded_profile_file_name" hidden>
                                            </div>
											<br>
                                            <div class="form-group">
												<label for="account_name">Account Name</label>
												<input type="text" class="form-control" id="account_name" name="account_name" placeholder="Enter Account Name" value="<?php echo $response['account_name']; ?>" >
											</div>
											<br>
											<br>
											<div class="card-action">
                                                <div class="d-flex justify-content-center">
                                                	<button type="submit" id="submit-btn"  class="btn btn-success btn-round pr-5 pl-5 ml-1 mr-1"><i class="far fa-save"></i>  Save</button>
                                            	</div>
											</div>
                                            <div class="form-group">
                                                <br>
                                                <br>
                                            </div>
										</div>
								</div>
                            </form>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "../includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<script src="../dist/js/iziToast.min.js"></script>
    <script src="js/upload.admin.js"></script>
    <script>
		$(document).ready(function(){
            var gallery = $('#photoviewer').simpleLightbox();
        });
		
        
	  	function displayNotification(title1, msg, state, icon){
            if(state == 'success'){
                iziToast.success({title: title1, message: msg, onClosing: function () {},});
            }else{
                iziToast.error({title: title1, message: msg, onClosing: function () {},});
            }
           
           return;
        }


        function handleEnter (field, event) {
        var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
            if (keyCode == 13) {
                var i;
                for (i = 0; i < field.form.elements.length; i++)
                    if (field == field.form.elements[i])
                        break;
                i = (i + 1) % field.form.elements.length;
                field.form.elements[i].focus();
                return false;
            } else
                return true;
        }      

        $('#profileAdminForm').submit(function() {
            if ($.trim($("#account_name").val()) === "")  {
                return false;
            }
        });
        
      
        var submitBtn = document.getElementById('submit-btn');
        submitBtn.addEventListener('click', () => {
            var account_name = document.getElementById("account_name").value;
            if(account_name.length == 0) {
                displayNotification("Error", "Please enter Account Name...", "danger", "fas fa-exclamation-triangle");
                return;
            } 
        });
    </script>
<script>
	<?php
		if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
			$state 	= $_SESSION["state"];
			$msg 	= $_SESSION["msg"];
			$title 	= $_SESSION["title"];

			if($state == "success"){
				$icon = "fas fa-check";
			}else if($state == "warning"){
				$icon = "fas fa-exclamation-circle";
			}else if($state == "danger"){
				$icon = "fas fa-exclamation-triangle";
			}?>
				displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>", "<?php echo $icon; ?>");
	<?php } ?>
	</script>

	<?php
			unset($_SESSION["user"]);
			unset($_SESSION["account_name"]);
			unset($_SESSION["profile"]);
			unset($_SESSION["email"]);
			unset($_SESSION["state"]);
			unset($_SESSION["msg"]);
			unset($_SESSION["title"]);
	?>
	<script src="../js/search.js"></script>
</body>
</html>