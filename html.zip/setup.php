<?php
include_once 'includes/csrf.php';
session_start();
if(!isset($_COOKIE['user_c']) && !isset($_SESSION['email'])){
    header('Location: /login');
}
include_once 'includes/config.php';
include_once 'includes/functions.php';
include_once 'includes/constant.php';
$csrf = new CSRF(
    'session-hashes', 
    'csrftoken',       
    5*60,
    256
  );
if(MAINTENANCE == "1"){
    header("Location: /maintenance");
    return;
}
$mysqli = db_connect($config);
$email = $_SESSION["email"];
$response =  loginAccount($mysqli, $email);
if($response['error']){
  session_destroy();
  unset($_SESSION['email']);
  setcookie("user_c", "", time() - 3600);
  header('Location: /404');
  return;
}

$profile        = $response["profile_pic"];
$bos            = $response["bos"];
$rank           = $response["rank"];
$classification = $response["classification"];



$firstname      =  $response["firstname"];
$lastname       =  $response["lastname"];
$email          =  $response["email"];
$middlename     =  $response["middlename"];
$mobile         =  $response["mobile"];
$birthdate      =  $response["birthdate"];
$address        =  $response["address"];
$date_enlisted  =  $response["date_enlisted"];
$date_retired   =  $response["date_retired"];
$serial_number  =  $response["serial_number"];
$designation    =  $response["designation"];
$unit_name      =  $response["unit_name"];
$unit_mobile    =  $response["unit_mobile"];
$unit_address   =  $response["unit_address"];
$$dependent_of  =  $response["dependent_of"];


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self' 'nonce-87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a92' 'nonce-8db0369dff542ac448aa8f9e8ceaece603fe3de4ea9afbea19a46f4b87f4959b' 'nonce-87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d'; style-src 'self' 'nonce-87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d'; font-src 'self'; connect-src 'self'; img-src 'self' data:; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none';"/>
	<title><?php echo APP . " - " . $email ?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="assets/img/icon.ico" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script src="/assets/js/plugin/webfont/webfont.min.js"></script>
	<script src="/assets/js/plugin/webfont/webfont.load.js"></script>

	
	<!-- CSS Files -->
    <link rel="stylesheet" href="/css/loading.css" type='text/css'/>
	<link rel="stylesheet" href="/assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="/assets/css/atlantis.min.css"/>

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="/assets/css/demo.css"/>
    <link rel="stylesheet" href="/dist/css/iziToast.min.css"/>
	<link rel='stylesheet' href='/simplelightbox/dist/simple-lightbox.min.css' type='text/css'/>
	
	<script type="text/javascript" src="/js/jquery.min.js"></script>
	<script type="text/javascript" src="/dist/assets/jquery-file-upload/js/vendor/jquery.ui.widget.js"></script>
    <script type="text/javascript" src="/dist/assets/jquery-file-upload/js/jquery.iframe-transport.js"></script>
    <script type="text/javascript" src="/dist/assets/jquery-file-upload/js/jquery.fileupload.js"></script>
    <script type="text/javascript" src="/simplelightbox/dist/simple-lightbox.jquery.min.js"></script>
    <script type="text/javascript" src="/js/loading.js"></script>
	
</head>
<body data-background-color="dark">
	<div class="wrapper">
        <div class="main-header">
            <!-- Logo Header -->
            <div class="logo-header" data-background-color="dark">
                
                <a href="" class="logo">
                    <img src="<?php echo SITE_LOGO; ?>" alt="<?php echo APP; ?>" height="50" class="navbar-brand">
                </a>
                <button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                        <i class="icon-menu"></i>
                    </span>
                </button>
                <button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
            </div>
            <!-- End Logo Header -->

            <!-- Navbar Header -->
            <nav class="navbar navbar-header navbar-expand-lg" data-background-color="dark">
                
                <div class="container-fluid">
                    <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
                        
                        <li class="nav-item dropdown hidden-caret">
                            <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false">
                                <div class="avatar-sm">
                                    <img src="<?php echo $profile; ?>" alt="<?php  echo $firstname ." ". $lastname; ?>" class="avatar-img rounded-circle">
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-user animated fadeIn">
                                <div class="dropdown-user-scroll scrollbar-outer">
                                    <li>
                                        <div class="user-box">
                                            <div class="avatar-lg"><img src="<?php echo $profile; ?>" alt="image profile" class="avatar-img rounded"></div>
                                            <div class="u-text">
                                                <h4><?php echo $firstname ." ". $lastname;  ?></h4>
                                                <p class="text-muted"><?php echo $email; ?></p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" id="logout-btn-nav" href="#">Logout</a>
                                    </li>
                                </div>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
            <!-- End Navbar -->
        </div>

		<div class="main">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $email; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<form class="card" id="profileForm">
                            <?=$csrf->input('setup');?>
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Setup Profile</h4>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
                                        <div class="col-md-5 mx-auto">
                                            <div class="form-group" id="select_file_support">
                                                <div class="profile-picture text-center">
                                                    <div class="avatar avatar-xxxl">
                                                        <a id="photoviewer" href="<?php echo $profile; ?>">
                                                            <img src="<?php echo $profile; ?>" alt="<?php  echo $firstname ." ". $lastname; ?>" id="profile_pic" class="avatar-img rounded-circle">
                                                        </a> 
                                                        <div class="inner">
                                                            <input id="profileupload" class="inputfile" type="file" name="profile_file" accept="image/x-png, image/gif, image/jpeg">
                                                            <label><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path></svg></label>
                                                        </div>
                                                    </div>
                                                </div>
                                                    <br>
                                                    <div id="progress_profile" class="progress nd"></div>
                                                    <br>
                                                    <div class="progress-bar progress-bar-success"></div>
                                                    <div id="files_profile" class="files"></div>
                                                    <input type="text" name="uploaded_profile_file_name" id="uploaded_profile_file_name" hidden>
                                            </div>
											<div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <label for="lastname">Lastname <span class="tip-warning">Required</span></label>
                                                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Enter Lastname" value="<?php echo $lastname; ?>" >
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="firstname">Firstname <span class="tip-warning">Required</span></label>
                                                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Enter Firstname" value="<?php echo $firstname; ?>" >
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="middlename">Middlename</label>
                                                        <input type="text" class="form-control" id="middlename"  name="middlename" placeholder="Enter Middlename" value="<?php echo $middlename; ?>" >
                                                    </div>
                                                </div>
                                            </div>
                                           
											<div class="form-group">
                                                
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="phone">Mobile Number <span class="tip-warning">Required</span></label>
                                                            <div class="input-icon">
                                                                <span class="input-icon-addon">
                                                                    <i class="icon-phone"></i>
                                                                </span>
                                                                <input class="form-control" placeholder="639xxxxxxxxx" id="phone" name="phone" type="phone"  maxlength="12"  value="<?php echo $mobile; ?>">
                                                            </div>
                                                       </div>
                                                    <div class="col-lg-6">
                                                        <label for="birthdate">Birthdate <span class="tip-warning">Required</span></label>
                                                        <div class="input-icon">
                                                            <span class="input-icon-addon">
                                                                <i class="icon-present"></i>
                                                            </span>
                                                            <input class="form-control ddcs" placeholder="DD/MM/YYYY" id="birthdate"  name="birthdate" type="date" value="<?php echo $birthdate; ?>">
                                                        </div>
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
												<label for="address">Complete Address <span class="tip-warning">Required</span></label>
                                                <div class="input-icon">
                                                    <span class="input-icon-addon">
                                                        <i class="icon-location-pin"></i>
                                                    </span>
                                                    <textarea type="text" class="form-control" id="address" name="address" placeholder="Enter Complete Address" ><?php echo $address; ?> </textarea>
                                                </div>
												
											</div>
                                            <div class="form-group">
												<label for="classification">Select Personnel Classification <span class="tip-warning">Required</span></label>
												<select class="form-control"  name="classification" id="classification">
                                                <?php $type = getAllClassification($mysqli, $classification);
                                                foreach ($type as $value){
                                                        echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                } ?>
												</select>
											</div>
                                            <div id="active">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="bos_a">Branch of Service <span class="tip-warning">Required</span></label>
                                                            <select class="form-control" name="bos_a" id="bos_a">
                                                            <?php $type = getAllBos($mysqli, $bos);
                                                            foreach ($type as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="rank_a">Select Rank <span class="tip-warning">Required</span></label>
                                                            <select class="form-control" name="rank_a" id="rank_a">
                                                            <?php $ranks = getAllRanks($mysqli, $rank);
                                                            foreach ($ranks as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['rank'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="date_enlisted_a">Date Enlisted <span class="tip-warning">Required</span></label>
                                                            <input class="form-control ddcs"  placeholder="dd/mm/yyyy" value="<?php echo $date_enlisted ?>" id="date_enlisted_a" name="date_enlisted_a" type="date">
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="date_retired_a">Date Retired <span class="tip-warning">Required</span></label>
                                                            <input class="form-control ddcs"  placeholder="dd/mm/yyyy" value="<?php echo $date_retired ?>" id="date_retired_a"  name="date_retired_a" type="date">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="serial_number_a">Serial Number <span class="tip-warning">Required</span></label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $serial_number ?>" id="serial_number_a" name="serial_number_a" type="text">
                                                </div>
                                                <div class="form-group">
                                                    <label for="designation_a">Designation/Office <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-briefcase"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="designation_a" name="designation_a" value="<?php echo $designation ?>" placeholder="Enter Designation/Office">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_a">Unit Assignment <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-grid"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="unit_a" name="unit_a" value="<?php echo $unit_name ?>" placeholder="Enter Unit Assignment">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_mobile_a">Unit Mobile Number <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-phone"></i>
                                                        </span>
                                                        <input class="form-control" placeholder="639xxxxxxxxx" maxlength="12" value="<?php echo $unit_mobile ?>" id="unit_mobile_a" name="unit_mobile_a" type="text">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_address_a">Unit Address <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-location-pin"></i>
                                                        </span>
                                                        <textarea type="text" class="form-control" id="unit_address_a" name="unit_address_a" placeholder="Enter Unit Address"><?php echo $unit_address ?></textarea>
                                                    </div> 
                                                </div>
                                            </div>
                                            <div id="retired" class="nd">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="bos_b">Branch of Service <span class="tip-warning">Required</span></label>
                                                            <select class="form-control" name="bos_b" id="bos_b">
                                                            <?php $type = getAllBos($mysqli, $bos);
                                                            foreach ($type as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="rank_b">Select Rank <span class="tip-warning">Required</span></label>
                                                            <select class="form-control" name="rank_b" id="rank_b">
                                                            <?php $ranks = getAllRanks($mysqli, $rank);
                                                            foreach ($ranks as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['rank'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group" id="des">
                                                    <label for="designation_b">Last Designation/Office <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-briefcase"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="designation_b" value="<?php echo $designation ?>" name="designation_b" placeholder="Enter Last Designation/Office">
                                                    </div> 
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_b">Last Unit Assignment <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-grid"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="unit_b" name="unit_b" value="<?php echo $unit_name ?>" placeholder="Enter Last Unit Assignment">
                                                    </div>
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_b">Last Unit Mobile Number <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-phone"></i>
                                                        </span>
                                                        <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $unit_mobile ?>"  maxlength="12" id="unit_mobile_b" name="unit_mobile_b" type="text">
                                                    </div>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_b">Last Unit Address <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-location-pin"></i>
                                                        </span>
                                                        <textarea type="text" class="form-control" id="unit_address_b" name="unit_address_b" placeholder="Enter Last Unit Address"><?php echo $unit_address ?></textarea>
                                                    </div> 
                                                </div>
                                            </div>
                                            <div id="reservist" class="nd">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="bos_r">Branch of Service <span class="tip-warning">Required</span></label>
                                                            <select class="form-control" name="bos_r" id="bos_r">
                                                            <?php $type = getAllBos($mysqli, $bos);
                                                            foreach ($type as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="rank_r">Select Rank <span class="tip-warning">Required</span></label>
                                                            <select class="form-control" name="rank_r" id="rank_r">
                                                            <?php $ranks = getAllRanks($mysqli, $rank);
                                                            foreach ($ranks as $value){
                                                                    echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['rank'].'</option>';
                                                            } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group" id="reservist_sn">
                                                    <label for="serial_number_r">Serial Number <span class="tip-warning">Required</span></label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $serial_number ?>" id="serial_number_r" name="serial_number_r" type="text">
                                                </div>

                                                <div class="form-group" id="des">
                                                    <label for="designation_r">Designation/Office <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-briefcase"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="designation_r" value="<?php echo $designation ?>" name="designation_r" placeholder="Enter Designation/Office">
                                                    </div> 
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_r">Company Name <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-grid"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="unit_r" name="unit_r" value="<?php echo $unit_name ?>" placeholder="Enter Company Name">
                                                    </div>
                                                    
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_r">Company Mobile Number <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-phone"></i>
                                                        </span>
                                                        <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $unit_mobile ?>"  maxlength="12" id="unit_mobile_r" name="unit_mobile_r" type="text">
                                                    </div>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_r">Company Address <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-location-pin"></i>
                                                        </span>
                                                        <textarea type="text" class="form-control" id="unit_address_r" name="unit_address_r" placeholder="Enter Company Address"><?php echo $unit_address ?></textarea>
                                                    </div> 
                                                </div>
                                            </div>

                                            <div id="chr" class="nd">
                                                <div class="form-group">
                                                    <label for="bos_c">Branch of Service <span class="tip-warning">Required</span></label>
                                                    <select class="form-control" name="bos_c" id="bos_c">
                                                    <?php $type = getAllBos($mysqli, $bos);
                                                        foreach ($type as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                        } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="date_enlisted_c">Date Employed <span class="tip-warning">Required</span></label>
                                                            <input class="form-control ddcs"  placeholder="dd/mm/yyyy" value="<?php echo $date_enlisted ?>" id="date_enlisted_c"  name="date_enlisted_c" type="date">
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="date_retired_c">Date Retired <span class="tip-warning">Required</span></label>
                                                            <input class="form-control ddcs"  placeholder="dd/mm/yyyy" value="<?php echo $date_retired ?>" id="date_retired_c"  name="date_retired_c" type="date">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group" id="chrid">
                                                    <label for="serial_number_c">CivHR Number <span class="tip-warning">Required</span></label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $serial_number ?>" id="serial_number_c" name="serial_number_c" type="text">
                                                </div>
                                                <div class="form-group">
                                                    <label for="designation_c">Designation/Office <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-briefcase"></i>
                                                        </span>
                                                        <input type="text" class="form-control" value="<?php echo $designation ?>" id="designation_c" name="designation_c" placeholder="Enter Designation/Office">
                                                    </div> 
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_c">Unit Assignment <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-grid"></i>
                                                        </span>
                                                        <input type="text" class="form-control" value="<?php echo $unit_name ?>" id="unit_c" name="unit_c" placeholder="Enter Unit Assignment">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_mobile_c">Unit Mobile Number <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-phone"></i>
                                                        </span>
                                                        <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $unit_mobile ?>" maxlength="12" id="unit_mobile_c" name="unit_mobile_c" type="text">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_address_c">Unit Address <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-location-pin"></i>
                                                        </span>
                                                        <textarea type="text" class="form-control" id="unit_address_c" name="unit_address_c" placeholder="Enter Unit Address"><?php echo $unit_address ?></textarea>
                                                    </div> 
                                                </div>
                                            </div>
                                            <div id="dependent_active" class="nd">
                                                <div class="form-group">
                                                    <label for="dependent_of_d">Dependent of? <span class="tip-warning">Required</span></label>
                                                    <input class="form-control"  placeholder="Dependent of?" value="<?php echo $dependent_of ?>" id="dependent_of_d" name="dependent_of_d" type="text">
                                                </div>
                                                <div class="form-group">
                                                    <label for="bos_d">Branch of Service <span class="tip-warning">Required</span></label>
                                                    <select class="form-control" name="bos_d" id="bos_d">
                                                    <?php $type = getAllBos($mysqli, $bos);
                                                        foreach ($type as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                        } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="serial_number_d">Serial Number <span class="tip-warning">Required</span></label>
                                                    <input class="form-control"  placeholder="xxxxxxx" value="<?php echo $serial_number ?>" id="serial_number_d" name="serial_number_d" type="text">
                                                </div>
                                                <div class="form-group">
                                                    <label for="designation_d">Designation/Office <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-briefcase"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="designation_d" value="<?php echo $designation ?>" name="designation_d" placeholder="Enter Designation/Office">
                                                    </div> 
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_d">Unit Assignment <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-grid"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="unit_d"  value="<?php echo $unit_name ?>" name="unit_d" placeholder="Enter Unit Assignment">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_mobile_d">Unit Mobile Number <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-phone"></i>
                                                        </span>
                                                        <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $unit_mobile ?>"  maxlength="12" id="unit_mobile_d" name="unit_mobile_d" type="text">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="unit_address_d">Unit Address <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-location-pin"></i>
                                                        </span>
                                                        <textarea type="text" class="form-control" id="unit_address_d" name="unit_address_d" placeholder="Enter Unit Address"> <?php echo $unit_address ?></textarea>
                                                    </div> 
                                                </div>
                                            </div>
                                            <div id="dependent_retired" class="nd">
                                                <div class="form-group">
                                                    <label for="dependent_of_e">Dependent of? <span class="tip-warning">Required</span></label>
                                                    <input class="form-control"  placeholder="Dependent of?" value="<?php echo $dependent_of ?>" id="dependent_of_e" name="dependent_of_e" type="text">
                                                </div>
                                                <div class="form-group">
                                                    <label for="bos_e">Branch of Service <span class="tip-warning">Required</span></label>
                                                    <select class="form-control" name="bos_e" id="bos_e">
                                                    <?php $type = getAllBos($mysqli, $bos);
                                                        foreach ($type as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['name'].'</option>';
                                                        } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group" id="des">
                                                    <label for="designation_e">Designation/Office <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-briefcase"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="designation_e" value="<?php echo $designation ?>" name="designation_e" placeholder="Enter Designation/Office">
                                                    </div> 
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_e">Company Name <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-grid"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="unit_e" value="<?php echo $unit_name ?>" name="unit_e" placeholder="Enter Company Name">
                                                    </div>
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_e">Company Mobile Number <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-phone"></i>
                                                        </span>
                                                        <input class="form-control" placeholder="639xxxxxxxxx" value="<?php echo $unit_mobile ?>" maxlength="12" id="unit_mobile_e" name="unit_mobile_e" type="text">
                                                    </div>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_e">Company Address <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-location-pin"></i>
                                                        </span>
                                                        <textarea type="text" class="form-control" id="unit_address_e" name="unit_address_e" placeholder="Enter Company Address"><?php echo $unit_address ?></textarea>
                                                    </div> 
                                                </div>
                                            </div>
                                            <div id="others" class="nd">
                                                <div class="form-group" id="des">
                                                    <label for="designation_f">Designation/Office <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-briefcase"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="designation_f" value="<?php echo $designation ?>" name="designation_f" placeholder="Enter Designation/Office">
                                                    </div> 
                                                </div>
                                                <div class="form-group" id="ass">
                                                    <label for="unit_f">Company Name <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-grid"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="unit_f" value="<?php echo $unit_name ?>" name="unit_f" placeholder="Enter Company Name">
                                                    </div>
                                                </div>
                                                <div class="form-group" id="mob">
                                                    <label for="unit_mobile_f">Company Mobile Number <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-phone"></i>
                                                        </span>
                                                        <input class="form-control" placeholder="639xxxxxxxxx"  value="<?php echo $unit_mobile ?>" maxlength="12" id="unit_mobile_f" name="unit_mobile_f" type="text">
                                                    </div>
                                                </div>
                                                <div class="form-group" id="add">
                                                    <label for="unit_address_f">Company Address <span class="tip-warning">Required</span></label>
                                                    <div class="input-icon">
                                                        <span class="input-icon-addon">
                                                            <i class="icon-location-pin"></i>
                                                        </span>
                                                        <textarea type="text" class="form-control" id="unit_address_f" name="unit_address_f" placeholder="Enter Company Address"><?php echo $unit_address ?></textarea>
                                                    </div> 
                                                </div>
                                               
                                            </div>
                                            <br>
                                                <div class="card-action">
                                                    <div class="d-flex justify-content-center">
                                                    <button type="button" id="submit-btn" class="btn btn-success btn-round pr-5 pl-5"> <i class="icon-paper-plane"></i> Finish Setup</button>
                                                </div>
                                            </div>
										</div>
								    </div>
                                </div>
                            </form>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>
    
    <div class="overlay"></div>
    </body>
    <script type="module" nonce="87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a92">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/9.14.0/firebase-app.js";
        const firebaseConfig = {
            apiKey: "AIzaSyB2loe0A4XthtInFuACzJUuQweTFvamBuU",
            authDomain: "edecal-ac9a7.firebaseapp.com",
            projectId: "edecal-ac9a7",
            storageBucket: "edecal-ac9a7.appspot.com",
            messagingSenderId: "459894222438",
            appId: "1:459894222438:web:50a367f4ea6b096ec507a7"
        };
        const app = initializeApp(firebaseConfig);
    </script>
    <!--   Core JS Files   -->
	<script src="/assets/js/core/popper.min.js"></script>
	<script src="/assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="/assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="/assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

	<!-- Chart Circle -->
	<script src="/assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="/assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="/assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="/assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

    <!-- Sweet Alert -->
    <script nonce="87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d" type="text/javascript" src="/assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="/assets/js/atlantis.min.js"></script>
    
    <script src="/dist/js/iziToast.min.js"></script>

    <script src="/js/upload.js"></script>
    <script src="/js/setup.js"></script>

   
</html>