<div class="iLGpSw">
    <span>©<?php echo date("Y"); echo " "; echo APP; ?>. All rights reserved.</span>
</div>
