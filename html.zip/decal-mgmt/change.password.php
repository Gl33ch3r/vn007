<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['$id']);
  include_once '../includes/header.login.location.php';
}
include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
	<div class="wrapper">
	<?php include "../includes/navbar-admin.php" ?>
		<?php include "../includes/sidebar-admin.php"; ?>


		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<form class="card" id="changePasswordForm" method="post" action="save.password.php">
							<input type="hidden" name="token" id="token" value="<?php echo $_SESSION["token"]?>"/>
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Change Password</h4>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
										<div class="col-md-5 mx-auto">
											<div class="form-group">
												<label for="oldpassword">Current Password</label>
												<input type="password" class="form-control" id="oldpassword" name="oldpassword" placeholder="Current Password">
											</div>
                                            <div class="form-group">
												<label for="newpassword">New Password</label>
												<input type="password" class="form-control" id="newpassword" name="newpassword" placeholder="New Password">
											</div>
                                            <div class="form-group">
												<label for="confirmpassword">Confirm Password</label>
												<input type="password" class="form-control" id="confirmpassword" name="confirmpassword" placeholder="Confirm New Password">
											</div>
                                        
											<div class="form-group">
												<div class="d-flex justify-content-center">
                                                	<button type="submit" id="submit-btn" class="btn btn-success btn-round pr-5 pl-5"><i class="far fa-save"></i>  Change</button>
                                            	</div>
											</div>
                                            <div class="form-group">
                                                <br>
                                                <br>
                                            </div>
                                        </div>
									</div>
								</div>
                            </form>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>
    

<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
    
    <script src="../dist/js/iziToast.min.js"></script>


    <script>
        

        function onlyNumberKey(evt) {
          var ASCIICode = (evt.which) ? evt.which : evt.keyCode
          if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
              return false;
          return true;
      }

        function displayNotification(title1, msg, state, icon){
            if(state == 'success'){
                iziToast.success({title: title1, message: msg, onClosing: function () {},});
            }else{
                iziToast.error({title: title1, message: msg, onClosing: function () {},});
            }
           
           return;
        }


        function handleEnter (field, event) {
        var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
            if (keyCode == 13) {
                var i;
                for (i = 0; i < field.form.elements.length; i++)
                    if (field == field.form.elements[i])
                        break;
                i = (i + 1) % field.form.elements.length;
                field.form.elements[i].focus();
                return false;
            } else
                return true;
        }  

        $('#changePasswordForm').submit(function() {
            if ($.trim($("#oldpassword").val()) === "" || $.trim($("#newpassword").val()) === "" || $.trim($("#confirmpassword").val()) === "")  {
                return false;
            }
        });

        $('#changePasswordForm').submit(function() {
            if ($.trim($("#confirmpassword").val()) != $.trim($("#newpassword").val()))  {
                displayNotification("Error", "Password do not match!", "danger", "fas fa-exclamation-triangle");
                return false;
            }
        });
        
      
        var submitBtn = document.getElementById('submit-btn');
        submitBtn.addEventListener('click', () => {
            var oldpassword = document.getElementById("oldpassword").value;
            var newpassword = document.getElementById("newpassword").value;
            var confirmpassword = document.getElementById("confirmpassword").value;
          
            if(oldpassword.length == 0) {
                displayNotification("Error", "Please enter Current Password!", "danger", "fas fa-exclamation-triangle");
                return;
            } 
            if(newpassword.length == 0) {
                displayNotification("Error", "Please enter New Password!", "danger", "fas fa-exclamation-triangle");
                return;
            } 
            if(confirmpassword.length == 0) {
                displayNotification("Error", "Please enter Confirm Password!", "danger", "fas fa-exclamation-triangle");
                return;
            } 
           
        });
    </script>
<script>
	<?php
		if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
			$state 	= $_SESSION["state"];
			$msg 	= $_SESSION["msg"];
			$title 	= $_SESSION["title"];

			if($state == "success"){
				$icon = "fas fa-check";
			}else if($state == "warning"){
				$icon = "fas fa-exclamation-circle";
			}else if($state == "danger"){
				$icon = "fas fa-exclamation-triangle";
			}?>
				displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>", "<?php echo $icon; ?>");
	<?php } ?>
	</script>

	<?php
		unset($_SESSION["state"]);
		unset($_SESSION["msg"]);
		unset($_SESSION["title"]);
	?>
	<script src="../js/search.js"></script>
</body>
</html>