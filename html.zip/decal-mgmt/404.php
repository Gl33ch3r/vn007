<?php include_once '/includes/constant.php'; ?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self'; style-src 'self'; font-src 'self'; connect-src 'self'; img-src 'self' data:; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none';"/>
         <link rel="icon" type="image/png" href="<?php echo ICO ?>">
  <title>404 Page Not Found</title>
</head>
<link rel="stylesheet" href="/css/error.css" type='text/css'/>
<html>
<body>
<h1>404</h1>
<div><p>> <span>ERROR CODE</span>: "<i>HTTP 404 Page Not Found</i>"</p>
<p>> <span>ERROR DESCRIPTION</span>: "<i>Page Not Found. The Page You Are Accessing Doesn't Exist On This Server</i>"</p>
<p>> <span>ERROR POSSIBLY CAUSED BY</span>: [<b>written incorrectly, domain name doesn’t exist, website content has been removed, website moved to another URL, invalid configuration, linked incorrectly, external links error, file doesn't exist, directory doesn't exist</b>...]</p>
<p>> <span>HAVE A NICE DAY GL33CH3R :-)</span></p>
</div>
</body>
<script type="text/javascript" src="/js/error.js"></script>
</html>