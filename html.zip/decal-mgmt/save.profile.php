<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id                 = mysqli_real_escape_string($mysqli, $_SESSION['id']);
$profile            = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['uploaded_profile_file_name'], ENT_QUOTES, 'UTF-8'));
$account_name       = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["account_name"], ENT_QUOTES, 'UTF-8'));

$response = loginAdmin($mysqli, $id);
if($response['error']){
    header('Location: ../404');
    return;
  }
$responseAdmin = updateAdminAccount($mysqli, $account_name, $profile, $id);
if(!$responseAdmin['error']){
    $_SESSION["state"]  = "success";
    $_SESSION["title"]  = "Success";
    $_SESSION["msg"]    = "You have successfully updated your account.";
    header("Location: profile.admin.php");
}else{
    $_SESSION["state"]  = "danger";
    $_SESSION["title"]  = "Error";
    $_SESSION["msg"]    = "Problem occured while saving data...";
    header("Location: profile.admin.php");
}
?>