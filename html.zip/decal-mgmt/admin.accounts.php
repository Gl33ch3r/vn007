<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id  = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response["user_role"] == "0"){
    header('Location: ../404');
}
if($response['error']){
  session_destroy();
  unset($_SESSION['id']);
  include_once '../includes/header.login.location.php';
}
include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
	<div class="wrapper">
		<?php include "../includes/navbar-admin.php" ?>
		<?php include "../includes/sidebar-admin.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Admin Accounts</h4>
                                        <a class="btn btn-primary btn-round ml-auto" href="add.admin.account.php">
											<i class="fa fa-plus"></i>
											Add Admin Account
										</a>
									</div>
								</div>
								<div class="card-body">
									<div class="table-responsive">
                                        <table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
                                                    <th>Profile</th>
													<th>Account Name</th>
                                                    <th>Username</th>
                                                    <th>Role</th>
													<th>Status</th>
													<th style="width: 10%">Action</th>
												</tr>
											</thead>
											<tbody>
												<?php
													$responseAccount = getAllAdminAccount($mysqli);
													while($u = mysqli_fetch_array($responseAccount)) {
                                                        $profile           = $u["profile"];
                                                        $account_name      = $u["account_name"];
                                                        $username          = $u["username"];
                                                        $aid               = $u["id"];
                                                        $role              = $u["user_role"];
														$sio               = $u["sio_id"];
														$enabled           = $u["is_enabled"];
														$responseSio	   = getSioName($mysqli, $sio);

                                                        if($role == "1" || $role == "2" || $role == "5"){
															$roleFlag = getRoleName($mysqli, $role)["name"];
														}else{
															$roleFlag = getRoleName($mysqli, $role)["name"]." - ".$responseSio['sio_name'];
														}

														if($enabled == "1"){
															$enabledFlag = "<span class='align-middle' style='color:#31ce36!important; font-weight:700'>Enabled</span>";
														}else if($enabled == "0"){
															$enabledFlag = "<span class='align-middle' style='color:#f25961!important; font-weight:700'>Disabled</span>";
														}
												?>
												<tr>
													<td>
                                                    <div class="profile-picture text-center">
                                                        <div id="photoviewer" class="avatar avatar-xl" style="margin-top: 10px; margin-bottom: 10px;">
															<a target="_blank" href="<?php echo $profile; ?>">
																<img src="<?php echo $profile; ?>" alt="..." id="profile" class="avatar-img rounded">
															</a>
                                                        </div>
                                                    </div>
                                                    </td>
                                                    <td><?php echo $account_name  ?></td>
													<td><?php echo $username ?></td>
                                                    <td><?php echo $roleFlag ?></td>
													<td id="flag_<?php echo $aid ?>"><?php echo $enabledFlag ?></td>
													<td id="action_<?php echo $aid; ?>">
                                                        <?php if($aid != $response["id"]){ ?>
														<div class="form-button-action">
															<a type="button" data-toggle="tooltip" href="edit.admin.account.php?id=<?php echo $aid; ?>" title="" class="btn btn-link btn-primary" data-original-title="Edit">
															    <i class="fa fa-edit"></i>
                                                            </a>
															<?php if($enabled == "1"){ ?>
															<a type="button"  data-toggle="tooltip" onclick="disableUserAdmin('<?php echo $aid; ?>');"  title="" class="btn btn-link btn-danger" data-original-title="Disable User">
																<i  class="fas fa-user-slash"></i>
                                                            </a>
															<?php }else{ ?>
															<a type="button" data-toggle="tooltip" onclick="activateUserAdmin('<?php echo $aid; ?>');"  title="" class="btn btn-link btn-success" data-original-title="Activate User">
																<i  class="fas fa-user-check"></i>
                                                            </a>
															<?php } ?>
															<a type="button" data-toggle="tooltip" onclick="deleteUserAdmin('<?php echo $aid; ?>');" class="btn btn-link btn-danger" data-original-title="Delete">
															    <i class="fas fa-trash-alt"></i>
                                                            </a>
														</div>
                                                        <?php } ?>
													</td>
												</tr>

												<?php } ?>
												
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "../includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>

	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<script src="../dist/js/iziToast.min.js"></script>
	<script >
		

		function viewImage(uid){
			var gallery = $('.col-sm-12 a').simpleLightbox();
		}
           
		function deleteUserAdmin(uid){
			swal({
				text: "Are you sure you want to delete this account?",
				type: 'warning',
				buttons:{
					cancel: {
						visible: true,
						text : 'No, cancel!',
						className: 'btn btn-danger'
					},        			
					confirm: {
						text : 'Yes, delete it!',
						className : 'btn btn-success'
					}
				}
			}).then((willDelete) => {
				if (willDelete) {
					var token =  $("#token").val();
					$.ajax({
        				type: "POST",
        				url: "delete.admin.account.php",
        				data: { 'id': uid, 'token': token },
						dataType : 'json',
        				cache: false,
        				success: function(response) {
							if(!response.error){
								swal({
									title: "Good job!",
									text: "You have succefully delete the account",
									icon: "success",
									closeOnClickOutside: false,
									buttons: {
										confirm2: {
											text: "Ok",
											value: true,
											visible: true,
											className: "btn btn-success",
											closeModal: true
										}
									}
								}).then(confirm2 => {
									if(confirm2){
										window.location='admin.accounts.php' 
									}
								});
							}else{
								swal("Internal Error","Oops, something went wrong.", "error")
							}
									
        				},
        				failure: function (response) {
            				swal("Internal Error","Oops, something went wrong.", "error")
       					}
    				});

				}
			});
		};
      

		$(document).ready(function() {
			$('#basic-datatables').DataTable({
			});
		});

		function disableUserAdmin(uid){
					swal({
						text: "Are you sure you want to disable this account?",
						type: 'warning',
						buttons:{
							cancel: {
								visible: true,
								text : 'No, cancel!',
								className: 'btn btn-danger'
							},        			
							confirm: {
								text : 'Yes, disable it!',
								className : 'btn btn-success'
							}
						}
					}).then((willDelete) => {
						if (willDelete) {
							var token =  $("#token").val();
							$.ajax({
        						type: "POST",
        						url: "disable.admin.user.php",
								data: { 'id': uid },
								dataType : 'json',
        						cache: false,
        						success: function(response) {
									document.getElementById("flag_"+response.id).innerHTML = "<span class='align-middle' style='color:#f25961!important; font-weight:700'>Disabled</span>";
            						document.getElementById("action_"+response.id).innerHTML = '<a type="button" data-toggle="tooltip" href="edit.admin.account.php?id='+response.id+'" title="" class="btn btn-link btn-primary" data-original-title="Edit"><i class="fa fa-edit"></i></a><a type="button" id="action_'+response.id+'" data-toggle="tooltip" onclick="activateUserAdmin('+response.id+');"  title="" class="btn btn-link btn-success" data-original-title="Enable User"><i  class="fas fa-user-check"></i></a><a type="button" data-toggle="tooltip" onclick="deleteUserAdmin('+response.id+');"  title="" class="btn btn-link btn-danger" data-original-title="Delete"><i  class="fas fa-trash-alt"></i></a></div>';
									swal("Sccess!","Account successfully disabled.","success")
        						},
        						failure: function (response) {
            						swal("Internal Error","Oops, something went wrong.", "error")
       							}
    						});

						}
					});
		}


		function activateUserAdmin(uid){
					swal({
						text: "Are you sure you want to enable this account?",
						type: 'warning',
						buttons:{
							cancel: {
								visible: true,
								text : 'No, cancel!',
								className: 'btn btn-danger'
							},        			
							confirm: {
								text : 'Yes, enable it!',
								className : 'btn btn-success'
							}
						}
					}).then((willDelete) => {
						if (willDelete) {
							var token =  $("#token").val();
							$.ajax({
        						type: "POST",
        						url: "enable.admin.user.php",
								data: { 'id': uid },
								dataType : 'json',
        						cache: false,
        						success: function(response) {
									document.getElementById("flag_"+response.id).innerHTML = "<span class='align-middle' style='color:#31ce36!important; font-weight:700'>Enabled</span>";
            						document.getElementById("action_"+response.id).innerHTML = '<a type="button" data-toggle="tooltip" href="edit.admin.account.php?id='+response.id+'" title="" class="btn btn-link btn-primary" data-original-title="Edit"><i class="fa fa-edit"></i></a><a type="button" id="action_'+response.id+'" data-toggle="tooltip" onclick="disableUserAdmin('+response.id+');"  title="" class="btn btn-link btn-danger" data-original-title="Disable User"><i  class="fas fa-user-slash"></i></a><a type="button" data-toggle="tooltip" onclick="deleteUserAdmin('+response.id+');"  title="" class="btn btn-link btn-danger" data-original-title="Delete"><i  class="fas fa-trash-alt"></i></a></div>';
									swal("Sccess!","Account successfully enabled.","success")
        						},
        						failure: function (response) {
            						swal("Internal Error","Oops, something went wrong.", "error")
       							}
    						});

						}
					});
		}
		
		function displayNotification(title, msg, state){
            if(state == 'success'){
                iziToast.success({title: title1, message: msg, onClosing: function () {},});
            }else{
                iziToast.error({title: title1, message: msg, onClosing: function () {},});
            }
           return;
        }

		
		
	</script>
		<script>
	<?php
		if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
			$state 	= $_SESSION["state"];
			$msg 	= $_SESSION["msg"];
			$title 	= $_SESSION["title"];
			?>
				displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>");
	<?php } ?>
	</script>

	<?php
		unset($_SESSION["state"]);
		unset($_SESSION["msg"]);
		unset($_SESSION["title"]);
	?>
	<script src="../js/search.js"></script>
</body>
</html>