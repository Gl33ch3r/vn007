<!----- START CLAIM MODAL ------>
<div class="modal fade" id="reportModal" role="dialog" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header no-bd">
				<h3 class="modal-title" style="color:black;">
					Generate Report
				</h3>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
            <form id="generateForm" action="generate-report.php" method="POST" onsubmit="open('',this.target=new Date().getTime(),'directories=no,titlebar=no,toolbar=no,menubar=no,location=no,resizable=no,scrollbars=yes,width=4000,height=4000');">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Date From</label>
                                <input id="yearfrom" name="yearfrom" type="date" class="form-control" style="color-scheme: dark;" required>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Date to</label>
                                <input id="yearto" name="yearto" type="date" class="form-control" style="color-scheme: dark;" required>
                            </div>
                        </div>
                       <!-- <div class="col-sm-12">
                            <div class="form-group">
                                <label>Status</label>
                                <select id="status" name="status" class="form-control" style="color-scheme: dark;" required>
                                    <option value="1">Approved</option>
                                    <option value="2">Rejected</option>
                                </select>
                            </div>
                        </div> -->
                    </div>
                </div>
                <div class="modal-footer no-bd">
                    <button type="submit" id="claim" class="btn btn-primary">Generate</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </form>
		</div>
	</div>
</div>
<script>
    $('#generateForm').submit(function() {
        $("#reportModal").modal('hide')
    });
</script>