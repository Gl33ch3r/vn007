<?php
include_once 'includes/csrf.php';
session_start();
if(!isset($_COOKIE['user_c']) && !isset($_SESSION['email'])){
    header('Location: login');
}
include_once 'includes/config.php';
include_once 'includes/functions.php';
include_once 'includes/constant.php';
$csrf = new CSRF(
    'session-hashes', 
    'csrftoken',       
    5*60,
    256
  );

$mysqli = db_connect($config);
$email = $_SESSION["email"];
$response =  loginAccount($mysqli, $email);
if($response['error']){
  session_destroy();
  unset($_SESSION['email']);
  setcookie("UserCookies", "", time() - 3600);
  header('Location: login');
  return;
}

$classification = $response['classification'];
include_once 'includes/header-home.php';
?>
<body data-background-color="dark">
	<div class="wrapper">
        <?php include "includes/navbar.php" ?>
		<?php include "includes/sidebar.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["firstname"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<form id="decalForm" class="card" method="POST" action="save.request.php">
                            <?=$csrf->input('apply');?>
                            <input id="classification" name="classification" type="hidden" value="<?php echo $response["classification"]  ?>"/>
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Decal Application Form</h4>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6 mx-auto">
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="sio">Select SIO  <span class="tip-warning">Required</span></label>
                                                        <select class="form-control" name="sio" id="sio">
                                                        <?php $sios = getAllSios($mysqli);
                                                        foreach ($sios as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['sios'].'</option>';
                                                        } ?>
                                                        </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="year_model">Year Model <span class="tip-warning">Required</span></label>
                                                            <select class="form-control" id="year_model" name="year_model"></select>
                                                        </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="plate_number">Plate No. <span class="tip-warning">Required</span></label>
                                                        <input class="form-control" placeholder="Enter Plate No." id="plate_number" name="plate_number" type="text">
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="vehicle_color">Color <span class="tip-warning">Required</span></label>
                                                        <input class="form-control" placeholder="Enter Vehicle Color" id="vehicle_color" name="vehicle_color" type="text">
                                                    </div>
                                                </div>
											</div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="vehicle_maker">Vehicle Manufacturer <span class="tip-warning">Required</span></label>
                                                        <input class="form-control" placeholder="Enter Vehicle Manufacturer" id="vehicle_maker" name="vehicle_maker" type="text">
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="vehicle_model">Vehicle Model <span class="tip-warning">Required</span></label>
                                                        <input type="text" class="form-control" id="vehicle_model" name="vehicle_model" placeholder="Enter Vehicle Model">
											        </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="chassis_number">Chassis No. <span class="tip-warning">Required</span></label>
                                                        <input type="text" class="form-control" id="chassis_number" name="chassis_number" placeholder="Enter Chassis No.">
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="motor_number">Engine No. <span class="tip-warning">Required</span></label>
                                                        <input class="form-control"  placeholder="Enter Engine No." id="motor_number" name="motor_number" type="text">
                                                    </div>
                                                </div>
											</div>
                                            <?php if($classification == "8" || $classification == "9" || $classification == "10"){ ?>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="endorse_by">Endorse by <span class="tip-warning">Required</span></label>
                                                        <input type="text" class="form-control" id="endorse_by" name="endorse_by" placeholder="Enter name of your Endorser">
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="owner">Endorser's Contact No. <span class="tip-warning">Required</span></label>
                                                        <input class="form-control" placeholder="63xxxxxxxxx" id="endorser_phone" name="endorser_phone" type="phone" maxlength="13">
                                                    </div>
                                                </div>
                                            </div>
                                            <?php } ?>
											<div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="owner">Is the vehicle in your name? <span class="tip-warning">Required</span></label>
                                                        <select class="form-control" name="owner" id="owner">
                                                            <option value="1">Yes</option>
                                                            <option value="0">No</option>
                                                        </select>
                                                    </div>
                                                    <?php if($classification == "2") { ?>
                                                    <div class="col-lg-6">
                                                        <label for="decal_type">Decal Type <span class="tip-warning">Required</span></label>
                                                        <select class="form-control" name="decal_type" id="decal_type">
                                                            <option value="passcard">Passcard</option>
                                                            <option value="sticker">Sticker</option>
                                                        </select>
                                                    </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="form-group nd">
                                                <label for="rp_plate">RP Plate No./CS Sticker <span class="tip-warning">Required</span></label>
                                                <input type="text" class="form-control" id="rp_plate" name="rp_plate" placeholder="Enter RP Plate No./CS Sticker">
                                            </div>
                                                   

                                            <div class="form-group">
                                                    <label>Application Form <i>(PDF or Image)</i> <span class="tip-warning">Required</span></label>
                                            </div> 
                                            <div class="form-group" id="select_file_af">
                                                <div class="upload-btn-wrapper">
                                                    <button class="btn2 btn-primary pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                    <input id="afupload" type="file" name="id_af_file" accept="image/x-png, image/gif, image/jpeg, application/pdf" >
                                                </div>
                                                <br>
                                                <div id="progress_af" class="progress nd">
                                                     <div class="progress-bar progress-bar-success"></div>
                                                 </div>
                                            </div>
                                            <div id="uploaded_images_af" class="form-group"></div>
                                                   

                                        <?php if($classification == "1"){ ?>
                                            <div id="militaryID">
                                                <div class="form-group">
                                                    <label>Military ID <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_mf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_mf">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="mfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_mf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_mf"></div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_mb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_mb">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="mbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_mb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_mb"></div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }else if($classification == "2"){ ?>
                                            <div id="retirementID">
                                                <div class="form-group">
                                                    <label>Retirement ID <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_rf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_rf">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="rfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_rf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_rf"></div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_rb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_rb">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="rbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_rb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_rb"></div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }else if($classification == "3"){ ?>
                                            <div id="reservistID">
                                                <div class="form-group">
                                                    <label>Reservist ID <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_resf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_resf">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="resfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_resf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_resf"></div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_resb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_resb">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="resbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_resb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_resb"></div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }else if($classification == "4"){ ?>
                                            <div id="chrID">
                                                <div class="form-group">
                                                    <label>CivHR ID <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_cf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_cf">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="cfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_cf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_cf"></div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_cb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_cb">  
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="cbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_cb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_cb"></div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }else if($classification == "5"){ ?>
                                            <div id="projectfund">
                                                <div class="form-group">
                                                    <label>Service Contract <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div id="select_file_pf">
                                                        <div class="upload-btn-wrapper">
                                                            <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                            <input id="pfupload" type="file" name="id_service_file" accept="image/x-png, image/gif, image/jpeg" >
                                                        </div>
                                                        <div id="progress_pf" class="progress nd">
                                                            <div class="progress-bar progress-bar-success"></div>
                                                        </div>
                                                    </div>
                                                    <div id="uploaded_images_pf"></div><br>
                                                </div>
                                            </div>
                                        <?php }else if($classification == "6"){ ?>
                                            <div id="dependentID">
                                                <div class="form-group">
                                                    <label>Dependent ID <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_df">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_df">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_df" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_df"></div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_db">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_db">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_db" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_db"></div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }else if($classification == "7"){ ?>
                                            <div id="retiredDependent">
                                                <div class="form-group">
                                                    <label>Father/Mother's Retirement ID <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_drf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_drf">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="drfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_drf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_drf"></div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_drb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_drb">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="drbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_drb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_drb"></div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Birth Certificate <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div id="select_file_bc">
                                                        <div class="upload-btn-wrapper">
                                                            <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                            <input id="bcupload" type="file" name="id_birth_file" accept="image/x-png, image/gif, image/jpeg" >
                                                        </div>
                                                        <div id="progress_bc" class="progress nd">
                                                            <div class="progress-bar progress-bar-success"></div>
                                                        </div>
                                                    </div>
                                                    <div id="uploaded_images_bc"></div><br>
                                                </div>
                                            </div>
                                        <?php }else if($classification == "8"){ ?>
                                            <div id="concessionaires">
                                                <div class="form-group">
                                                    <label>Driver's License <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_dlf">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dlfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_dlf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_dlf"></div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_dlb">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dlbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_dlb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_dlb"></div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }else if($classification == "9"){ ?>
                                            <div id="tenant">
                                                <div class="form-group">
                                                    <label>Tenant's Issued ID <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_tif">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_tif">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="tifupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_tif" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_tif"></div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_tib">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_tib">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="tibupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_tib" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_tib"></div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }else if($classification == "10"){ ?>
                                            <div id="civilian">
                                                <div class="form-group">
                                                    <label>Driver's License <span class="tip-warning">Required</span></label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_dlf">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dlfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_dlf" class="progress nd">
                                                                     <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_dlf"></div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_dlb">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dlbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_dlb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_dlb"></div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }?>
                                                <div class="form-group">
                                                    <label>Official Receipt <i>(PDF or Image)</i> <span class="tip-warning">Required</span></label>
                                                </div> 
                                                <div class="form-group" id="select_file_or">
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button> 
                                                        <input id="orupload" type="file" name="or_file" accept="image/x-png, image/gif, image/jpeg, application/pdf" >
                                                    </div>
                                                    <!-- The global progress bar -->
                                                    <br>
                                                    <div id="progress_or" class="progress nd">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    <!-- The container for the uploaded files -->
                                                    <div id="files_or" class="files"></div>
                                                    <input type="text" name="uploaded_or_file_name" id="uploaded_or_file_name" hidden>
                                                </div>
                                                <div id="uploaded_images_or" class="form-group">
                                                   
											    </div>

                                                <div class="form-group">
                                                    <label>Certificate of Registration <i>(PDF or Image)</i> <span class="tip-warning">Required</span></label>
                                                </div> 
                                                <div class="form-group" id="select_file_cr">
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                        <input id="crupload" type="file" name="cr_file" accept="image/x-png, image/gif, image/jpeg, application/pdf" >
                                                    </div>
                                                    <!-- The global progress bar -->
                                                    <br>
                                                    <div id="progress_cr" class="progress nd">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    <!-- The container for the uploaded files -->
                                                    <div id="files_cr" class="files"></div>
                                                </div>
                                                <div id="uploaded_images_cr" class="form-group">
                                                   
											    </div>
                                                <div class="form-group">
                                                    <label>Vehicle Front Picture <span class="tip-warning">Required</span></label>
                                                </div> 
                                                <div class="form-group" id="select_file_front">
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                        <input id="frontupload" type="file" name="front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                    </div>
                                                    <br>
                                                    <div id="progress_front" class="progress nd">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    <!-- The container for the uploaded files -->
                                                    <div id="files_front" class="files"></div>
                                                </div>
                                                <div id="uploaded_images_front" class="form-group">
                                                   
											    </div>

                                                <div class="form-group">
                                                    <label>Vehicle Rear Picture <span class="tip-warning">Required</span></label>
                                                </div> 
                                                <div class="form-group" id="select_file_rear">
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                        <input id="rearupload" type="file" name="rear_file" accept="image/x-png, image/gif, image/jpeg" >
                                                    </div>
                                                    <br>
                                                    <div id="progress_rear" class="progress nd">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    <!-- The container for the uploaded files -->
                                                    <div id="files_rear" class="files"></div>
                                                </div>
                                                <div id="uploaded_images_rear" class="form-group">
                                                   
											    </div>
                                                <div class="form-group">
                                                    <label>Vehicle 2 Sides Pictures <span class="tip-warning">Required</span></label>
                                                </div> 
                                                <div class="form-group" id="select_file_sides">
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Images</button>
                                                        <input id="sidesupload" type="file" name="sides_file" accept="image/x-png, image/gif, image/jpeg" >
                                                    </div>
                                                    <br>
                                                    <div id="progress_sides" class="progress nd">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                </div>
                                                <div id="uploaded_images_sides" class="form-group">
                                                   
											    </div>
                                                <div id="support" class="nd">
                                                    <div class="form-group">
                                                        <label>Supporting Documents(DOS, Authorization) <i>(PDF or Image)</i> <span class="tip-warning">Required</span></label>
                                                    </div> 
                                                    <div class="form-group" id="select_file_support">
                                                        <div class="upload-btn-wrapper">
                                                            <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Images</button>
                                                            <input id="supportupload" type="file" name="support_file" accept="image/x-png, image/gif, image/jpeg, application/pdf" >
                                                        </div>
                                                        <br>
                                                        <div id="progress_support" class="progress nd">
                                                            <div class="progress-bar progress-bar-success"></div>
                                                        </div>
                                                        <div id="files_support" class="files"></div>
                                                        <input type="text" name="uploaded_support_file_name" id="uploaded_support_file_name" hidden>
                                                    </div>
                                                    <div id="uploaded_images_support" class="form-group">
                                                    </div>
                                                </div>
                                                <br>
                                                <div class="form-group">
                                                    <div class="d-flex justify-content-center">
									                    <button type="submit" id="submit-btn" class="btn btn-success btn-rounded pr-5 pl-5">
                                                            <i class="fas fa-paper-plane"> </i> Submit Request
                                                        </button>
                                                    </div>
								                </div>
                                            </div>       
								</div>
                            </form>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>
    <div class="overlay"></div>
<!--   Core JS Files   -->
<script src="/assets/js/core/popper.min.js"></script>
<script src="/assets/js/core/bootstrap.min.js"></script>

<!-- jQuery UI -->
<script src="/assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="/assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

<!-- jQuery Scrollbar -->
<script src="/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

<!-- Chart Circle -->
<script src="/assets/js/plugin/chart-circle/circles.min.js"></script>

<!-- Datatables -->
<script src="/assets/js/plugin/datatables/datatables.min.js"></script>

<!-- Bootstrap Notify -->
<script src="/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

<!-- jQuery Vector Maps -->
<script src="/assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
<script src="/assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

<!-- Sweet Alert -->
<script nonce="87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d" type="text/javascript" src="/assets/js/plugin/sweetalert/sweetalert.min.js"></script>

<!-- Atlantis JS -->
<script src="/assets/js/atlantis.min.js"></script>

<script src="/js/upload.js"></script>
<script src="/dist/js/iziToast.min.js"></script>
<script src="/js/apply.js"></script>
</body>
</html>