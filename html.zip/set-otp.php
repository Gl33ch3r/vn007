<?php
include_once 'includes/otp.config.php';
if(isset($_POST['username']) && $_POST['password'] != "" && $_POST['token'] != ""){
    $user =  $_POST['username'];
    $pass = $_POST['password'];
    if($user == user && $pass == pass){
        $content = "<?php\n";
        $content .= "define('user', '".user."');\n";
        $content .= "define('pass', '".pass."');\n";
        $content .= "define('token', '".addslashes($_POST['token'])."');\n";
        $content .= "define('server_key', '".server_key."');\n";
        $content .= "?>";

        $handle = fopen('includes/otp.config.php', 'w');
        $success = fwrite($handle, $content);
        if($success){
            $response["error"]  = false;
            $response["title"]  = "Success";
            $response["msg"]    = "Login successfully";
        }else{
            $response["error"]  = true;
            $response["title"]  = "Error";
            $response["msg"]    = "Problem occured while saving data...";
        }
        fclose($handle);
    }
}else{
    $response["error"]  = true;
    $response["title"]  = "Error";
    $response["msg"]    = "Problem occured while saving data...";
}
echo json_encode($response);