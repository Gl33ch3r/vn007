<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING ^ E_DEPRECATED);
date_default_timezone_set('Asia/Manila');

function db_connect($config){
    $con = new mysqli($config['db']['host'], $config['db']['user'], $config['db']['pass'], $config['db']['name']);
    if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    }
    return $con;
}

function fileExtension($name) {
    $n = strrpos($name, '.');
    return ($n === false) ? '' : substr($name, $n+1);
}

function db_connect_pdo($config){
    $conn = new PDO('mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'], $config['db']['user'], $config['db']['pass']);
    if(!$conn){
        die("Fatal Error: Connection Failed!");
    }
    return $conn;
}


function stringCheck($str){
   return strpos($str, '--') !== false;   
}


function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'N2-CIB-TIB';
    $secret_iv = 'PN-EDECAL-SYSTEM-2022';
    $key = hash('sha256', $secret_key);
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}


function getPublicIP(){
    $ipAddress = '';
    if (! empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ipAddress = $_SERVER['HTTP_CLIENT_IP'];
    } else if (! empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipAddressList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        foreach ($ipAddressList as $ip) {
            if (! empty($ip)) {
                $ipAddress = $ip;
                break;
            }
        }
    } else if (! empty($_SERVER['HTTP_X_FORWARDED'])) {
        $ipAddress = $_SERVER['HTTP_X_FORWARDED'];
    } else if (! empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP'])) {
        $ipAddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
    } else if (! empty($_SERVER['HTTP_FORWARDED_FOR'])) {
        $ipAddress = $_SERVER['HTTP_FORWARDED_FOR'];
    } else if (! empty($_SERVER['HTTP_FORWARDED'])) {
        $ipAddress = $_SERVER['HTTP_FORWARDED'];
    } else if (! empty($_SERVER['REMOTE_ADDR'])) {
        $ipAddress = $_SERVER['REMOTE_ADDR'];
    }
    return $ipAddress;
}

function getAllRanks($con,$selected=""){
    $ranks = array();
    $count = 0;

    $query = "SELECT rank_name, rank_id FROM `ranks` ORDER BY rank_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count]['rank'] = $info['rank_name'];
        $ranks[$count]['id'] = $info['rank_id'];
        if($selected != ""){
            if($selected==$info['rank_id']){
                $ranks[$count]['selected'] = "selected";
            } else{
                $ranks[$count]['selected'] = "";
            }
        }
        $count++;
    }

    return $ranks;
}

function getAllRoles($con,$selected=""){
    $ranks = array();
    $count = 0;

    $query = "SELECT * FROM `role` ORDER BY id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count]['role'] = $info['name'];
        $ranks[$count]['id'] = $info['role_id'];
        if($selected != ""){
            if($selected==$info['role_id']){
                $ranks[$count]['selected'] = "selected";
            } else{
                $ranks[$count]['selected'] = "";
            }
        }
        $count++;
    }

    return $ranks;
}



function getAllSios($con,$selected=""){
    $ranks = array();
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count]['sios'] = $info['sio_name'];
        $ranks[$count]['id'] = $info['sio_id'];
        if($selected != ""){
            if($selected==$info['sio_id']){
                $ranks[$count]['selected'] = "selected";
            } else{
                $ranks[$count]['selected'] = "";
            }
        }
        $count++;
    }

    return $ranks;
}





function getAllSIO($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = $info['sio_name'];
        $count++;
    }
    return $ranks;
}


function getAllSIODecalType($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = $info['sio_name'];
        $count++;
    }
    return $ranks;
}


function getAllDecalCounts($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND sio_id = '".$sio_id."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}
function getAllDecalCountSio($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllDecalCounts($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}

function getAllPendingCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND status = '0' AND sio_id = '".$sio_id."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}

function getAllRejectedCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND status = '2' AND sio_id = '".$sio_id."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}

function getAllApprovedCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND status = '1' AND `is_claimed` = '0' AND sio_id = '".$sio_id."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}
function getAllClaimedCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND status = '1' AND `is_claimed` = '1' AND sio_id = '".$sio_id."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}

function getAllA4WCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND `category` = 'A-4W' AND `sio_id` = '".$sio_id."' AND `is_claimed` = '1' AND `status` = '1' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}



function getAllA4W($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllA4WCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}

function getAllB4WPCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND `category` = 'B-4WP' AND `sio_id` = '".$sio_id."' AND `is_claimed` = '1' AND `status` = '1' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}



function getAllB4WP($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllB4WPCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}


function getAllB4WCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND `category` = 'B-4W' AND `sio_id` = '".$sio_id."' AND `is_claimed` = '1' AND `status` = '1' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}



function getAllB4W($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllB4WCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}



function getAllC4WCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND `category` = 'C-4W' AND `sio_id` = '".$sio_id."' AND `is_claimed` = '1' AND `status` = '1' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}



function getAllC4W($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllC4WCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}

function getAllA2WCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND `category` = 'A-2W' AND `sio_id` = '".$sio_id."' AND `is_claimed` = '1' AND `status` = '1' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}



function getAllA2W($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllA2WCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}


function getAllB2WCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND `category` = 'B-2W' AND `sio_id` = '".$sio_id."' AND `is_claimed` = '1' AND `status` = '1' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}



function getAllB2W($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllB2WCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}


function getAllC2WCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(`create_at`) = YEAR(NOW()) AND `category` = 'C-2W' AND `sio_id` = '".$sio_id."' AND `is_claimed` = '1' AND `status` = '1' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count;
}



function getAllC2W($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllC2WCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}




function getAllPending($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllPendingCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}

function getAllRejected($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllRejectedCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}

function getAllApproved($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllApprovedCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}


function getAllClaimed($con){
    $count = 0;
    $query = "SELECT sio_name, sio_id FROM `sios` ORDER BY sio_id";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count] = getAllClaimedCount($con, $info["sio_id"]);
        $count++;
    }
    return $ranks;
}



function getAllDecalType($con,$selected=""){
    $ranks = array();
    $count = 0;
    $query = "SELECT `name`, `id` FROM `decal_type` ORDER BY `id`";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count]['name'] = $info['name'];
        $ranks[$count]['id'] = $info['id'];
        if($selected != ""){
            if($selected==$info['id']){
                $ranks[$count]['selected'] = "selected";
            } else{
                $ranks[$count]['selected'] = "";
            }
        }
        $count++;
    }

    return $ranks;
}

function getAllBos($con,$selected=""){
    $ranks = array();
    $count = 0;
    $query = "SELECT `name`, `id` FROM `bos` ORDER BY `id`";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count]['name'] = $info['name'];
        $ranks[$count]['id'] = $info['id'];
        if($selected != ""){
            if($selected==$info['id']){
                $ranks[$count]['selected'] = "selected";
            } else{
                $ranks[$count]['selected'] = "";
            }
        }
        $count++;
    }

    return $ranks;
}

function getAllClassificationB($con,$selected=""){
    $ranks = array();
    $count = 0;
    $query = "SELECT `name`, `id` FROM `classification_b` ORDER BY `id`";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count]['name'] = $info['name'];
        $ranks[$count]['id'] = $info['id'];
        if($selected != ""){
            if($selected==$info['id']){
                $ranks[$count]['selected'] = "selected";
            } else{
                $ranks[$count]['selected'] = "";
            }
        }
        $count++;
    }

    return $ranks;
}

function getAllClassification($con,$selected=""){
    $ranks = array();
    $count = 0;
    $query = "SELECT `name`, `id` FROM `classification` ORDER BY `id`";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count]['name'] = $info['name'];
        $ranks[$count]['id'] = $info['id'];
        if($selected != ""){
            if($selected==$info['id']){
                $ranks[$count]['selected'] = "selected";
            } else{
                $ranks[$count]['selected'] = "";
            }
        }
        $count++;
    }

    return $ranks;
}

function getAllClassificationC($con,$selected=""){
    $ranks = array();
    $count = 0;
    $query = "SELECT `name`, `id` FROM `classification_c` ORDER BY `id`";
    $query_result = mysqli_query($con,$query);
    while ($info = mysqli_fetch_array($query_result)) {
        $ranks[$count]['name'] = $info['name'];
        $ranks[$count]['id'] = $info['id'];
        if($selected != ""){
            if($selected==$info['id']){
                $ranks[$count]['selected'] = "selected";
            } else{
                $ranks[$count]['selected'] = "";
            }
        }
        $count++;
    }
    return $ranks;
}




function generateActivationCode(){
    return sha1(mt_rand(10000,99999).time());
}

function didCheck($con, $aid, $uid){
    $query="SELECT COUNT(*) AS decal_count FROM decal_application WHERE application_id = '".$aid."' AND user_id = '".$uid."'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count  > 0;
}


function emailCheck($con, $email){
    $query="SELECT COUNT(*) AS user_count FROM users WHERE email = '".$email."'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['user_count'];
    return $count  > 0;
}


function isVehicleExist($con, $vid){
    $query="SELECT COUNT(*) AS decal_count FROM decal_application WHERE vehicle_id = '".$vid."' AND YEAR(create_at) = YEAR(NOW())";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count  > 0;
}

function isVehicleExistSameUID($con, $vid, $uid){
    $query="SELECT COUNT(*) AS decal_count FROM decal_application WHERE vehicle_id = '".$vid."' AND `user_id` = '".$uid."' AND YEAR(`create_at`) = YEAR(NOW())";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    return $count  > 0;
}



function emailActivatedCheck($con, $email){
    $query="SELECT COUNT(*) AS user_count FROM users WHERE email = '".$email."' AND is_activated = '0'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['user_count'];
    return $count  > 0;
}


function activationCheck($con, $email, $code){
    $query="SELECT COUNT(*) AS user_count FROM users WHERE email = '".$email."' AND activation = '".$code."' AND is_activated = '0'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['user_count'];
    return $count  > 0;
}


function resetCheck($con, $email, $code){
    $query="SELECT COUNT(*) AS user_count FROM users WHERE email = '".$email."' AND activation = '".$code."' AND is_activated = '1'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['user_count'];
    return $count  > 0;
}


function createAccount($con, $email, $code){
    $response = array();
    $query = "INSERT INTO `users` (email, `activation`) VALUES (?,?)";
    $stmt=$con->prepare($query);
    $stmt->bind_param("ss", $email, $code);
    if ($stmt->execute()) {
            $response["error"]   = false;
            $response["email"]   = $email;
            $response["code"]    = $code;
    } else {
            $response["error"]   = true;
    }
  return $response;
}


function saveAdminAccount($con, $account_name, $username, $email, $role, $sio, $encrypted_password, $profile){
    $response = array();
    if($profile == ""){
        $query = "INSERT INTO `panel_users` (`account_name`, `username`, `email`, `sio_id`, `user_role`, `password`) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt=$con->prepare($query);
        $stmt->bind_param("ssssss", $account_name, $username, $email, $sio, $role, $encrypted_password);
    }else{
        $query = "INSERT INTO `panel_users` (`account_name`, `username`, `email`, `sio_id`, `user_role`, `password` , `profile`) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt=$con->prepare($query);
        $stmt->bind_param("sssssss", $account_name, $username, $email, $sio, $role, $encrypted_password, $profile);
    }
    if ($stmt->execute()) {
            $response["error"]   = false;
    } else {
            $response["error"]   = true;
    }
  return $response;
}


function addLogs($con, $userid, $type, $other_info, $ipaddress, $is_admin){
    $response = array();
    $query = "INSERT INTO `logs` (`user_id`, `type_function`, `other_info`, `ipaddress`, `is_admin`) VALUES (?, ?, ?, ?, ?)";
    $stmt=$con->prepare($query);
    $stmt->bind_param("sssss", $userid, $type, $other_info, $ipaddress, $is_admin);
    if ($stmt->execute()) {
            $response["error"]   = false;
    } else {
            $response["error"]   = true;
    }
  return $response;
}


function getLogs($con){
    $query="SELECT * FROM `logs` ORDER BY id DESC";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}





function updateAdminAccount($con, $account_name, $profile, $id){
    $response = array();
    if($profile == ""){
        $query = "UPDATE `panel_users` SET `account_name` = ? WHERE `id` = ?";
        $stmt=$con->prepare($query);
        $stmt->bind_param("ss", $account_name, $id);
    }else{
        $query = "UPDATE `panel_users` SET `account_name` = ?, `profile` = ? WHERE `id` = ?";
        $stmt=$con->prepare($query);
        $stmt->bind_param("sss", $account_name, $profile, $id);
    }
    if ($stmt->execute()) {
            $response["error"]   = false;
            $response["email"]   = $email;
            $response["code"]    = $code;
    } else {
            $response["error"]   = true;
    }
  return $response;
}

function updateAdminUserAccount($con, $account_name, $profile, $sio, $role, $id){
    $response = array();
    if($profile == ""){
        $query = "UPDATE `panel_users` SET `account_name` = ?, `user_role` = ?, `sio_id` = ? WHERE `id` = ?";
        $stmt= $con->prepare($query);
        $stmt->bind_param("ssss", $account_name, $role, $sio, $id);
    }else{
        $query = "UPDATE `panel_users` SET `account_name` = ?, `profile` = ?, `user_role` = ?, `sio_id` = ? WHERE `id` = ?";
        $stmt= $con->prepare($query);
        $stmt->bind_param("sssss", $account_name, $profile, $role, $sio, $id);
    }
    if ($stmt->execute()) {
            $response["error"]   = false;
            $response["email"]   = $email;
            $response["code"]    = $code;
    } else {
            $response["error"]   = true;
    }
  return $response;
}

function usernameCheckAdmin($con, $username){
    $query="SELECT COUNT(*) AS user_count FROM panel_users WHERE username = '".$username."'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['user_count'];
    return $count  > 0;
}


function emailCheckAdmin($con, $email){
    $query="SELECT COUNT(*) AS user_count FROM panel_users WHERE email = '".$email."'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['user_count'];
    return $count  > 0;
}



function updateCodeAccount($con, $email, $code){
    $response = array();
    $query = "UPDATE `users` SET `activation` = ? WHERE `email` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("ss", $code, $email);
    if ($stmt->execute()) {
            $response["error"]   = false;
            $response["email"]   = $email;
            $response["code"]    = $code;
    } else {
            $response["error"]   = true;
    }
    return $response;
}


function resetTimeline($con, $id){
    $response = array();
    $query = "DELETE FROM `timeline` WHERE `application_id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("s", $id);
    if ($stmt->execute()) {
            $response["error"]   = false;
    } else {
            $response["error"]   = true;
    }
    return $response;
}


function updateUserAccount($con, $email, $code, $password){
    $response = array();
    $query = "UPDATE `users` SET `password` = ?, `is_activated` = '1', `type` = '1' , `updated_at` = NOW() WHERE `email` = ? AND `activation` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("sss", $password, $email, $code);
    if ($stmt->execute()) {
            $response["error"]   = false;
    } else {
            $response["error"]   = true;
    }
    return $response;
}


function changeUserPassword($con, $email, $password){
    $response = array();
    $query = "UPDATE `users` SET `password` = ?, `updated_at` = NOW() WHERE `email` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("ss", $password, $email);
    if ($stmt->execute()) {
            $response["error"]   = false;
    } else {
            $response["error"]   = true;
    }
    return $response;
}

function updateUserOtherInformation($con, $email, $lastname, $firstname, $middlename, $address,  $mobile,  $birthdate){
    $response = array();
    $query = "UPDATE `users` SET `mobile` = ?, `birthdate` = ?, `updated_at` = NOW() WHERE `email` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("sss", $mobile, $birthdate, $email);
    if ($stmt->execute()) {
            $response["error"]      = false;
      } else {
            $response["error"]   = true;
      }
      return $response;
}





function updateUserProfile($con, $email,  $lastname, $firstname, $middlename, $address, $mobile,  $birthdate, $profile, $dependent_of, $bos, $rank, $date_enlisted, $date_retired, $serial_number, $designation, $unit_name, $unit_address, $unit_mobile, $classification){
    $response = array();
    if($profile == ""){
        $query = "UPDATE `users` SET `lastname` = ?, `firstname` = ?, `middlename` = ?, `address` = ?, `mobile` = ?, `birthdate` = ? , `dependent_of` = ?, `bos` = ?, `rank` = ?, `date_enlisted` = ?, `date_retired` = ?, `serial_number` = ?, `designation` = ?, `unit_name` = ?, `unit_address` = ?, `unit_mobile` = ?, `classification` = ?, `is_setup` = '1', `updated_at` = NOW() WHERE `email` = ?";
        $stmt= $con->prepare($query);
        $stmt->bind_param("ssssssssssssssssss", $lastname, $firstname, $middlename, $address, $mobile,  $birthdate, $dependent_of, $bos, $rank, $date_enlisted, $date_retired, $serial_number, $designation, $unit_name, $unit_address, $unit_mobile, $classification, $email);
    }else{
        $query = "UPDATE `users` SET `lastname` = ?, `firstname` = ?, `middlename` = ?, `address` = ?, `mobile` = ?, `birthdate` = ?, `profile_pic` = ? , `dependent_of` = ?, `bos` = ?, `rank` = ?, `date_enlisted` = ?, `date_retired` = ?, `serial_number` = ?, `designation` = ?, `unit_name` = ?, `unit_address` = ?, `unit_mobile` = ?, `classification` = ?, `is_setup` = '1', `updated_at` = NOW() WHERE `email` = ?";
        $stmt= $con->prepare($query);
        $stmt->bind_param("sssssssssssssssssss", $lastname, $firstname, $middlename, $address, $mobile,  $birthdate, $profile, $dependent_of, $bos, $rank, $date_enlisted, $date_retired, $serial_number, $designation, $unit_name, $unit_address, $unit_mobile, $classification, $email);
    }
    if ($stmt->execute()) {
            $response["error"]   = false;
    } else {
            $response["error"]   = true;
    }
      return $response;
}

function updateVehicleInformation($con, $vehicle_model, $year_model, $vehicle_color, $plate_number,  $chassis_number, $vehicle_maker, $motor_number, $rp_plate, $owner, $vehicle_id){
    $response = array();
    $query = "UPDATE `vehicle_data` SET `vehicle_model` = ?, `year_model` = ?, `vehicle_color` = ?, `plate_number` = ?, `chassis_number` = ?, `vehicle_maker` = ?, `motor_number` = ?, `rp_plate` = ?, `is_owner` = ? WHERE `id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("ssssssssss", $vehicle_model, $year_model, $vehicle_color, $plate_number, $chassis_number, $vehicle_maker, $motor_number, $rp_plate, $owner, $vehicle_id);
    if ($stmt->execute()) {
            $response["error"]   = false;
    } else {
            $response["error"]   = true;
    }
      return $response;
}

function updateDecalApplication($con, $userid, $sio_id, $vehicle_id, $uploaded_or_name, $uploaded_cr_name, $uploaded_front_name, $uploaded_rear_name, $uploaded_side_list, $uploaded_support_list, $frontid, $backid, $endorse, $endorser_phone, $birthcert, $contract, $decalid, $application_form_path, $decal_type){
    $response = array();
    $query = "UPDATE `decal_application` SET `sio_id` = ?, `vehicle_id` = ?, `or_path` = ?, `cr_path` = ?, `front_path` = ? , `rear_path` = ?, `sides_path` = ?, `support_path` = ?, `frontid_path` = ?, `backid_path` = ?, `endorse_by` = ?, `endorser_contact` = ?, `birth_cert_path` = ?, `service_contract_path` = ?, `application_form_path` = ?, `decal_type` = ?, `remarks` = '', `has_deficiency` = '0', `updated_at` = NOW() WHERE `application_id` = ? AND `user_id` = ? AND YEAR(`create_at`) =  YEAR(NOW())";
    $stmt= $con->prepare($query);
    $stmt->bind_param("ssssssssssssssssss", $sio_id, $vehicle_id, $uploaded_or_name, $uploaded_cr_name, $uploaded_front_name, $uploaded_rear_name, $uploaded_side_list, $uploaded_support_list, $frontid, $backid, $endorse, $endorser_phone, $birthcert, $contract, $application_form_path, $decal_type, $decalid, $userid);
    if ($stmt->execute()) {
            $response["error"]      = false;
    } else {
            $response["error"]   = true;
    }
      return $response;
}
   
function updateDecalApplicationLevel($con, $userid, $sio_id, $vehicle_id, $uploaded_or_name, $uploaded_cr_name, $uploaded_front_name, $uploaded_rear_name, $uploaded_side_list, $uploaded_support_list, $frontid, $backid, $endorse, $endorser_phone, $birthcert, $contract, $decalid, $application_form_path, $decal_type){
    $response = array();
    $query = "UPDATE `decal_application` SET `sio_id` = ?, `vehicle_id` = ?, `or_path` = ?, `cr_path` = ?, `front_path` = ? , `rear_path` = ?, `sides_path` = ?, `support_path` = ?, `frontid_path` = ?, `backid_path` = ?, `endorse_by` = ?, `endorser_contact` = ?, `birth_cert_path` = ?, `service_contract_path` = ?, `application_form_path` = ?, `decal_type` = ?, `remarks` = '', `approved_level` = '4', `has_deficiency` = '0', `updated_at` = NOW() WHERE `application_id` = ? AND `user_id` = ? AND YEAR(`create_at`) =  YEAR(NOW())";
    $stmt= $con->prepare($query);
    $stmt->bind_param("ssssssssssssssssss", $sio_id, $vehicle_id, $uploaded_or_name, $uploaded_cr_name, $uploaded_front_name, $uploaded_rear_name, $uploaded_side_list, $uploaded_support_list, $frontid, $backid, $endorse, $endorser_phone, $birthcert, $contract, $application_form_path, $decal_type, $decalid, $userid);
    if ($stmt->execute()) {
            $response["error"]      = false;
    } else {
            $response["error"]   = true;
    }
      return $response;
}
    

function disableUser($con, $userid){
    $response = array();
    $query = "UPDATE `users` SET `is_activated` = '2' WHERE `id` = '".$userid."'";
    $stmt= $con->prepare($query);
    $stmt->bind_param("s", $userid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $userid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $userid;
    }
      return $response;
}


function deleteAdmin($con, $adminid){
    $response = array();
    $query = "DELETE FROM `panel_users` WHERE `id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("i", $adminid);
    if ($stmt->execute()) {
            $response["error"]      = false;
    } else {
            $response["error"]      = true;
    }
      return $response;
}

function addRemarks($con, $aid, $remarks){
    $response = array();
    $query = "UPDATE `decal_application` SET `has_deficiency` = '1', `is_read` = '0', `remarks` = ?, `updated_at` = NOW() WHERE `application_id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("ss", $remarks, $aid);
    if ($stmt->execute()) {
        $response["error"]      = false;
        $response["id"]         = $aid;
} else {
        $response["error"]      = true;
        $response["id"]         = $aid;
}
      return $response;
}

function addRemarksRejected($con, $aid, $remarks, $userid){
    $response = array();
    $query = "UPDATE `decal_application` SET `is_read` = '0', `has_deficiency` = '0', `status` = '2', `remarks` = ?,`rejected_by` = ?, `updated_at` = NOW() WHERE `application_id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("sss", $remarks, $userid, $aid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $userid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $userid;
    }
      return $response;
}

function setRead($con, $aid, $uid){
    $response = array();
    $query = "UPDATE `decal_application` SET `is_read` = '1', `updated_at` = NOW() WHERE `user_id` = ? AND `application_id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("ss", $uid, $aid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $uid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $uid;
    }
      return $response;
}


function setReadRejected($con, $uid){
    $response = array();
    $query = "UPDATE `decal_application` SET `is_read` = '1', `updated_at` = NOW() WHERE `user_id` = ? AND `status` = '2'";
    $stmt= $con->prepare($query);
    $stmt->bind_param("s", $uid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $uid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $uid;
    }
      return $response;
}



function enableUser($con, $userid){
    $response = array();
    $query = "UPDATE `users` SET `is_activated` = '1' WHERE `id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("s", $userid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $userid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $userid;
    }
      return $response;
}


function disableUserAdmin($con, $userid){
    $response = array();
    $query = "UPDATE `panel_users` SET `is_enabled` = '0' WHERE `id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("s", $userid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $userid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $userid;
    }
      return $response;
}

function enableUserAdmin($con, $userid){
    $response = array();
    $query = "UPDATE `panel_users` SET `is_enabled` = '1' WHERE `id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("s", $userid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $userid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $userid;
    }
      return $response;
}

function claimDecal($con, $aid, $claimants, $decal_number, $id, $category){
    $response = array();
    $query = "UPDATE `decal_application` SET `is_claimed` = '1', `date_claimed` = NOW(), `category` = ?, `claimed_by` = ?, `released_by` = ?, `decal_number` = ? WHERE `application_id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("sssss",$category, $claimants, $id, $decal_number, $aid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $aid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $aid;
    }
      return $response;
}


function endorseRequest($con, $aid, $level){
    $response = array();
    $query = "UPDATE `decal_application` SET `approved_level` = ?, `updated_at` = NOW() WHERE `application_id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("ss",$level, $aid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $aid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $aid;
    }
      return $response;
}


function approveRequest($con, $aid){
    $response = array();
    $query = "UPDATE `decal_application` SET `is_read` = '0', `has_deficiency` = '0', `status` = '1', `updated_at` = NOW() WHERE `application_id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("s", $aid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $aid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $aid;
    }
      return $response;
}

function revokeApprovedRequest($con, $aid){
    $response = array();
    $query = "UPDATE `decal_application` SET `status` = '1', `is_read` = '0', `updated_at` = NOW() WHERE `application_id` = ?";
    $stmt= $con->prepare($query);
    $stmt->bind_param("s", $aid);
    if ($stmt->execute()) {
            $response["error"]      = false;
            $response["id"]         = $aid;
    } else {
            $response["error"]      = true;
            $response["id"]         = $aid;
    }
      return $response;
}
    

function getClassification($con, $id){
    $response = array();
    $query="SELECT * FROM `classification` WHERE `id` = ?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if($u = $result->fetch_assoc()) {
        $response["error"]           = false;
        $response["name"]            = $u["name"];
    }else{
        $response["error"]           = true;
    }
    return $response;
}


function loginAccount($con, $email){
    $response = array();
    $query="SELECT * FROM `users` WHERE `email` = ?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if($u = $result->fetch_assoc()) {
        $response["error"]           = false;
        $response["id"]              = $u["id"];
        $response["email"]           = $u["email"];
        $response["password"]        = $u["password"];
        $response["is_activated"]    = $u["is_activated"];
        $response["lastname"]        = $u["lastname"];
        $response["firstname"]       = $u["firstname"];
        $response["middlename"]      = $u["middlename"];
        $response["mobile"]          = $u["mobile"];
        $response["birthdate"]       = $u["birthdate"];
        $response["address"]         = $u["address"];
        $response["profile_pic"]     = $u["profile_pic"];
        $response["classification"]  = $u["classification"];
        $response["bos"]             = $u["bos"];
        $response["rank"]            = $u["rank"];
        $response["date_enlisted"]   = $u["date_enlisted"];
        $response["date_retired"]    = $u["date_retired"];
        $response["dependent_of"]    = $u["dependent_of"];
        $response["serial_number"]   = $u["serial_number"];
        $response["designation"]     = $u["designation"];
        $response["unit_name"]       = $u["unit_name"];
        $response["unit_address"]    = $u["unit_address"];
        $response["unit_mobile"]     = $u["unit_mobile"];
        $response["is_setup"]        = $u["is_setup"] == '1' ? true : false;

    }else{
        $response["error"]           = true;
    }
return $response;
}


    

function loginAdmin($con, $id){
    $response = array();
    $query="SELECT * FROM `panel_users` WHERE `id` = ?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if($u = $result->fetch_assoc()) {
        $response["error"]           = false;
        $response["id"]              = $u["id"];
        $response["email"]           = $u["email"];
        $response["username"]        = $u["username"];
        $response["password"]        = $u["password"];
        $response["user_role"]       = $u["user_role"];
        $response["account_name"]    = $u["account_name"];
        $response["sio_id"]          = $u["sio_id"];
        $response["profile"]         = $u["profile"];
      }else{
        $response["error"]           = true;
      }
    return $response;
    }


    function getSioName($con, $id){
        $response = array();
        $query="SELECT * FROM `sios` WHERE `sio_id` = ?";
        $stmt=$con->prepare($query);
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        if($u = $result->fetch_assoc()) {
            $response["error"]               = false;
            $response["sio_id"]              = $u["sio_id"];
            $response["sio_name"]            = $u["sio_name"];
          }else{
            $response["error"]               = true;
          }
        return $response;
    }

    function getRoleName($con, $id){
        $response = array();
        $query="SELECT * FROM `role` WHERE `role_id` = ?";
        $stmt=$con->prepare($query);
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        if($u = $result->fetch_assoc()) {
            $response["error"]               = false;
            $response["role_id"]             = $u["role_id"];
            $response["name"]                = $u["name"];
          }else{
            $response["error"]               = true;
          }
        return $response;
        }




    function adminLogin($con, $username){
        $response = array();
        $query="SELECT * FROM `panel_users` WHERE `username` = ?";
        $stmt=$con->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if($u = $result->fetch_assoc()) {
            $response["error"]           = false;
            $response["id"]              = $u["id"];
            $response["email"]           = $u["email"];
            $response["username"]        = $u["username"];
            $response["password"]        = $u["password"];
            $response["user_role"]       = $u["user_role"];
            $response["account_name"]    = $u["account_name"];
            $response["sio_id"]          = $u["sio_id"];
            $response["profile"]         = $u["profile"];
            $response["is_enabled"]      = $u["is_enabled"] == "1" ? true : false;
          }else{
            $response["error"]           = true;
          }
        return $response;
    }
        
    

function changeAdminPassword($con, $id, $password){
    $response = array();
    $query = "UPDATE `panel_users` SET `password` = ?, `updated_at` = NOW() WHERE `id` = ?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("ss", $password, $id);
    if ($stmt->execute()) {
        $response["error"]   = false;
    } else {
        $response["error"]   = true;
    }
    return $response;
}
    

function getUserByID($con, $id){
    $response = array();
    $query="SELECT * FROM `users` WHERE `id` = ?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if($u = $result->fetch_assoc()) {
        $response["error"]           = false;
        $response["id"]              = $u["id"];
        $response["email"]           = $u["email"];
        $response["password"]        = $u["password"];
        $response["is_activated"]    = $u["is_activated"];
        $response["lastname"]        = $u["lastname"];
        $response["firstname"]       = $u["firstname"];
        $response["middlename"]      = $u["middlename"];
        $response["mobile"]          = $u["mobile"];
        $response["birthdate"]       = $u["birthdate"];
        $response["address"]         = $u["address"];
        $response["profile_pic"]     = $u["profile_pic"];
        $response["classification"]  = $u["classification"];
        $response["bos"]             = $u["bos"];
        $response["rank"]            = $u["rank"];
        $response["date_enlisted"]   = $u["date_enlisted"];
        $response["date_retired"]    = $u["date_retired"];
        $response["dependent_of"]    = $u["dependent_of"];
        $response["serial_number"]   = $u["serial_number"];
        $response["designation"]     = $u["designation"];
        $response["unit_name"]       = $u["unit_name"];
        $response["unit_address"]    = $u["unit_address"];
        $response["unit_mobile"]     = $u["unit_mobile"];
        $response["is_setup"]        = $u["is_setup"] === '1' ? true : false;
      }else{
        $response["error"]           = true;
      }
    return $response;
    }

function addVehicleInformation($con, $vehicle_model, $year_model, $vehicle_color, $plate_number, $chassis_number, $vehicle_maker, $motor_number, $is_owner){
    $response = array();
    $query = "INSERT INTO `vehicle_data` (`vehicle_model`, `year_model`, `vehicle_color`, `plate_number`, `chassis_number`, `vehicle_maker`, `motor_number`, `is_owner`) VALUES (?,?,?,?,?,?,?,?)";
    $stmt = $con->prepare($query);
    $stmt->bind_param("ssssssss", $vehicle_model, $year_model, $vehicle_color, $plate_number, $chassis_number, $vehicle_maker, $motor_number, $is_owner);
    if ($stmt->execute()) {
            $response["error"]   = false;
            $response["vehicle_id"]   = $con->insert_id;
    } else {
            $response["error"]   = true;
    }
    return $response;
}


function getVehicleInformation($con, $id){
    $response = array();
    $query="SELECT * FROM `vehicle_data` WHERE `id` = ?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if($u = $result->fetch_assoc()) {
        $response["error"]              = false;
        $response["id"]                 = $u["id"];
        $response["vehicle_model"]      = $u["vehicle_model"];
        $response["year_model"]         = $u["year_model"];
        $response["vehicle_color"]      = $u["vehicle_color"];
        $response["plate_number"]       = $u["plate_number"];
        $response["chassis_number"]     = $u["chassis_number"];
        $response["vehicle_maker"]      = $u["vehicle_maker"];
        $response["motor_number"]       = $u["motor_number"];
        $response["rp_plate"]           = $u["rp_plate"];
        $response["is_owner"]           = $u["is_owner"];
      }else{
        $response["error"]           = true;
      }
    return $response;
}




function getVehicleInformationByPlate($con, $plate){
    $response = array();
    $query="SELECT * FROM `vehicle_data` WHERE `plate_number` = ? ORDER BY id DESC LIMIT 1";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s", $plate);
    $stmt->execute();
    $result = $stmt->get_result();
    if($u = $result->fetch_assoc()) {
        $response["error"]              = false;
        $response["id"]                 = $u["id"];
        $response["vehicle_model"]      = $u["vehicle_model"];
        $response["year_model"]         = $u["year_model"];
        $response["vehicle_color"]      = $u["vehicle_color"];
        $response["plate_number"]       = $u["plate_number"];
        $response["chassis_number"]     = $u["chassis_number"];
        $response["vehicle_maker"]      = $u["vehicle_maker"];
        $response["motor_number"]       = $u["motor_number"];
        $response["rp_plate"]           = $u["rp_plate"];
        $response["is_owner"]           = $u["is_owner"];
      }else{
        $response["error"]           = true;
      }
    return $response;
}




function addDecalApplication($con, $userid, $sioid, $vehicle_id, $uploaded_or_name, $uploaded_cr_name, $uploaded_front_name, $uploaded_rear_name, $uploaded_side_list, $uploaded_support_list, $frontid, $backid, $birthcert, $contract, $endorse, $endorser_phone, $application_form, $decal_type){
    $response = array();
    $query = "INSERT INTO `decal_application` (`user_id`, `sio_id`, `vehicle_id`, `frontid_path`, `backid_path`, `birth_cert_path`, `service_contract_path`, `or_path`, `cr_path`, `front_path`, `rear_path`, `sides_path`, `support_path`, `endorse_by`, `endorser_contact`, `application_form_path`, `decal_type`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $con->prepare($query);
    $stmt->bind_param("sssssssssssssssss", $userid, $sioid, $vehicle_id, $frontid, $backid, $birthcert, $contract, $uploaded_or_name, $uploaded_cr_name, $uploaded_front_name, $uploaded_rear_name, $uploaded_side_list, $uploaded_support_list, $endorse, $endorser_phone, $application_form, $decal_type);
    if ($stmt->execute()) {
            $response["error"]   = false;
            $response["appid"]   = $con->insert_id;
    } else {
            $response["error"]   = true;
    }
    return $response;
}


function addTimeLine($con, $appid, $adminid, $type, $role, $level){
    $response = array();
    $query = "INSERT INTO `timeline` (`application_id`, `admin_id`, `what_type`, `role`, `approved_level`) VALUES (?, ?, ?, ?, ?)";
    $stmt = $con->prepare($query);
    $stmt->bind_param("sssss", $appid, $adminid, $type, $role, $level);
    if ($stmt->execute()) {
            $response["error"]   = false;
    } else {
            $response["error"]   = true;
    }
    return $response;

}

function getTimeline($con, $id){
    $query="SELECT * FROM `timeline` WHERE `application_id` = '".$id."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getTimelineData($con, $id, $level, $type){
    $response = array();
    $query="SELECT * FROM `timeline` WHERE `application_id` = ? AND `approved_level` = ? AND `what_type` = ?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("sss", $id, $level, $type);
    $stmt->execute();
    $result = $stmt->get_result();
    if($u = $result->fetch_assoc()) {
        $response["error"]                  = false;
        $response["what_time"]              = $u["what_time"];
    }else{
        $response["error"]                  = true;
    }

    return $response;

}



function getDecalInformation($con, $id){
    $response = array();
    $query="SELECT * FROM `decal_application` WHERE `application_id` = ?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if($u = $result->fetch_assoc()) {
        $response["error"]                  = false;
        $response["application_id"]         = $u["application_id"];
        $response["user_id"]                = $u["user_id"];
        $response["sio_id"]                 = $u["sio_id"];
        $response["vehicle_id"]             = $u["vehicle_id"];
        $response["id_path"]                = $u["id_path"];
        $response["or_path"]                = $u["or_path"];
        $response["cr_path"]                = $u["cr_path"];
        $response["front_path"]             = $u["front_path"];
        $response["rear_path"]              = $u["rear_path"];
        $response["sides_path"]             = $u["sides_path"];
        $response["support_path"]           = $u["support_path"];
        $response["frontid_path"]           = $u["frontid_path"];
        $response["backid_path"]            = $u["backid_path"];
        $response["application_form_path"]  = $u["application_form_path"];
        $response["birth_cert_path"]        = $u["birth_cert_path"];
        $response["service_contract_path"]  = $u["service_contract_path"];
        $response["endorse_by"]             = $u["endorse_by"];
        $response["endorser_contact"]       = $u["endorser_contact"];
        $response["remarks"]                = $u["remarks"];
        $response["status"]                 = $u["status"];
        $response["has_deficiency"]         = $u["has_deficiency"] === "1" ? true : false;
        $response["approved_level"]         = $u["approved_level"];
        $response["is_claimed"]             = $u["is_claimed"] === "1" ? true : false;
        $response["claimed_by"]             = $u["claimed_by"];
        $response["date_claimed"]           = $u["date_claimed"];
        $response["decal_number"]           = $u["decal_number"];
        $response["released_by"]            = $u["released_by"];
        $response["decal_type"]             = $u["decal_type"];
      }else{
        $response["error"]              = true;
      }
    return $response;
}


function getDecalInformationByVehicleId($con, $vehicle_id){
    $response = array();
    $query="SELECT * FROM `decal_application` WHERE `vehicle_id` = ?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s", $vehicle_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if($u = $result->fetch_assoc()) {
        $response["error"]                  = false;
        $response["application_id"]         = $u["application_id"];
        $response["user_id"]                = $u["user_id"];
        $response["sio_id"]                 = $u["sio_id"];
        $response["vehicle_id"]             = $u["vehicle_id"];
        $response["id_path"]                = $u["id_path"];
        $response["or_path"]                = $u["or_path"];
        $response["cr_path"]                = $u["cr_path"];
        $response["front_path"]             = $u["front_path"];
        $response["rear_path"]              = $u["rear_path"];
        $response["sides_path"]             = $u["sides_path"];
        $response["support_path"]           = $u["support_path"];
        $response["frontid_path"]           = $u["frontid_path"];
        $response["backid_path"]            = $u["backid_path"];
        $response["application_form_path"]  = $u["application_form_path"];
        $response["birth_cert_path"]        = $u["birth_cert_path"];
        $response["service_contract_path"]  = $u["service_contract_path"];
        $response["endorse_by"]             = $u["endorse_by"];
        $response["endorser_contact"]       = $u["endorser_contact"];
        $response["remarks"]                = $u["remarks"];
        $response["status"]                 = $u["status"];
        $response["has_deficiency"]         = $u["has_deficiency"] === "1" ? true : false;
        $response["approved_level"]         = $u["approved_level"];
        $response["is_claimed"]             = $u["is_claimed"] === "1" ? true : false;
        $response["claimed_by"]             = $u["claimed_by"];
        $response["date_claimed"]           = $u["date_claimed"];
        $response["decal_number"]           = $u["decal_number"];
        $response["released_by"]            = $u["released_by"];
      }else{
        $response["error"]              = true;
      }
    return $response;
}


function getAllDecalInformation($con, $id, $status){
    $query="SELECT * FROM `decal_application` WHERE YEAR(`create_at`) = YEAR(NOW()) AND `user_id` = '".$id."' AND  `status` = '".$status."' ";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getAllDecalInfoHistory($con, $id){
    $query="SELECT * FROM `decal_application` WHERE YEAR(`create_at`) <> YEAR(NOW()) AND `user_id` = '".$id."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}


function getAllAppDecalInformation($con, $id){
    $query="SELECT * FROM `decal_application` WHERE YEAR(`create_at`) = YEAR(NOW()) AND `user_id` = '".$id."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getAllDecalInformationAdmin($con, $status){
    $query="SELECT * FROM `decal_application` WHERE YEAR(`create_at`) = YEAR(NOW()) AND `status` = '".$status."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getAllDecalInformationAdminApproved($con, $status){
    $query="SELECT * FROM `decal_application` WHERE `status` = '".$status."' AND YEAR(create_at) = YEAR(NOW()) AND is_claimed = '0'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getAllDecalInformationAdminClaimed($con, $status){
    $query="SELECT * FROM `decal_application` WHERE `status` = '".$status."' AND YEAR(create_at) = YEAR(NOW()) AND is_claimed = '1'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}




function getAllDecalInformationReport($con, $status, $from, $to){
    $query="SELECT * FROM `decal_application` WHERE `status` = '".$status."' AND  UNIX_TIMESTAMP(`create_at`) BETWEEN '".$from."' AND '".$to."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getAllDecalInformationReportSio($con, $status, $from, $to, $sio_id){
    $query="SELECT * FROM `decal_application` WHERE `status` = '".$status."' AND `sio_id` = '".$sio_id."' AND UNIX_TIMESTAMP(`create_at`) BETWEEN '".$from."' AND '".$to."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}


function getAllApprovedDecalInformationReport($con, $claimed, $from, $to){
    $query="SELECT * FROM `decal_application` WHERE `is_claimed` = '".$claimed."' AND `status` = '1' AND  UNIX_TIMESTAMP(`create_at`) BETWEEN '".$from."' AND '".$to."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getAllApprovedDecalInformationReportSio($con, $claimed, $from, $to, $sio_id){
    $query="SELECT * FROM `decal_application` WHERE `is_claimed` = '".$claimed."'  AND `status` = '1' AND `sio_id` = '".$sio_id."' AND UNIX_TIMESTAMP(`create_at`) BETWEEN '".$from."' AND '".$to."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}


function getDecalInformationReport($con, $from, $to){
    $query="SELECT * FROM `decal_application` WHERE (`status` = '1' OR `status` = '2') AND UNIX_TIMESTAMP(`create_at`)  BETWEEN '".$from."' AND '".$to."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getDecalInformationReportSio($con, $from, $to, $sio_id){
    $query="SELECT * FROM `decal_application` WHERE `sio_id` = '".$sio_id."'  AND (`status` = '1' OR `status` = '2') AND UNIX_TIMESTAMP(`create_at`) BETWEEN '".$from."' AND '".$to."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}


function getAllDecalInformationAdminSio($con, $status, $sio_id){
    $query="SELECT * FROM `decal_application` WHERE `status` = '".$status."' AND `sio_id` = '".$sio_id."' AND YEAR(create_at) = YEAR(NOW())";
    $sqldata = mysqli_query($con, $query); 
    return $sqldata;
}

function getAllDecalInformationAdminSioApproved($con, $status, $sio_id){
    $query="SELECT * FROM `decal_application` WHERE `status` = '".$status."' AND `sio_id` = '".$sio_id."' AND YEAR(create_at) = YEAR(NOW()) AND is_claimed = '0'";
    $sqldata = mysqli_query($con, $query); 
    return $sqldata;
}

function getAllDecalInformationAdminSioClaimed($con, $status, $sio_id){
    $query="SELECT * FROM `decal_application` WHERE `status` = '".$status."' AND `sio_id` = '".$sio_id."' AND YEAR(create_at) = YEAR(NOW()) AND is_claimed = '1'";
    $sqldata = mysqli_query($con, $query); 
    return $sqldata;
}

function getAllDecalInformationAdminPending($con, $status, $level){
    $query="SELECT * FROM `decal_application` WHERE `status` = '".$status."' AND `approved_level` = '".$level."' AND YEAR(create_at) = YEAR(NOW())";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}


function getAllDecalInformationAdminSioPending($con, $status, $sio_id, $level){
    $query="SELECT * FROM `decal_application` WHERE `status` = '".$status."' AND `sio_id` = '".$sio_id."' AND `approved_level` = '".$level."' AND YEAR(create_at) = YEAR(NOW())";
    $sqldata = mysqli_query($con, $query); 
    return $sqldata;
}

function getAllUsers($con){
    $query="SELECT * FROM `users`";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getAllAppDecalInformationAdmin($con){
    $query="SELECT * FROM `decal_application`";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getAllAdminAccount($con){
    $query="SELECT * FROM `panel_users`";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getAllAppDecalInformationAdminSio($con, $sio_id){
    $query="SELECT * FROM `decal_application` WHERE sio_id = '".$sio_id."'";
    $sqldata = mysqli_query($con, $query);
    return $sqldata;
}

function getUserCount($con){
    $query="SELECT COUNT(*) AS `users_count` FROM `users` WHERE `is_activated` = '1' AND `is_setup` = '1'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['users_count'];
    return $count;
}



function getAllDecalCount($con, $year){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id  WHERE YEAR(`create_at`) = '".$year."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}



function getSioDecalCount($con, $sio_id, $year){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = '".$year."' AND `sio_id` =  '".$sio_id."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}

function getAllApprovedDecalCountDash($con){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = YEAR(NOW()) AND status = '1' AND `is_claimed` = '0' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}


function getAllApprovedDecalCount($con){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = YEAR(NOW()) AND status = '1' AND is_claimed = '0' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}

function getSioApprovedDecalCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = YEAR(NOW()) AND `sio_id` =  '".$sio_id."' AND status = '1' AND is_claimed = '0' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}

function getAllClaimedDecalCount($con){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = YEAR(NOW()) AND status = '1' AND is_claimed = '1' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}

function getSioClaimedDecalCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = YEAR(NOW()) AND `sio_id` =  '".$sio_id."' AND status = '1' AND is_claimed = '1' AND has_deficiency = '0' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}



function getAllPendingDecalCount($con, $level){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = YEAR(NOW()) AND status = '0' AND `approved_level` = '".$level."' AND has_deficiency = '0' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}


function getAllDecalCountUser($con, $has_deficiency, $status, $uid){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` WHERE YEAR(create_at) = YEAR(NOW()) AND `status` = '".$status."' AND `is_read` = '0' AND `user_id` = '".$uid."' AND `has_deficiency` = '".$has_deficiency."'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}



function getAllPendingDecalCountDash($con){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = YEAR(NOW()) AND status = '0' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}

function getSioPendingDecalCount($con, $sio_id, $level){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = YEAR(NOW()) AND `sio_id` =  '".$sio_id."' AND has_deficiency = '0' AND `status` = '0' AND `approved_level` = '".$level."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}

function getAllRejectedDecalCount($con){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = YEAR(NOW()) AND status = '2' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}

function getSioRejectedDecalCount($con, $sio_id){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE YEAR(create_at) = YEAR(NOW()) AND `sio_id` =  '".$sio_id."' AND status = '2' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}

function getAllDecalCountMonth($con, $monthyear){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE DATE_FORMAT(create_at, '%Y%m') = '".$monthyear."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}


function getSioDecalCountMonth($con, $sio_id, $monthyear){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE DATE_FORMAT(create_at, '%Y%m') = '".$monthyear."' AND `sio_id` =  '".$sio_id."'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return  $count;
}

function getAllDecalCountDay($con, $monthyearday){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE DATE_FORMAT(create_at, '%Y%m%d') = '".$monthyearday."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return $count;
}

function getSioDecalCountDay($con, $sio_id, $monthyearday){
    $query="SELECT COUNT(*) AS `decal_count` FROM `decal_application` a INNER JOIN `users` u ON a.user_id = u.id WHERE DATE_FORMAT(create_at, '%Y%m%d') = '".$monthyearday."' AND `sio_id` =  '".$sio_id."' AND u.is_activated = '1' GROUP BY u.is_activated";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    $count = $row['decal_count'];
    $count = $count + 0;
    return  $count;
}
?>