<?php
if(isset($_FILES['profile_file']) && $_FILES['profile_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['profile_file']['tmp_name'];
    $fileName = $_FILES['profile_file']['name'];
    $fileSize = $_FILES['profile_file']['size'];
    $fileType = $_FILES['profile_file']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
 
    // sanitize file-name
    $newFileName = "PROFILE-ADMIN-FILE-". md5(time() . $fileName) . '.' . $fileExtension;
 
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
 
    if($fileSize > 64000000){
     $message = 'FAILED_FILE_TOO_BIG';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = './uploads/';
       $dest_path = $uploadFileDir . $newFileName;
  
       if(move_uploaded_file($fileTmpPath, $dest_path)){
         $message = $dest_path;
       }else{
         $message = 'FAILED';
       }
     }else{
       $message = 'INVALID_MIME';
     }
   }
   echo $message;
   }else if(isset($_FILES['sitelogo_file']) && $_FILES['sitelogo_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['sitelogo_file']['tmp_name'];
    $fileName = $_FILES['sitelogo_file']['name'];
    $fileSize = $_FILES['sitelogo_file']['size'];
    $fileType = $_FILES['sitelogo_file']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
 
    // sanitize file-name
    $newFileName = "SITELOGO-". md5(time() . $fileName) . '.' . $fileExtension;
 
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
 
    if($fileSize > 64000000){
     $message = 'FAILED_FILE_TOO_BIG';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = '../uploads/site-images/';
       $dest_path = $uploadFileDir . $newFileName;
       $new_dest = '/uploads/site-images/'. $newFileName;
       if(move_uploaded_file($fileTmpPath, $dest_path)){
         $message = $new_dest;
       }else{
         $message = 'FAILED';
       }
     }else{
       $message = 'INVALID_MIME';
     }
   }
   echo $message;
   }else if(isset($_FILES['favico_file']) && $_FILES['favico_file']['error'] === UPLOAD_ERR_OK){
    // get details of the uploaded file
    $fileTmpPath = $_FILES['favico_file']['tmp_name'];
    $fileName = $_FILES['favico_file']['name'];
    $fileSize = $_FILES['favico_file']['size'];
    $fileType = $_FILES['favico_file']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
 
    // sanitize file-name
    $newFileName = "FAVICO-". md5(time() . $fileName) . '.' . $fileExtension;
 
    // check if file has one of the following extensions
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
 
    if($fileSize > 64000000){
     $message = 'FAILED_FILE_TOO_BIG';
   }else{
     if (in_array($fileExtension, $allowedfileExtensions)){
       // directory in which the uploaded file will be moved
       $uploadFileDir = '../uploads/site-images/';
       $dest_path = $uploadFileDir . $newFileName;
       $new_dest = '/uploads/site-images/'. $newFileName;
       if(move_uploaded_file($fileTmpPath, $dest_path)){
         $message = $new_dest;
       }else{
         $message = 'FAILED';
       }
     }else{
       $message = 'INVALID_MIME';
     }
   }
   echo $message;
   }else{
    $message = 'FAILED';
    echo $message;
  }
?>