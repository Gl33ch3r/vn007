<?php
include_once 'includes/csrf.php';
session_start();
if(!isset($_COOKIE['user_c']) && !isset($_SESSION['email'])){
    header('Location: /login');
}
include_once 'includes/config.php';
include_once 'includes/functions.php';
include_once 'includes/constant.php';
$csrf = new CSRF(
    'session-hashes', 
    'csrftoken',       
    5*60,
    256
  );
if(MAINTENANCE == "1"){
    header("Location: /maintenance");
    return;
}
$mysqli = db_connect($config);
$email = $_SESSION["email"];
$response =  loginAccount($mysqli, $email);
if($response['error']){
  session_destroy();
  unset($_SESSION['email']);
  setcookie("user_c", "", time() - 3600);
  header('Location: /404');
  return;
}

$profile        = $response["profile_pic"];
$bos            = $response["bos"];
$rank           = $response["rank"];
$classification = $response["classification"];

# start decryption process

$firstname      =  $response["firstname"];
$lastname       =  $response["lastname"];
$email          =  $response["email"];
$middlename     =  $response["middlename"];
$mobile         =  $response["mobile"];
$birthdate      =  $response["birthdate"];
$address        =  $response["address"];
$date_enlisted  =  $response["date_enlisted"];
$date_retired   =  $response["date_retired"];
$serial_number  =  $response["serial_number"];
$designation    =  $response["designation"];
$unit_name      =  $response["unit_name"];
$unit_mobile    =  $response["unit_mobile"];
$unit_address   =  $response["serial_number"];
$$dependent_of  =  $response["dependent_of"];

# end deryption process

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self' 'nonce-8db0369dff542ac448aa8f9e8ceaece603fe3de4ea9afbea19a46f4b87f4959b' 'nonce-87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d'; style-src 'self' 'nonce-87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d'; font-src 'self'; connect-src 'self'; img-src 'self' data:; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none';"/>
	<title><?php echo APP . " - " . $email ?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="assets/img/icon.ico" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script src="/assets/js/plugin/webfont/webfont.min.js"></script>
	<script src="/assets/js/plugin/webfont/webfont.load.js"></script>

	
	<!-- CSS Files -->
    <link rel="stylesheet" href="/css/loading.css" type='text/css'/>
	<link rel="stylesheet" href="/assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="/assets/css/atlantis.min.css"/>

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="/assets/css/demo.css"/>
    <link rel="stylesheet" href="/dist/css/iziToast.min.css"/>
	<link rel='stylesheet' href='/simplelightbox/dist/simple-lightbox.min.css' type='text/css'/>
	
	<script type="text/javascript" src="/js/jquery.min.js"></script>
	<script type="text/javascript" src="/dist/assets/jquery-file-upload/js/vendor/jquery.ui.widget.js"></script>
    <script type="text/javascript" src="/dist/assets/jquery-file-upload/js/jquery.iframe-transport.js"></script>
    <script type="text/javascript" src="/dist/assets/jquery-file-upload/js/jquery.fileupload.js"></script>
    <script type="text/javascript" src="/simplelightbox/dist/simple-lightbox.jquery.min.js"></script>
    <script type="text/javascript" src="/js/loading.js"></script>
	
</head>
<body data-background-color="dark">
	<div class="wrapper">
        <div class="main-header">
            <!-- Logo Header -->
            <div class="logo-header" data-background-color="dark">
                
                <a href="" class="logo">
                    <img src="<?php echo SITE_LOGO; ?>" alt="<?php echo APP; ?>" height="50" class="navbar-brand">
                </a>
                <button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                        <i class="icon-menu"></i>
                    </span>
                </button>
                <button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
            </div>
            <!-- End Logo Header -->

            <!-- Navbar Header -->
            <nav class="navbar navbar-header navbar-expand-lg" data-background-color="dark">
                
                <div class="container-fluid">
                    <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
                        
                        <li class="nav-item dropdown hidden-caret">
                            <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false">
                                <div class="avatar-sm">
                                    <img src="<?php echo $profile; ?>" alt="<?php  echo $firstname ." ". $lastname; ?>" class="avatar-img rounded-circle">
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-user animated fadeIn">
                                <div class="dropdown-user-scroll scrollbar-outer">
                                    <li>
                                        <div class="user-box">
                                            <div class="avatar-lg"><img src="<?php echo $profile; ?>" alt="image profile" class="avatar-img rounded"></div>
                                            <div class="u-text">
                                                <h4><?php echo $firstname ." ". $lastname;  ?></h4>
                                                <p class="text-muted"><?php echo $email; ?></p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" id="logout-btn-nav" href="#">Logout</a>
                                    </li>
                                </div>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
            <!-- End Navbar -->
        </div>

		<div class="main">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $email; ?>!</h2>
					</div>
					<div class="row">
                        <div class="col-md-12">
                            <?=$csrf->input('phone');?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-5 mx-auto">
                                        <div class="form-group">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">+63</span>
                                                </div>
                                                <input type="text" class="form-control" placeholder="9XXXXXXXXX" aria-label="9XXXXXXXXX" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>
			</div>
		</div>
		
	</div>
    
    <div class="overlay"></div>
    
    <!--   Core JS Files   -->
	<script src="/assets/js/core/popper.min.js"></script>
	<script src="/assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="/assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="/assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

	<!-- Chart Circle -->
	<script src="/assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="/assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="/assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="/assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

    <!-- Sweet Alert -->
    <script nonce="87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d" type="text/javascript" src="/assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="/assets/js/atlantis.min.js"></script>
    
    <script src="/dist/js/iziToast.min.js"></script>

    <script src="/js/upload.js"></script>
    <script src="/js/setup.js"></script>
</body>
</html>