<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING ^ E_DEPRECATED);
session_start();
include_once '../includes/session.admin.php';
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
if(!isset($_SESSION['id'])){
    header('Location: login');
    return;
}

$response =  loginAdmin($mysqli, $_SESSION['id']);
if($response["user_role"] != "1"){
    header("Location: pending");
    return;
}
header("Location: dashboard");
?>