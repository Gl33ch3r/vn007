<?php
$flood_protection_interval = 2;
if(isset($_SESSION['ip']) && $_SESSION['counter'] > 10 && $_SESSION['last_post'] + $flood_protection_interval > time()){
    header("location: /");
}
$_SESSION['counter']++;
$_SESSION['last_post'] = time();
$_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
?>