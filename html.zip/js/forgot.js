$(document).ready(function () {

    $('#forgotForm').submit(function() {
        if ($.trim($("#email").val()) === "" || $.trim($("#captcha").val()) === "") {
            return false;
        }
    });

    $(function() {
        $("#captcha").keyup(function() {
            this.value = this.value.toLocaleUpperCase();
        });
        $("#captcha").attr("maxlength", 6);
    });

    $('#email').on('keypress', function (e) {
        var ingnore_key_codes = [34, 39];
        if ($.inArray(e.which, ingnore_key_codes) >= 0) {
            e.preventDefault();
        } 
    });
        
    $('#captcha').on('keypress', function (e) {
        var ingnore_key_codes = [34, 39];
        if ($.inArray(e.which, ingnore_key_codes) >= 0) {
            e.preventDefault();
        }
    });
    $("#refresh-btn").click(function(){
      $("#captcha-image").attr("src", 'captcha.php?' + Date.now());
    });
  
    $("#email").keyup(function () {
        validate();
    });
  
    $("#captcha").keyup(function () {
        validate();
    });

    $("#forgot").click(function () {
        if ($.trim($("#email").val()) === "" || $.trim($("#captcha").val()) === "") {
            return false;
        }
        var email = $("#email").val();
        var csrftoken = $("#csrftoken").val();
        var captcha = $("#captcha").val();
        $.ajax({
            type: "POST",
            url: "process-forgot.php",
            data: { 'email': email, 'captcha': captcha, 'csrftoken': csrftoken },
            dataType : 'json',
            cache: false,
            success: function(response) {
                if(response.error){
                    $("#captcha").val("");
                    $("#captcha-image").attr("src", 'captcha.php?' + Date.now());
                    iziToast.error({title: 'OK', message: response.msg, onClosing: function () {},});
                }else{
                    iziToast.success({title: 'OK', message: response.msg, onClosing: function () {},});
                    $("#message").append(" <h3 class='sc-iQKALj sc-dEfkYy'> Reset Code Sent!</h3><p>We've sent an email to "+response.email+".</p><p>Click the reset link in that email to reset you account.</p>");
                    $("#message").removeClass('nd');
                    $("#forgotForm").addClass('nd')
                }
            },
            failure: function (response) {
                swal("Internal Error","Oops, something went wrong.", "error")
               }
        });
    });
    

  })
  
  function validate() {
    let email = $("#email").val();
    let captcha = $("#captcha").val();
    filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (filter.test(email) && captcha != "") {
        $("#email").css("border","none");
        $("#captcha").css("border","none");
        $("#forgot").prop('disabled', false);
        return true;
    } 
    if (!filter.test(email)) {
        $("#email").css("border","1px solid red");
        $("#forgot").prop('disabled', true);
    }else{
        $("#email").css("border","none");
    }
    if (captcha == "") {
        $("#captcha").css("border","1px solid red");
        $("#forgot").prop('disabled', true);
    }else{
        $("#captcha").css("border","none");
    }
  }
  