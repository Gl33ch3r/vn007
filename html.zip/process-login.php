
<?php
header("Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'none'; font-src 'none'; connect-src 'none'; img-src 'none'; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none'; frame-ancestors 'none'; form-action 'none';");
include_once 'includes/csrf.php';
include_once 'includes/session.php';
include_once 'includes/constant.php';
require_once 'includes/config.php';
require_once "includes/functions.php";
$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);
if(MAINTENANCE == "1"){
	header("Location: maintenance");
	return;
}

$ipaddress = getPublicIP();
$mysqli = db_connect($config);
$responseLogin = array();
if(!$csrf->validate('login')) {
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "CSRF: Verification has been unsuccessful";
  echo json_encode($responseLogin);
  return;
}

if(!isset($_POST['email']) && !isset($_POST['password']) && !isset($_POST['captcha'])){
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "Error Occurred while logging in!";
  echo json_encode($responseLogin);
  return;
}

$email                  = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8'));
$password               = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['password'], ENT_QUOTES, 'UTF-8'));
$captcha_challenge      = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['captcha'], ENT_QUOTES, 'UTF-8'));
$encrypted_password     = sha1(md5(sha1($password)));

if(isset($captcha_challenge) && $captcha_challenge != $_SESSION['captcha_text']) {
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "Incorrect Captcha, Please try again!";
  unset ($_SESSION["captcha_text"]);
  echo json_encode($responseLogin);
  return;
}

if(empty($email) || empty($password)){
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "Please enter email and password!";
  echo json_encode($responseLogin);
  return;
}
     
$response = loginAccount($mysqli, $email);
if($response['error']){
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "Incorrect email or password!";
  echo json_encode($responseLogin);
  return;
}
if($response['is_activated'] == "0"){
  $responseLogs = addLogs($mysqli, $response['id'], "Authentication", "Not Activated", $ipaddress, "0");
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "Please Activate your account!";
  echo json_encode($responseLogin);
  return;
}

if($response['is_activated'] == "2"){
  $responseLogs = addLogs($mysqli, $response['id'], "Authentication", "Disabled Account", $ipaddress, "0");
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "Your account has been disabled, Please contact administrator.";
  echo json_encode($responseLogin);
  return;
}
  
if($encrypted_password != $response['password']){
  $responseLogs = addLogs($mysqli, $response['id'], "Authentication", "Invalid Password", $ipaddress, "0");
  $responseLogin["error"] = true;
  $responseLogin["msg"] = "Incorrect email or password!";
  echo json_encode($responseLogin);
  return;
}



if(!$response['is_setup']){
  $_SESSION['email']    = $response['email'];
  setcookie("user_c", generateActivationCode() , $week->getTimestamp(), "/", null, true, null);
  $responseLogs = addLogs($mysqli, $response['id'], "Setup", "Authenticated", $ipaddress, "0");
  $responseLogin["error"] = false;
  $responseLogin["location"] = "setup";
  echo json_encode($responseLogin);
  return;
}

$_SESSION['email']    = $response['email'];
setcookie("user_c", generateActivationCode() , $week->getTimestamp(), "/", null, true, null);
$responseLogs = addLogs($mysqli, $response['id'], "Authentication", "Authenticated", $ipaddress, "0");
$responseLogin["error"] = false;
$responseLogin["location"] = "pending";
echo json_encode($responseLogin);
?>