<?php
define('APP', 'PN ELECTRONIC DECAL SYSTEM');
define('ADMIN_TITLE', 'Decal System Admin Panel');
define('ICO', '/img/site-logo.png');
define('SITE_LOGO', '/img/site-logo.png');
define('PROTOCOL', 'smtp');
define('PORT', '25');
define('MAILHOST', 'mail.nav.ph');
define('MAIL', 'jconadera@nav.ph');
define('PASSWORD', 'BloodSec1968!!!!!');
define('REPLYTO', 'edecal@navy.ph');
define('HOST', 'http://localhost');
define('PENDING', '0');
define('APPROVED', '1');
define('REJECTED', '2');
define('MAINTENANCE', '0');
define('ENABLE_SMS', '0');
?>