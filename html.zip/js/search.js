$("#search").click(function () {
	if($.trim($("#plate_number").val()) === ""){
		displayNotification("Error", "Please enter Plate Number!", "danger");
		return false;
	}
	var plate_number = $("#plate_number").val();
	$("#searchModal").modal('hide');
	$.ajax({
		type: "POST",
		url: "search.plate.php",
		data: { 'plate_number': plate_number },
		cache: false,
		success: function(response) {
            document.getElementById("plate_number").value = "";
            $("#searchResultModal").modal('show');
            $("#search-content").html(response);
			},failure: function (response) {
				swal("Internal Error","Oops, something went wrong.", "error")
			   }
		});
});

$('#logout-btn').click(function(e) {
	swal({
		title: 'Are you sure you want to logout?',
		type: 'warning',
		buttons:{
			confirm: {
				text : 'yes',
				className : 'btn btn-success'
			},
			cancel: {
				visible: true,
				className: 'btn btn-danger',
				text : 'No'
			}
		}
	}).then((confirm) => {
		if (confirm) {
			window.location='logout.admin.php' 
		} else {
			swal.close();
		}
	});
});

$('#logout-btn-nav').click(function(e) {
	swal({
		title: 'Are you sure you want to logout?',
		type: 'warning',
		buttons:{
			confirm: {
				text : 'yes',
				className : 'btn btn-success'
			},
			cancel: {
				visible: true,
				className: 'btn btn-danger',
				text : 'No'
			}
		}
	}).then((confirm) => {
		if (confirm) {
			window.location='logout.admin.php' 
		} else {
			swal.close();
		}
	});
});
var count_all = document.getElementById("count-all");

if($("#request-li").hasClass('active')){
	count_all.style.display="none";
}


$('#toggle-btn').click(function(e) {
	if(!$("#base").hasClass('show')){
		count_all.style.display="none";
	}
	else {
		count_all.style.display="";
	}
});