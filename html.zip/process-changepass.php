<?php
header("Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'none'; font-src 'none'; connect-src 'none'; img-src 'none'; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none'; frame-ancestors 'none'; form-action 'none';");
include_once 'includes/csrf.php';
session_start();
if(!isset($_COOKIE['user_c']) && !isset($_SESSION['email'])){
  header('Location: login');
}
include_once 'includes/config.php';
include_once 'includes/functions.php';
include_once 'includes/constant.php';

$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);
if(MAINTENANCE == "1"){
	header("Location: /maintenance");
	return;
}
$responseChange= array();
$mysqli = db_connect($config);
if (!$csrf->validate('changepassword')) {
	$responseChange["error"] = true;
	$responseChange["msg"] = "CSRF: Verification has been unsuccessful";
	echo json_encode($responseChange);
	return;
}

if(!isset($_POST['password'])  && !isset($_POST['cpassword']) && !isset($_POST['oldpassword'])){
    $responseChange["error"] = true;
	$responseChange["msg"] = "Problem occured while saving data...";
	echo json_encode($responseChange);
	return;
}

$email              = mysqli_real_escape_string($mysqli, $_SESSION["email"]);
$password           = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['password'], ENT_QUOTES, 'UTF-8'));
$oldpassword        = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['oldpassword'], ENT_QUOTES, 'UTF-8'));
$cpassword          = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['cpassword'], ENT_QUOTES, 'UTF-8'));


$number             = preg_match('@[0-9]@', $password);
$uppercase          = preg_match('@[A-Z]@', $password);
$lowercase          = preg_match('@[a-z]@', $password);
$specialChars       = preg_match('@[^\w]@', $password);

$response = loginAccount($mysqli, $email);
if($response['error']){
    $responseChange["error"] = true;
	$responseChange["msg"] = "Problem occured while saving data...";
	echo json_encode($responseChange);
	return;
}

if(strlen($password) < 8 || !$number || !$uppercase || !$lowercase || !$specialChars) {
    $msg = "Password must be at least 8 characters in length and must contain at least one number, one upper case letter, one lower case letter and one special character.";
    $responseChange['msg']       = $msg;
    $responseChange['error']     = true;
    echo json_encode($responseChange);
    return;
}

$encrypted_oldpassword = sha1(md5(sha1($oldpassword)));
if($encrypted_oldpassword != $response['password']){
    $responseChange["error"] = true;
	$responseChange["msg"] = "Current password incorrect...";
	echo json_encode($responseChange);
	return;
}

if($password != $cpassword){
    $responseChange['msg']        = "Password do not match!";
    $responseChange['error']      = true;
    echo json_encode($responseChange);
    return;
}

$encrypted_password = sha1(md5(sha1($password)));
$responsePassword = changeUserPassword($mysqli, $email, $encrypted_password);
if($responsePassword['error']){
    $responseChange["error"] = true;
    $responseChange["msg"] = "Problem occured while saving data...";
    echo json_encode($responseChange);
    return;
}
$responseChange["location"]      = "change-password";
$responseChange['msg']           = "You have successfully change your password.";
$responseChange['error']         = false;
echo json_encode($responseChange);
return;
?>