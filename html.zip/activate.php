<?php
include_once 'includes/csrf.php';
include_once 'includes/session.php';
include_once  'includes/constant.php';
include_once  'includes/config.php';
include_once  "includes/functions.php";;
$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);
if(MAINTENANCE == "1"){
	header("Location: maintenance");
	return;
}

$page=" - ACTIVATE";
include_once 'includes/header.php';

$mysqli = db_connect($config);
if(!isset($_GET['email']) && !isset($_GET['code'])){
  header("Location: 404");
  return;
}
$email = mysqli_real_escape_string($mysqli, htmlspecialchars($_GET['email'], ENT_QUOTES, 'UTF-8'));
$code  = mysqli_real_escape_string($mysqli, htmlspecialchars($_GET['code'], ENT_QUOTES, 'UTF-8'));
if(!activationCheck($mysqli, $email, $code)){
    header("Location: 404");
    return;
}

?>

  <div id="main">
    <div class="sc-glUWqk gZBdDv">
      <div class="sc-jqCOkK sc-bbmXgH sc-drlKqa kMexyI">
        <div class="sc-jqCOkK sc-bbmXgH sc-gGBfsJ sc-bIqbHp eFtCXp">
          <img width="100" height="100" src="<?php echo SITE_LOGO; ?>" class="sc-RbTVP kBYGdh">
          <h2 class="sc-iQKALj sc-dEfkYy fqMEYe"><?php echo APP;  ?></h2>
          <form id="activationForm">
            <h5 class="sc-iQKALj sc-dEfkYy">Activate Account</h5>
            <?=$csrf->input('activate');?>
            <input type="hidden"  name="email" id="email" value="<?php echo $email ?>">
            <input type="hidden"  name="code" id="code" value="<?php echo $code ?>">
            <input type="password" name="password" id="password" placeholder="Password" autocomplete="off"  class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG pass sc-chPdSV lYoTa2"/>
            <img id="pass-button" class="pass-button" src="/img/hidden.png"><br>   
            <input type="password" name="cpassword" id="cpassword" placeholder="Confirm Password" class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG pass sc-chPdSV lYoTa2"/>
            <img id="cpass-button" class="pass-button" src="/img/hidden.png"><br>
            <button id="activate" class="sc-hEsumM sc-jxGEyO boaKTO jFTvbI sc-kAzzGY gXQAXS" disabled type="button">ACTIVATE</button>
          </form>
          <div class="sc-jqCOkK sc-uJMKN sc-yZwTr dctPBU">
            <hr class="sc-fjhmcy hr-pad"><span>or</span>
            <hr class="sc-fjhmcy hr-pad">
          </div>
          <a href="/login" class="sc-hEsumM sc-jxGEyO sc-hwcHae gtwSej sc-kAzzGY gXQAXS" type="button" title="">LOGIN</a>
     
        </div>
         <?php 
          include_once 'includes/footer.php';
      ?>
      </div>
    </div>
</div>
<div class="overlay"></div>
</body>
  <script nonce="87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d" type="text/javascript" src="/assets/js/plugin/sweetalert/sweetalert.min.js"></script>
  <script type="text/javascript" src="/js/activate.js"></script>
  <script type="text/javascript" src="/dist/js/iziToast.min.js"></script>
</html>