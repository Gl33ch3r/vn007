


$(document).ready(function () {

  $('#activationForm').submit(function() {
    if ($.trim($("#password").val()) === "" || $.trim($("#cpassword").val()) === "") {
        return false;
    }
    if ($.trim($("#password").val()) != $.trim($("#cpassword").val())) {
        iziToast.error({title: 'Error', message: 'Password do not match!', onClosing: function () {},});
        return false;
    }
  });
  
  $(function() {
    $("#captcha").keyup(function() {
        this.value = this.value.toLocaleUpperCase();
    });
    $("#captcha").attr("maxlength", 6);
  });

  $('#password').on('keypress', function (e) {
    var ingnore_key_codes = [34, 39];
    if ($.inArray(e.which, ingnore_key_codes) >= 0) {
        e.preventDefault();
    }
  });

  $('#cpassword').on('keypress', function (e) {
    var ingnore_key_codes = [34, 39];
    if ($.inArray(e.which, ingnore_key_codes) >= 0) {
        e.preventDefault();
    }
  });


  $("#password").keyup(function () {
      validate();
  });

  $("#cpassword").keyup(function () {
      validate();
  });
  
  $("#reset").click(function () {
    if ($.trim($("#email").val()) === "" ||$.trim($("#code").val()) === "" || $.trim($("#password").val()) === "" || $.trim($("#cpassword").val()) === "") {
        return false;
    }
    var email = $("#email").val();
    var code = $("#code").val();
    var csrftoken = $("#csrftoken").val();
    var password = $("#password").val();
    var cpassword = $("#cpassword").val();
    $.ajax({
        type: "POST",
        url: "process-reset.php",
        data: { 'email': email, 'code': code, 'password': password, 'cpassword': cpassword, 'csrftoken': csrftoken},
        dataType : 'json',
        cache: false,
        success: function(response) {
            if(response.error){
                iziToast.error({title: 'OK', message: response.msg, onClosing: function () {},});
            }else{
                swal({
                    allowOutsideClick: false,
                    closeOnClickOutside: false,
                    title: "Good job!",
                    text: "You successfully reset your account, redirecting in 2 seconds",
                    icon: "success",
                    timer: 2000,
                    showConfirmButton: false
                  }).then(() => { window.location = response.location });
            }
        },
        failure: function (response) {
            swal("Internal Error","Oops, something went wrong.", "error")
          }
    });
  });
})

function validate() {
  let password = $("#password").val();
  let cpassword = $("#cpassword").val();
  if (password != "" && cpassword != "") {
      $("#password").css("border","none");
      $("#cpassword").css("border","none");
      $("#reset").prop('disabled', false);
      return true;
  } 
  if (password == "") {
      $("#password").css("border","1px solid red");
      $("#reset").prop('disabled', true);
  }else{
      $("#password").css("border","none");
  }
  if (cpassword == "") {
      $("#cpassword").css("border","1px solid red");
      $("#reset").prop('disabled', true);
  }else{
      $("#cpassword").css("border","none");
  }
}
  
