<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
  header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$uid =  mysqli_real_escape_string($mysqli, $_POST["id"]);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
    header('Location: ../404');
    return;
  }
if($response["user_role"] == "4" || $response["user_role"] == "2" || $response["user_role"] == "3" || $response["user_role"] == "5"){
    header('Location: ../404');
    return;
}
if(!$response['error']){
 $responseDisble = disableUserAdmin($mysqli, $uid);
 if(!$responseDisble["error"]){
   $ipaddress = getPublicIP();
   $responseAdminUser = loginAdmin($mysqli, $uid);
   $responseLogs = addLogs($mysqli, $response["id"], "Disable Admin User", $responseAdminUser["account_name"], $ipaddress, "1");
 }
 echo json_encode($responseDisble);
}