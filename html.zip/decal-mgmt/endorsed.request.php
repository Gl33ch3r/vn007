<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$responseEndorsed = array();
$aid =  mysqli_real_escape_string($mysqli, $_POST["id"]);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
    $responseEndorsed['error'] = true;
    echo json_encode($responseEndorsed);
    return;
}
if($response["user_role"] == "4" || $response["user_role"] == "2" || $response["user_role"] == "3"){
    if(!$response['error']){
        if($response["user_role"] == "4"){
            $level = "3";
        }else if($response["user_role"] == "3"){
            $level = "2";
        }else if($response["user_role"] == "2"){
            $level = "1";
        }
        $responseTimeline = addTimeLine($mysqli, $aid, $id, "1", "0", $level);
        if(!$responseTimeline["error"]){
            $responseDisble = endorseRequest($mysqli, $aid, $level);
            echo json_encode($responseDisble);
        }else{
            echo json_encode($responseTimeline);
        }
    }
}