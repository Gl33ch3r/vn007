<?php
require('includes/xwaf.php'); 
$xWAF = new xWAF();
$xWAF->start();
?>