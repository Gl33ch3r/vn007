<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
  session_destroy();
  unset($_SESSION['$id']);
  include_once '../includes/header.login.location.php';
}
if($response["user_role"] == "1" || $response["user_role"] == "5"){
	
include_once '../includes/header-admin.php';
?>
<body data-background-color="dark">
<div class="wrapper">
        <?php include "../includes/navbar-admin.php" ?>
		<?php include "../includes/sidebar-admin.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["account_name"]; ?>!</h2>
					</div>
					<div class="row">
					    
                        <div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Decal Monitoring</div>
								</div>
								<div class="card-body">
									<div class="chart-container">
										<canvas id="multipleBarChart"></canvas>
									</div>
								</div>
							</div>
						</div>

                        <div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Type of Decal</div>
								</div>
								<div class="card-body">
									<div class="chart-container">
										<canvas id="multipleBarChart2"></canvas>
									</div>
								</div>
							</div>
						</div>
                        <div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Total Decal Request Per SIO</div>
								</div>
								<div class="card-body">
									<div class="chart-container">
										<canvas id="barChart"></canvas>
									</div>
								</div>
							</div>
						</div>
                        <div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Dashboard</h4>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
                                        <?php if($response["user_role"] == "1" || $response["user_role"] == "5"){ ?>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="card card-stats card-round">
                                                <div class="card-body">
                                                    <div class="row align-items-center">
                                                        <div class="col-icon">
                                                            <div class="icon-big text-center icon-primary bubble-shadow-small">
                                                            <i class="flaticon-users"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col col-stats ml-3 ml-sm-0">
                                                            <div class="numbers">
                                                                <p class="card-category">Total Users</p>
                                                                <h4 class="card-title"><?php echo getUserCount($mysqli); ?></h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php } ?>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="card card-stats card-round">
                                                <div class="card-body">
                                                    <div class="row align-items-center">
                                                        <div class="col-icon">
                                                            <div class="icon-big text-center icon-info bubble-shadow-small">
                                                                <i class="flaticon-calendar"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col col-stats ml-3 ml-sm-0">
                                                            <div class="numbers">
                                                                <p class="card-category">Total Decal Request (<?php echo date("Y") ?>)</p>
                                                               
                                                                <h4 class="card-title"><?php echo getAllDecalCount($mysqli, date("Y")); ?></h4>
                                                               
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="card card-stats card-round">
                                                <div class="card-body">
                                                    <div class="row align-items-center">
                                                        <div class="col-icon">
                                                            <div class="icon-big text-center icon-info bubble-shadow-small">
                                                                <i class="flaticon-calendar"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col col-stats ml-3 ml-sm-0">
                                                            <div class="numbers">
                                                                <p class="card-category">Total Decal Request this Month</p>
                                                                <?php
                                                                    $yearmonth = date("Y").date("m");  
                                                                ?>
                                                                <h4 class="card-title"><?php echo getAllDecalCountMonth($mysqli, $yearmonth); ?></h4>
                                                             
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="card card-stats card-round">
                                                <div class="card-body">
                                                    <div class="row align-items-center">
                                                        <div class="col-icon">
                                                            <div class="icon-big text-center icon-info bubble-shadow-small">
                                                                <i class="flaticon-calendar"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col col-stats ml-3 ml-sm-0">
                                                            <div class="numbers">
                                                                <p class="card-category">Total Decal Request Today</p>
                                                                <?php
                                                                    $yearmonthday = date("Y").date("m").date("d");  
                                                                ?>
                                                                <h4 class="card-title"><?php echo getAllDecalCountDay($mysqli, $yearmonthday); ?></h4>
                                                             
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="card card-stats card-round">
                                                <div class="card-body">
                                                    <div class="row align-items-center">
                                                        <div class="col-icon">
                                                            <div class="icon-big text-center icon-warning bubble-shadow-small">
                                                                <i class="icon-hourglass"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col col-stats ml-3 ml-sm-0">
                                                            <div class="numbers">
                                                                <p class="card-category">Total Pending Request</p>
                                                                <?php if($response["user_role"] == "1" || $response["user_role"] == "5"){ ?>
                                                                <h4 class="card-title"><?php echo getAllPendingDecalCountDash($mysqli); ?></h4>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="card card-stats card-round">
                                                <div class="card-body">
                                                    <div class="row align-items-center">
                                                        <div class="col-icon">
                                                            <div class="icon-big text-center icon-danger bubble-shadow-small">
                                                                <i class="icon-ban"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col col-stats ml-3 ml-sm-0">
                                                            <div class="numbers">
                                                                <p class="card-category">Total Rejected Request</p>
                                                               
                                                                <h4 class="card-title"><?php echo getAllRejectedDecalCount($mysqli); ?></h4>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="card card-stats card-round">
                                                <div class="card-body">
                                                    <div class="row align-items-center">
                                                        <div class="col-icon">
                                                            <div class="icon-big text-center icon-primary bubble-shadow-small">
                                                                <i class="icon-like"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col col-stats ml-3 ml-sm-0">
                                                            <div class="numbers">
                                                                <p class="card-category">Total Approved Request</p>
                                                                
                                                                <h4 class="card-title"><?php echo getAllApprovedDecalCountDash($mysqli); ?></h4>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-md-3">
                                            <div class="card card-stats card-round">
                                                <div class="card-body">
                                                    <div class="row align-items-center">
                                                        <div class="col-icon">
                                                            <div class="icon-big text-center icon-success bubble-shadow-small">
                                                                <i class="flaticon-list"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col col-stats ml-3 ml-sm-0">
                                                            <div class="numbers">
                                                                <p class="card-category">Total Claimed Decal</p>
                                                              
                                                                <h4 class="card-title"><?php echo getAllClaimedDecalCount($mysqli); ?></h4>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
								    </div>
                                </div>
                            </div>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "../includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@0.7.0"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="../assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<script src="../dist/js/iziToast.min.js"></script>
    <script src="js/upload.admin.js"></script>
    <script>
        var barChart = document.getElementById('barChart').getContext('2d');
        var multipleBarChart = document.getElementById('multipleBarChart').getContext('2d');
        var multipleBarChart2 = document.getElementById('multipleBarChart2').getContext('2d');
        <?php  
        $result = '"' . implode ( '", "', getAllSIO($mysqli) ) . '"';
        $resultPending = '"' . implode ( '", "', getAllPending($mysqli) ) . '"';
        $resultRejected = '"' . implode ( '", "', getAllRejected($mysqli) ) . '"';
        $resultApproved = '"' . implode ( '", "', getAllApproved($mysqli) ) . '"';
        $resultClaimed = '"' . implode ( '", "', getAllClaimed($mysqli) ) . '"';
        $resultAll = '"' . implode ( '", "', getAllDecalCountSio($mysqli) ) . '"';
        ?>
         var myBarChart = new Chart(barChart, {
			type: 'bar',
			data: {
				labels: [<?php echo $result ?>],
				datasets : [{
					label: "Decal Request",
					backgroundColor: 'rgb(23, 125, 255)',
					borderColor: 'rgb(23, 125, 255)',
					data: [<?php echo $resultAll ?>],
				}],
			},
			options: {
				responsive: true, 
				maintainAspectRatio: false,
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero:true
						}
					}]
				}, 
                plugins: {
                    datalabels: {
                        color: 'white',
                        font: {
                        weight: 'bold'
                        },
                        formatter: function(value, context) {
                        return value == 0 ? "" : value;
                        }
                    }
                }
			}
		});
        	
        var myMultipleBarChart = new Chart(multipleBarChart, {
			type: 'bar',
			data: {
				labels: [<?php echo $result ?>],
				datasets : [{
					label: "PENDING",
					backgroundColor: '#fdaf4b',
					borderColor: '#fdaf4b',
					data: [<?php echo $resultPending ?>],
				},{
					label: "REJECTED",
					backgroundColor: '#f25961',
					borderColor: '#f25961',
					data: [<?php echo $resultRejected ?>],
				},{
					label: "APPROVED",
					backgroundColor: '#177dff',
					borderColor: '#177dff',
					data: [<?php echo $resultApproved ?>],
				}, {
					label: "CLAIMED",
					backgroundColor: '#59d05d',
					borderColor: '#59d05d',
					data: [<?php echo $resultClaimed ?>],
				}],
			},
			options: {
				responsive: true, 
				maintainAspectRatio: false,
				legend: {
					position : 'bottom'
				},
				title: {
					display: false,
					text: 'Traffic Stats'
				},
				tooltips: {
					mode: 'index',
					intersect: false
				},
				responsive: true,
				scales: {
					xAxes: [{
						stacked: true,
					}],
					yAxes: [{
						stacked: true
					}]
				},
                plugins: {
                    datalabels: {
                        color: 'white',
                        font: {
                        weight: 'bold'
                        },
                        formatter: function(value, context) {
                        return value == 0 ? "" : value;
                        }
                    }
                }
			}
		});


        <?php  
        $resultDecal= '"' . implode ( '", "', getAllSIODecalType($mysqli) ) . '"';
        $resultA4W  = '"' . implode ( '", "', getAllA4W($mysqli) ) . '"';
        $resultB4WP = '"' . implode ( '", "', getAllB4WP($mysqli) ) . '"';
        $resultB4W  = '"' . implode ( '", "', getAllB4W($mysqli) ) . '"';
        $resultC4W  = '"' . implode ( '", "', getAllC4W($mysqli) ) . '"';
        $resultA2W  = '"' . implode ( '", "', getAllA2W($mysqli) ) . '"';
        $resultB2W  = '"' . implode ( '", "', getAllB2W($mysqli) ) . '"';
        $resultC2W  = '"' . implode ( '", "', getAllC2W($mysqli) ) . '"';
        ?>
        var myMultipleBarChart2 = new Chart(multipleBarChart2, {
			type: 'bar',
			data: {
				labels: [<?php echo $resultDecal ?>],
				datasets : [{
					label: "A-4W",
					backgroundColor: '#59d05d',
					borderColor: '#59d05d',
					data: [<?php echo $resultA4W ?>],
				},{
					label: "B-4W",
					backgroundColor: '#E40C0F',
					borderColor: '#E40C0F',
					data: [<?php echo $resultB4W ?>],
				},{
					label: "B-4WP",
					backgroundColor: '#6B3339',
					borderColor: '#6B3339',
					data: [<?php echo $resultB4WP ?>],
				},{
					label: "C-4W",
					backgroundColor: '#FFFF00',
					borderColor: '#FFFF00',
					data: [<?php echo $resultC4W ?>],
				},{
					label: "A-2W",
					backgroundColor: '#006400',
					borderColor: '#006400',
					data: [<?php echo $resultA2W ?>],
				},{
					label: "B-2W",
					backgroundColor: '#8B0000',
					borderColor: '#8B0000',
					data: [<?php echo $resultB2W ?>],
				},{
					label: "C-2W",
					backgroundColor: '#FFCC00',
					borderColor: '#FFCC00',
					data: [<?php echo $resultC2W ?>],
				}],
			},
			options: {
				responsive: true, 
				maintainAspectRatio: false,
				legend: {
					position : 'bottom'
				},
				title: {
					display: false,
					text: 'Traffic Stats'
				},
				tooltips: {
					mode: 'index',
					intersect: false
				},
				responsive: true,
				scales: {
					xAxes: [{
						stacked: true,
					}],
					yAxes: [{
						stacked: true
					}]
				},
                plugins: {
                    datalabels: {
                        color: 'white',
                        font: {
                        weight: 'bold'
                        },
                        formatter: function(value, context) {
                        return value == 0 ? "" : value;
                        }
                    }
                }
			}
		});

	  	function displayNotification(title1, msg, state, icon){
            if(state == 'success'){
                iziToast.success({title: title1, message: msg, onClosing: function () {},});
            }else{
                iziToast.error({title: title1, message: msg, onClosing: function () {},});
            }
           
           return;
        }

    </script>
<script>
	<?php
		if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
			$state 	= $_SESSION["state"];
			$msg 	= $_SESSION["msg"];
			$title 	= $_SESSION["title"];

			if($state == "success"){
				$icon = "fas fa-check";
			}else if($state == "warning"){
				$icon = "fas fa-exclamation-circle";
			}else if($state == "danger"){
				$icon = "fas fa-exclamation-triangle";
			}?>
				displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>", "<?php echo $icon; ?>");
	<?php } ?>
	</script>

	<?php
		unset($_SESSION["state"]);
		unset($_SESSION["msg"]);
		unset($_SESSION["title"]);
	?>
    <script src="../js/search.js"></script>
</body>
</html>
<?php }else{
    header("Location: ../404");
    return;
}