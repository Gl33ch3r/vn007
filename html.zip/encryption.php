<?php

function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'DEVS-KR-SUMS';
    $secret_iv = 'INFORMATION-SYSTEMS-GROUP-ISG-2020';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

echo "Username: ". encrypt_decrypt("decrypt","MWFKd29iZHUvbnNBQy9WdHd0aS90WXNkYnJIVGtCSUhxb3pHNCtrK2liST0==").", ";
echo "Password: ". encrypt_decrypt("decrypt","MWFKd29iZHUvbnNBQy9WdHd0aS90WXNkYnJIVGtCSUhxb3pHNCtrK2liST0==");
?>
