<?php
session_start();
if(!isset($_COOKIE['user_a']) && !isset($_SESSION['id'])){
    header('Location: login');
}
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/constant.php';
$mysqli = db_connect($config);
$plate_number =  mysqli_real_escape_string($mysqli, htmlspecialchars($_POST["plate_number"], ENT_QUOTES, 'UTF-8'));
$id = mysqli_real_escape_string($mysqli, $_SESSION["id"]);
$response =  loginAdmin($mysqli, $id);
if($response['error']){
    header('Location: ../404');
    return;
}
$ipaddress = getPublicIP();
$responseLogs = addLogs($mysqli, $id, "search plate", "Plate No.: ".$plate_number, $ipaddress, "1");
$responseVehicleInfo = getVehicleInformationByPlate($mysqli, $plate_number);
if(!$responseVehicleInfo["error"]){
$responseDecalInfo = getDecalInformationByVehicleId($mysqli, $responseVehicleInfo["id"]);
$responseUser = getUserByID($mysqli, $responseDecalInfo["user_id"]);
?>

<div class="modal-content">
			<div class="modal-header no-bd">
				<h3 class="modal-title" style="color:black;">
					Search Result
				</h3>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
            <form>
                <div class="modal-body">
                <table class="table table-responsive table-inverse table-hover table-striped" width="100%">
                    <thead>
                        <tr>
                            <th>Plate No.</th>
                            <th>Owner</th>
                            <th>Model</th>
                            <th>Released by</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                    <tr>                                    
                        <?php $responseAdmin = loginAdmin($mysqli, $responseDecalInfo["released_by"]); ?>
                        <td><p><?php echo $responseVehicleInfo['plate_number']; ?></p></td>
                        <td><p><a href="view-user/<?php echo $responseUser['id'] ?>"><?php echo $responseUser['firstname'] . " " . $responseUser['lastname'] ?> </a></p></td>
                        <td><p><?php echo $responseVehicleInfo['vehicle_maker']." - " .$responseVehicleInfo['vehicle_model'] ." - " .$responseVehicleInfo['year_model']." - " .$responseVehicleInfo['vehicle_color'] ?></p></td>
                        <td><p><?php echo $responseAdmin["account_name"]. " - " .  getSioName($mysqli, $responseAdmin["sio_id"])["sio_name"] ?></p></td>
                      
                    </tr>
                    </tbody>
                </table>
                </div>
                <div class="modal-footer no-bd">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </form>
		</div>
<?php } else {?>
    <div class="modal-content">
			<div class="modal-header no-bd">
				<h3 class="modal-title" style="color:black;">
					Search Result
				</h3>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
            <form>
                <div class="modal-body">
                <center><h2><b> No Records </b></h2></center>
                    
                </div>
                <div class="modal-footer no-bd">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </form>
		</div>
<?php } ?>