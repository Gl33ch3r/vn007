$(document).ready(function(){
    function displayNotification(title1, msg, state){
        if(state == 'success'){
            iziToast.success({title: title1, message: msg, onClosing: function () {},});
        }else{
            iziToast.error({title: title1, message: msg, onClosing: function () {},});
        }
        return;
    }   
 
    var gallery = $('#photoviewer').simpleLightbox();
    var classification = $("#classification").val();
    var active = $("#active");
    var retired = $("#retired");
    var chr = $("#chr");
    var chrid = $("#chrid");
    var dep_a = $("#dependent_active");
    var dep_r = $("#dependent_retired");
    var others = $("#others");
    var reservist = $("#reservist");

    switch (classification) {
        case "1":
            active.removeClass("nd");
            retired.addClass("nd");
            reservist.addClass("nd");
            chr.addClass("nd");
            dep_a.addClass("nd");
            dep_r.addClass("nd");
            others.addClass("nd");
            chrid.addClass("nd");
            break;
        case "2":
            active.addClass("nd");
            retired.removeClass("nd");
            reservist.addClass("nd");
            chr.addClass("nd");
            dep_a.addClass("nd");
            dep_r.addClass("nd");
            others.addClass("nd");
            chrid.addClass("nd");
            break;
        case "3":
            active.addClass("nd");
            retired.addClass("nd");
            reservist.removeClass("nd");
            chr.addClass("nd");
            dep_a.addClass("nd");
            dep_r.addClass("nd");
            others.addClass("nd");
            chrid.addClass("nd");
            break;
        case "4":
            active.addClass("nd");
            retired.addClass("nd");
            reservist.addClass("nd");
            chr.removeClass("nd");
            dep_a.addClass("nd");
            dep_r.addClass("nd");
            others.addClass("nd");
            chrid.removeClass("nd");
            break;
        case "5":
            active.addClass("nd");
            retired.addClass("nd");
            reservist.addClass("nd");
            chr.removeClass("nd");
            dep_a.addClass("nd");
            dep_r.addClass("nd");
            others.addClass("nd");
            chrid.addClass("nd");
            break;
        case "6":
            active.addClass("nd");
            retired.addClass("nd");
            reservist.addClass("nd");
            chr.addClass("nd");
            dep_a.removeClass("nd");
            dep_r.addClass("nd");
            others.addClass("nd");
            chrid.addClass("nd");
            break;
        case "7":
            active.addClass("nd");
            retired.addClass("nd");
            reservist.addClass("nd");
            chr.addClass("nd");
            dep_a.addClass("nd");
            dep_r.removeClass("nd");
            others.addClass("nd");
            chrid.addClass("nd");
            break;
        default:
            active.addClass("nd");
            retired.addClass("nd");
            reservist.addClass("nd");
            chr.addClass("nd");
            dep_a.addClass("nd");
            dep_r.addClass("nd");
            others.removeClass("nd");
            chrid.addClass("nd");              
        }


    $('#classification').on('change', function() {
        switch (this.value) {
            case "1":
                active.removeClass("nd");
                retired.addClass("nd");
                reservist.addClass("nd");
                chr.addClass("nd");
                dep_a.addClass("nd");
                dep_r.addClass("nd");
                others.addClass("nd");
                chrid.addClass("nd");
                break;
            case "2":
                active.addClass("nd");
                retired.removeClass("nd");
                reservist.addClass("nd");
                chr.addClass("nd");
                dep_a.addClass("nd");
                dep_r.addClass("nd");
                others.addClass("nd");
                chrid.addClass("nd");
                break;
            case "3":
                active.addClass("nd");
                retired.addClass("nd");
                reservist.removeClass("nd");
                chr.addClass("nd");
                dep_a.addClass("nd");
                dep_r.addClass("nd");
                others.addClass("nd");
                chrid.addClass("nd");
                break;
            case "4":
                active.addClass("nd");
                retired.addClass("nd");
                reservist.addClass("nd");
                chr.removeClass("nd");
                dep_a.addClass("nd");
                dep_r.addClass("nd");
                others.addClass("nd");
                chrid.removeClass("nd");
                break;
            case "5":
                active.addClass("nd");
                retired.addClass("nd");
                reservist.addClass("nd");
                chr.removeClass("nd");
                dep_a.addClass("nd");
                dep_r.addClass("nd");
                others.addClass("nd");
                chrid.addClass("nd");
                break;
            case "6":
                active.addClass("nd");
                retired.addClass("nd");
                reservist.addClass("nd");
                chr.addClass("nd");
                dep_a.removeClass("nd");
                dep_r.addClass("nd");
                others.addClass("nd");
                chrid.addClass("nd");
                break;
            case "7":
                active.addClass("nd");
                retired.addClass("nd");
                reservist.addClass("nd");
                chr.addClass("nd");
                dep_a.addClass("nd");
                dep_r.removeClass("nd");
                others.addClass("nd");
                chrid.addClass("nd");
                break;
            default:
                active.addClass("nd");
                retired.addClass("nd");
                reservist.addClass("nd");
                chr.addClass("nd");
                dep_a.addClass("nd");
                dep_r.addClass("nd");
                others.removeClass("nd");
                chrid.addClass("nd");              
        }
    });


    $("#lastname").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#firstname").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#middlename").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });

    $("#address").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#serial_number_a").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#designation_a").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_a").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_address_a").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    }); 
    
    $("#designation_b").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_b").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_address_b").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });

    $("#serial_number_r").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#designation_r").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_r").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_address_r").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });

    $("#serial_number_c").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#designation_c").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_c").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_address_c").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });

    $("#dependent_of_d").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });

    $("#serial_number_d").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#designation_d").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_d").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_address_d").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });

    $("#dependent_of_e").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });

    $("#designation_e").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_e").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_address_e").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });

    $("#designation_f").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_f").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });  

    $("#unit_address_f").keyup(function () {  
        $(this).val($(this).val().toUpperCase());  
    });
    
    $("#phone").keydown(function(event) {
        var ASCIICode = (event.which) ? event.which : event.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    });

    $("#phone").keydown(function(event) {
        var ASCIICode = (event.which) ? event.which : event.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    });

    $("#unit_mobile_a").keydown(function(event) {
        var ASCIICode = (event.which) ? event.which : event.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    });

    $("#unit_mobile_b").keydown(function(event) {
        var ASCIICode = (event.which) ? event.which : event.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    });

    $("#unit_mobile_c").keydown(function(event) {
        var ASCIICode = (event.which) ? event.which : event.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    });

    $("#unit_mobile_d").keydown(function(event) {
        var ASCIICode = (event.which) ? event.which : event.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    });

    $("#unit_mobile_e").keydown(function(event) {
        var ASCIICode = (event.which) ? event.which : event.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    });

    $("#unit_mobile_f").keydown(function(event) {
        var ASCIICode = (event.which) ? event.which : event.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    });

    $("#unit_mobile_r").keydown(function(event) {
        var ASCIICode = (event.which) ? event.which : event.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    });

    $("#date_enlisted_c").keydown(function(event) {
        var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
        if (keyCode == 13) {
            var i;
            for (i = 0; i < this.form.elements.length; i++)
                if (this == this.form.elements[i])
                    break;
            i = (i + 1) % this.form.elements.length;
            this.form.elements[i].focus();
            return false;
        } else
            return true;
    });

    $("#date_retired_c").keydown(function(event) {
        var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
        if (keyCode == 13) {
            var i;
            for (i = 0; i < this.form.elements.length; i++)
                if (this == this.form.elements[i])
                    break;
            i = (i + 1) % this.form.elements.length;
            this.form.elements[i].focus();
            return false;
        } else
            return true;
    });

    
    $("#date_enlisted_a").keydown(function(event) {
        var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
        if (keyCode == 13) {
            var i;
            for (i = 0; i < this.form.elements.length; i++)
                if (this == this.form.elements[i])
                    break;
            i = (i + 1) % this.form.elements.length;
            this.form.elements[i].focus();
            return false;
        } else
            return true;
    });

    $("#date_retired_a").keydown(function(event) {
        var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
        if (keyCode == 13) {
            var i;
            for (i = 0; i < this.form.elements.length; i++)
                if (this == this.form.elements[i])
                    break;
            i = (i + 1) % this.form.elements.length;
            this.form.elements[i].focus();
            return false;
        } else
            return true;
    });

    $("#birthdate").keydown(function(event) {
        var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
        if (keyCode == 13) {
            var i;
            for (i = 0; i < this.form.elements.length; i++)
                if (this == this.form.elements[i])
                    break;
            i = (i + 1) % this.form.elements.length;
            this.form.elements[i].focus();
            return false;
        } else
            return true;
    });

    $('#profileForm').submit(function() {
        if ($.trim($("#uploaded_profile_file_name").val()) === "" || $.trim($("#firstname").val()) === "" || $.trim($("#lastname").val()) === "" || $.trim($("#address").val()) === "" || $.trim($("#birthdate").val()) === "" || $.trim($("#phone").val()) === "")  {
            return false;
        }
        if($("#classification").val()=="1"){
            if ($.trim($("#bos_a").val()) === "" || $.trim($("#rank_a").val()) === "" || $.trim($("#date_enlisted_a").val()) === "" || $.trim($("#date_retired_a").val()) === "" || $.trim($("#serial_number_a").val()) === "" || $.trim($("#designation_a").val()) === "" || $.trim($("#unit_a").val()) === "" || $.trim($("#unit_mobile_a").val()) === "" || $.trim($("#unit_address_a").val()) === "")  {
                return false;
            }
        }else if($("#classification").val()=="2"){
            if ($.trim($("#bos_b").val()) === "" || $.trim($("#rank_b").val()) === "" || $.trim($("#designation_b").val()) === "" || $.trim($("#unit_b").val()) === "" || $.trim($("#unit_mobile_b").val()) === "" || $.trim($("#unit_address_b").val()) === "")  {
                return false;
            }
        }else if($("#classification").val()=="3"){
            if ($.trim($("#bos_r").val()) === "" || $.trim($("#rank_r").val()) === "" || $.trim($("#serial_number_r").val()) === "" || $.trim($("#designation_r").val()) === "" || $.trim($("#unit_r").val()) === "" || $.trim($("#unit_mobile_r").val()) === "" || $.trim($("#unit_address_r").val()) === "")  {
                return false;
            }
        }else if($("#classification").val()=="4"){
            if ($.trim($("#bos_c").val()) === "" || $.trim($("#date_enlisted_c").val()) === "" || $.trim($("#date_retired_c").val()) === "" || $.trim($("#serial_number_c").val()) === "" || $.trim($("#designation_c").val()) === "" || $.trim($("#unit_c").val()) === "" || $.trim($("#unit_mobile_c").val()) === "" || $.trim($("#unit_address_c").val()) === "")  {
                return false;
            }
        }else if($("#classification").val()=="5"){
            if ($.trim($("#bos_c").val()) === "" || $.trim($("#date_enlisted_c").val()) === "" || $.trim($("#date_retired_c").val()) === "" || $.trim($("#designation_c").val()) === "" || $.trim($("#unit_c").val()) === "" || $.trim($("#unit_mobile_c").val()) === "" || $.trim($("#unit_address_c").val()) === "")  {
                return false;
            }
        }else if($("#classification").val()=="6"){
            if ($.trim($("#dependent_of_d").val()) === ""  || $.trim($("#bos_d").val()) === ""  || $.trim($("#serial_number_d").val()) === "" || $.trim($("#designation_d").val()) === "" || $.trim($("#unit_d").val()) === "" || $.trim($("#unit_mobile_d").val()) === "" || $.trim($("#unit_address_d").val()) === "")  {
                return false;
            }
        }else if($("#classification").val()=="7"){
            if ($.trim($("#dependent_of_e").val()) === ""  || $.trim($("#bos_e").val()) === "" || $.trim($("#designation_e").val()) === "" || $.trim($("#unit_e").val()) === "" || $.trim($("#unit_mobile_e").val()) === "" || $.trim($("#unit_address_e").val()) === "")  {
                return false;
            }
        }else{
            if ($.trim($("#designation_f").val()) === "" || $.trim($("#unit_f").val()) === "" || $.trim($("#unit_mobile_f").val()) === "" || $.trim($("#unit_address_f").val()) === "")  {
                return false;
            }
        }
    });

    $("#submit-btn").click(function(){
        var fname = $("#firstname").val();
        var lname = $("#lastname").val();
        var mname = $("#middlename").val();
        var address = $("#address").val();
        var birthdate = $("#birthdate").val();
        var phone = $("#phone").val();
        var uploaded_profile_file_name = $("#uploaded_profile_file_name").val();

        if(uploaded_profile_file_name.length == 0) {
            displayNotification("Error", "Please upload your profile picture!", "danger");
            return;
        } 
    
        if(lname.length == 0) {
            displayNotification("Error", "Please enter Lastname!", "danger");
            return;
        } 
        if(fname.length == 0) {
            displayNotification("Error", "Please enter Firstname!", "danger");
            return;
        } 
        if(address.length == 0) {
            displayNotification("Error", "Please enter Complete Address!", "danger");
            return;
        } 

        if(phone.length == 0) {
            displayNotification("Error", "Please enter Mobile Number!", "danger");
            return;
        } 

        if(birthdate.length == 0) {
            displayNotification("Error", "Please enter Birthdate!", "danger");
            return;
        } 

        if($("#classification").val()=="1"){
            if ($.trim($("#date_enlisted_a").val()) === "")  {
                displayNotification("Error", "Please enter your Enlistment Date!", "danger");
                return false;
            }
            if ($.trim($("#date_retired_a").val()) === "")  {
                displayNotification("Error", "Please enter your Retirement Date!", "danger");
                return false;
            }
            if ($.trim($("#serial_number_a").val()) === "")  {
                displayNotification("Error", "Please enter your Serial Number!", "danger");
                return false;
            }
            if ($.trim($("#designation_a").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger");
                return false;
            }
            if ($.trim($("#unit_a").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger");
                return false;
            }
            if ($.trim($("#unit_mobile_a").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger");
                return false;
            }
            if ($.trim($("#unit_address_a").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger");
                return false;
            }
        }else if($("#classification").val()=="2"){
            if ($.trim($("#designation_b").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger");
                return false;
            }
            if ($.trim($("#unit_b").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger");
                return false;
            }
            if ($.trim($("#unit_mobile_b").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger");
                return false;
            }
            if ($.trim($("#unit_address_b").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger");
                return false;
            }
        }else if($("#classification").val()=="3"){
            if ($.trim($("#serial_number_r").val()) === "")  {
                displayNotification("Error", "Please enter your Serial Number!", "danger");
                return false;
            }
            if ($.trim($("#designation_r").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger");
                return false;
            }
            if ($.trim($("#unit_r").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger");
                return false;
            }
            if ($.trim($("#unit_mobile_r").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger");
                return false;
            }
            if ($.trim($("#unit_address_r").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger");
                return false;
            }
        }else if($("#classification").val()=="4"){
            if ($.trim($("#date_enlisted_c").val()) === "")  {
                displayNotification("Error", "Please enter your Employment Date!", "danger");
                return false;
            }
            if ($.trim($("#date_retired_c").val()) === "")  {
                displayNotification("Error", "Please enter your Retirement Date!", "danger");
                return false;
            }
            if ($.trim($("#serial_number_c").val()) === "")  {
                displayNotification("Error", "Please enter your CivHR Number!", "danger");
                return false;
            }
            if ($.trim($("#designation_c").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger");
                return false;
            }
            if ($.trim($("#unit_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger");
                return false;
            }
            if ($.trim($("#unit_mobile_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger");
                return false;
            }
            if ($.trim($("#unit_address_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger");
                return false;
            }
        }else if($("#classification").val()=="5"){
            if ($.trim($("#date_enlisted_c").val()) === "")  {
                displayNotification("Error", "Please enter your Employment Date!", "danger");
                return false;
            }
            if ($.trim($("#date_retired_c").val()) === "")  {
                displayNotification("Error", "Please enter your Retirement Date!", "danger");
                return false;
            }
            if ($.trim($("#designation_c").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger");
                return false;
            }
            if ($.trim($("#unit_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger");
                return false;
            }
            if ($.trim($("#unit_mobile_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger");
                return false;
            }
            if ($.trim($("#unit_address_c").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger");
                return false;
            }
        }else if($("#classification").val()=="6"){
            if ($.trim($("#dependent_of_d").val()) === "")  {
                displayNotification("Error", "Please enter Dependent of?", "danger");
                return false;
            }
            if ($.trim($("#serial_number_d").val()) === "")  {
                displayNotification("Error", "Please enter your Serial Number!", "danger");
                return false;
            }
            if ($.trim($("#designation_d").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger");
                return false;
            }
            if ($.trim($("#unit_d").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Assignment!", "danger");
                return false;
            }
            if ($.trim($("#unit_mobile_d").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Mobile Number!", "danger");
                return false;
            }
            if ($.trim($("#unit_address_d").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Address!", "danger");
                return false;
            }
        }else if($("#classification").val()=="7"){
            if ($.trim($("#dependent_of_e").val()) === "")  {
                displayNotification("Error", "Please enter Dependent of?", "danger");
                return false;
            }
            if ($.trim($("#designation_e").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger");
                return false;
            }
            if ($.trim($("#unit_e").val()) === "")  {
                displayNotification("Error", "Please enter your Company Name", "danger");
                return false;
            }
            if ($.trim($("#unit_mobile_e").val()) === "")  {
                displayNotification("Error", "Please enter your Company Mobile Number!", "danger");
                return false;
            }
            if ($.trim($("#unit_address_e").val()) === "")  {
                displayNotification("Error", "Please enter your Company Address!", "danger");
                return false;
            }
        }else{
            if ($.trim($("#designation_f").val()) === "")  {
                displayNotification("Error", "Please enter your Designation/Office!", "danger");
                return false;
            }
            if ($.trim($("#unit_f").val()) === "")  {
                displayNotification("Error", "Please enter your Company Name!", "danger");
                return false;
            }
            if ($.trim($("#unit_mobile_f").val()) === "")  {
                displayNotification("Error", "Please enter your Unit Company Number!", "danger");
                return false;
            }
            if ($.trim($("#unit_address_f").val()) === "")  {
                displayNotification("Error", "Please enter your Company Address!", "danger");
                return false;
            }
        }

        var csrftoken = $("#csrftoken").val();
        var profile = $("#uploaded_profile_file_name").val();
        var firstname = $("#firstname").val();
        var lastname = $("#lastname").val();
        var middlename = $("#middlename").val();
        var address = $("#address").val();
        var birthdate = $("#birthdate").val();
        var phone = $("#phone").val();
        var classification = $("#classification").val();

        switch (classification) {
            case "1":
                var bos = $("#bos_a").val();
                var rank = $("#rank_a").val();
                var date_enlisted = $("#date_enlisted_a").val();
                var date_retired = $("#date_retired_a").val();
                var serial_number = $("#serial_number_a").val();
                var designation = $("#designation_a").val();
                var unit = $("#unit_a").val();
                var unit_mobile = $("#unit_mobile_a").val();
                var unit_address = $("#unit_address_a").val();
                var dependent_of = "";
            break;
            case "2":
                var bos = $("#bos_b").val();
                var rank = $("#rank_b").val();
                var date_enlisted = "";
                var date_retired = "";
                var serial_number = "";
                var designation = $("#designation_b").val();
                var unit = $("#unit_b").val();
                var unit_mobile = $("#unit_mobile_b").val();
                var unit_address = $("#unit_address_b").val();
                var dependent_of = "";
            break;
            case "3":
                var bos = $("#bos_r").val();
                var rank = $("#rank_r").val();
                var date_enlisted = "";
                var date_retired = "";
                var serial_number = $("#serial_number_r").val();
                var designation = $("#designation_r").val();
                var unit = $("#unit_r").val();
                var unit_mobile = $("#unit_mobile_r").val();
                var unit_address = $("#unit_address_r").val();
                var dependent_of = "";
            break;
            case "4":
                var bos = $("#bos_c").val();
                var rank = "";
                var date_enlisted = $("#date_enlisted_c").val();
                var date_retired = $("#date_retired_c").val();
                var serial_number = $("#serial_number_c").val();
                var designation = $("#designation_c").val();
                var unit = $("#unit_c").val();
                var unit_mobile = $("#unit_mobile_c").val();
                var unit_address = $("#unit_address_c").val();
                var dependent_of = "";
            break;
            case "5":
                var bos = $("#bos_c").val();
                var rank = "";
                var date_enlisted = $("#date_enlisted_c").val();
                var date_retired = $("#date_retired_c").val();
                var serial_number = "";
                var designation = $("#designation_c").val();
                var unit = $("#unit_c").val();
                var unit_mobile = $("#unit_mobile_c").val();
                var unit_address = $("#unit_address_c").val();
                var dependent_of = "";
            break;
            case "6":
                var bos = $("#bos_d").val();
                var rank = "";
                var date_enlisted = "";
                var date_retired = "";
                var serial_number = $("#serial_number_d").val();
                var designation = $("#designation_d").val();
                var unit = $("#unit_d").val();
                var unit_mobile = $("#unit_mobile_d").val();
                var unit_address = $("#unit_address_d").val();
                var dependent_of = $("#dependent_of_d").val();
            break;
            case "7":
            
                var bos = $("#bos_e").val();
                var rank = "";
                var date_enlisted = "";
                var date_retired = "";
                var serial_number = "";
                var designation = $("#designation_e").val();
                var unit = $("#unit_e").val();
                var unit_mobile = $("#unit_mobile_e").val();
                var unit_address = $("#unit_address_e").val();
                var dependent_of = $("#dependent_of_e").val();
            break;
            case "8":
                var bos = "";
                var rank = "";
                var date_enlisted = "";
                var date_retired = "";
                var serial_number = "";
                var designation = $("#designation_f").val();
                var unit = $("#unit_f").val();
                var unit_mobile = $("#unit_mobile_f").val();
                var unit_address = $("#unit_address_f").val();
                var dependent_of = "";
            break;
            case "9":
                var bos = "";
                var rank = "";
                var date_enlisted = "";
                var date_retired = "";
                var serial_number = "";
                var designation = $("#designation_f").val();
                var unit = $("#unit_f").val();
                var unit_mobile = $("#unit_mobile_f").val();
                var unit_address = $("#unit_address_f").val();
                var dependent_of = "";
            break;
            case "10":
                var bos = "";
                var rank = "";
                var date_enlisted = "";
                var date_retired = "";
                var serial_number = "";
                var designation = $("#designation_f").val();
                var unit = $("#unit_f").val();
                var unit_mobile = $("#unit_mobile_f").val();
                var unit_address = $("#unit_address_f").val();
                var dependent_of = "";
            break;

        }

    
        $.ajax({
            type: "POST",
            url: "process-profile.php",
            data: { 'csrftoken': csrftoken, 'uploaded_profile_file_name': profile, 'firstname': firstname, 'lastname': lastname, 'middlename': middlename, 'address': address, 'birthdate': birthdate, 'phone': phone, 'classification': classification, 'bos': bos, 'rank': rank ,   'date_enlisted': date_enlisted, 'date_retired': date_retired, 'serial_number': serial_number, 'designation': designation, 'unit': unit, 'unit_mobile': unit_mobile, 'unit_address': unit_address, 'dependent_of': dependent_of },
            dataType : 'json',
            cache: false,
            success: function(response) {
                if(response.error){
                    iziToast.error({title: 'OK', message: response.msg, onClosing: function () {},});
                    
                }else{
                    swal({
                        allowOutsideClick: false,
                        closeOnClickOutside: false,
                        title: "Good job!",
                        text: response.msg,
                        icon: "success",
                        timer: 2000,
                        buttons: false,
                    });
                }
            },
            failure: function (response) {
                swal("Internal Error","Oops, something went wrong.", "error")
            }
        });
    
    });

    $("#lastname").keyup(function () {
        if($("#lastname").val() === ""){
            $("#lastname").addClass("invalid");
            $("#lastname").removeClass("valid");
        }else{
            $("#lastname").addClass("valid");
            $("#lastname").removeClass("invalid");
        }
    });

    $("#firstname").keyup(function () {
        if($("#firstname").val() === ""){
            $("#firstname").addClass("invalid");
            $("#firstname").removeClass("valid");
        }else{
            $("#firstname").addClass("valid");
            $("#firstname").removeClass("invalid");
        }
    });

    $("#address").keyup(function () {
        if($("#address").val() === ""){
            $("#address").addClass("invalid");
            $("#address").removeClass("valid");
        }else{
            $("#address").addClass("valid");
            $("#address").removeClass("invalid");
        }
    });

    $("#birthdate").keyup(function () {
        if($("#birthdate").val() === ""){
            $("#birthdate").addClass("invalid2");
            $("#birthdate").removeClass("valid2");
        }else{
            $("#birthdate").addClass("valid2");
            $("#birthdate").removeClass("invalid2");
        }
    });
    

    $("#phone").keyup(function () {
        if($("#phone").val().length == 12){
            $("#phone").addClass("valid");
            $("#phone").removeClass("invalid");
        }else{
            $("#phone").addClass("invalid");
            $("#phone").removeClass("valid");
        }
    });

    $('#logout-btn-nav').click(function(e) {
        swal({
            title: 'Are you sure?',
            text: 'It will automatically logout your account!',
            type: 'warning',
            buttons:{
                confirm: {
                    text : 'yes',
                    className : 'btn btn-success'
                },
                cancel: {
                    visible: true,
                    className: 'btn btn-danger',
                    text : 'No'
                }
            }
        }).then((confirm) => {
            if (confirm) {
                window.location='logout' 
            } else {
                swal.close();
            }
        });
    });

    $('#logout-btn').click(function(e) {
        swal({
            title: 'Are you sure?',
            text: 'It will automatically logout your account!',
            type: 'warning',
            buttons:{
                confirm: {
                    text : 'yes',
                    className : 'btn btn-success'
                },
                cancel: {
                    visible: true,
                    className: 'btn btn-danger',
                    text : 'No'
                }
            }
        }).then((confirm) => {
            if (confirm) {
                window.location='logout' 
            } else {
                swal.close();
            }
        });
    });

    
    var allCount = $("#count-all");

    if($("#request-li").hasClass('active')){
        allCount.addClass("nd");
    }
    $('#toggle-btn').click(function(e) {
        if(!$("#base").hasClass('show')){
            allCount.addClass("nd");
        } else {
            allCount.removeClass("nd");
        }
    });

});
