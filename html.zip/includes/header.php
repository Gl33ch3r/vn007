<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="theme-color" content="#2A3A4B">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'self' 'nonce-8db0369dff542ac448aa8f9e8ceaece603fe3de4ea9afbea19a46f4b87f4959b' 'nonce-87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d'; style-src 'self' 'nonce-87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d'; font-src 'self'; connect-src 'self'; img-src 'self' data:; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none';"/>
        <meta NAME="copyright" content="Philippine Navy Electronic Decal System">
        <meta NAME="author" content="Technical Intelligence Branch - N2 - GL33CH3R">
        <meta NAME="revised" content="MARCH 2022">
        <title><?php echo APP . $page  ?></title>
        <link rel="icon" type="image/png" href="<?php echo ICO ?>">
        <link rel="stylesheet" href="/css/container.css" type='text/css'/>
        <link rel="stylesheet" href="/css/loading.css" type='text/css'/>
        <link rel="stylesheet" href="/css/all.css" as="style">
        <link rel="stylesheet" href="/assets/css/font.nunito.css" type='text/css'>
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/dist/css/iziToast.min.css"/>
        <script type="text/javascript" src="/js/jquery.min.js"></script>
        <script type="text/javascript" src="/js/loading.js"></script>
    </head>
        <body>