<?php
include_once 'includes/csrf.php';
session_start();
if(!isset($_COOKIE['user_c']) && !isset($_SESSION['email'])){
    header('Location: login');
}
include_once 'includes/config.php';
include_once 'includes/functions.php';
include_once 'includes/constant.php';

$csrf = new CSRF(
    'session-hashes', 
    'csrftoken',       
    5*60,
    256
  );

$mysqli = db_connect($config);
$email = $_SESSION["email"];
$response =  loginAccount($mysqli, $email);
if($response['error']){
  session_destroy();
  unset($_SESSION['email']);
  setcookie("user_c", "", time() - 3600);
  header('Location: login');
  return;
}
include_once 'includes/header-home.php';
?>
<body data-background-color="dark">
	<div class="wrapper">
        <?php include "includes/navbar.php" ?>
		<?php include "includes/sidebar.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["firstname"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<form class="card" id="changePasswordForm">
                            <?=$csrf->input('changepassword');?>
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Change Password</h4>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
                                        <div class="col-md-5  mx-auto">   
											<div class="form-group">
												<label for="oldpassword">Current Password</label>
												<input type="password" class="form-control" id="oldpassword" name="oldpassword" placeholder="Current Password">
											</div>
                                            <div class="form-group">
												<label for="newpassword">New Password</label>
												<input type="password" class="form-control" id="password" name="password" placeholder="New Password">
											</div>
                                            <div class="form-group">
												<label for="confirmpassword">Confirm Password</label>
												<input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Confirm New Password">
											</div>
                                        
											<div class="card-action">
                                                <div class="d-flex justify-content-center">
                                                	<button type="button" id="submit-btn" class="btn btn-success btn-round pr-5 pl-5">Submit</button>
												</div>
                                            </div>
                                        </div>
									</div>
								</div>
                            </form>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>
    <div class="overlay"></div>
    <!--   Core JS Files   -->
	<script src="/assets/js/core/popper.min.js"></script>
	<script src="/assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="/assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="/assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

	<!-- Chart Circle -->
	<script src="/assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="/assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="/assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="/assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script nonce="87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d" type="text/javascript" src="/assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="/assets/js/atlantis.min.js"></script>
    
    <script src="/dist/js/iziToast.min.js"></script>

    <script src="/js/upload.js"></script>
    <script src="/js/change.password.js"></script>
</body>
</html>