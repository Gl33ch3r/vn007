<?php
session_start();
if(!isset($_COOKIE['user_c']) && !isset($_SESSION['email'])){
    header('Location: login');
}
include_once 'includes/config.php';
include_once 'includes/functions.php';
include_once 'includes/constant.php';
$mysqli = db_connect($config);
$email = mysqli_real_escape_string($mysqli, $_SESSION["email"]);
$response =  loginAccount($mysqli, $email);
if($response['error']){
  session_destroy();
  unset($_SESSION['email']);
  setcookie("user_c", "", time() - 3600);
  header('Location: login');
  return;
}
include_once 'includes/header-home.php';
?>
<body data-background-color="dark">
	<div class="wrapper">
		<?php include "includes/navbar.php" ?>
		<?php include "includes/sidebar.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["firstname"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Transaction History</h4>
									</div>
								</div>
                                <div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Date Applied</th>
													<th>Plate No.</th>
													<th>Manufacturer</th>
													<th>Model</th>
													<th>Remarks</th>
													<th>Status</th>
													<th class="w10">Action</th>
												</tr>
											</thead>
											<tbody>
												<?php
													$responseDecalInfo = getAllDecalInfoHistory($mysqli, $response["id"]);
													while($u = mysqli_fetch_array($responseDecalInfo)) {
														$vehicle_id         = $u["vehicle_id"];
														$status        		= $u["status"];
                                                        $aid                = $u["application_id"];
														$has_deficiency     = $u["has_deficiency"];
														$is_claimed 		= $u["is_claimed"];
														if($status == "0" && $has_deficiency){
															$stataFlag = "<span class='align-middle nr700'>Pending - Has Deficiency</span>";
															$remarks = $u["remarks"];
														}elseif($status == "0" && !$has_deficiency){
															$stataFlag = "<span class='align-middle no700'>Pending</span>";
															$remarks = "NONE";
														}else if($status == "1" && $is_claimed){
															$stataFlag = "<span class='align-middle ng700'>Claimed</span>";
															$responseSio	   = getSioName($mysqli, $u["sio_id"]);
															$remarks = "Claimed by ".$u["claimed_by"]." @ ".$responseSio["sio_name"]. " on ".$u["date_claimed"]; 
														}else if($status == "1" && !$is_claimed){
															$stataFlag = "<span class='align-middle ng700'>Approved</span>";
															$remarks = "NONE";
														}else if($status == "2"){
															$stataFlag = "<span class='align-middle nr700'>Rejected</span>";
															$remarks = $u["remarks"];
														}else if($status == "3"){
															$stataFlag = "<span class='align-middle ng700'>Claimed</span>";
														}
														
														$response = getVehicleInformation($mysqli, $vehicle_id);
														
												?>
												<tr>
													<td><?php echo $u["create_at"] ?></td>
													<td><?php echo $response["plate_number"] ?></td>
													<td><?php echo $response["vehicle_maker"] ?></td>
													<td><?php echo $response["vehicle_model"] ?></td>
													<td><?php echo $remarks ?></td>
													<td><?php echo $stataFlag ?></td>
													<td>
														<div class="form-button-action">
                                                            <?php 
                                                                if($status == "1"){ 
                                                                    $date = $u["create_at"];
                                                                    $newdate = date('d-m-Y',strtotime($date));
                                                                    $current = date('Y') - 1;
                                                                    $responsePlate = getVehicleInformationByPlate($mysqli, $response["plate_number"]);

                                                                    if($current == date('Y', strtotime($newdate)) && !isVehicleExist($mysqli, $responsePlate["id"])){
                                                            		?>
                                                                    <a type="button" data-toggle="tooltip" href="/renew/<?php echo $aid; ?>/<?php echo base64_encode($curPageName) ?>" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Renew Decal">
                                                                        <b>Renew</b>
                                                                    </a>
																<?php }else{ ?>
																	<a type="button" data-toggle="tooltip" href="/view/<?php echo $aid; ?>/<?php echo base64_encode($curPageName) ?>" title="" class="btn btn-link btn-primary btn-lg" data-original-title="View Decal">
																		<b>View</b>
																	</a>
																<?php }
																}?>
														</div>
													</td>
												</tr>

												<?php } ?>
												
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
			
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>

	<?php include "includes/app.javascript.php"; ?>
</body>
</html>