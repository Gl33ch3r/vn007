<?php
header("Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'none'; font-src 'none'; connect-src 'none'; img-src 'none'; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none'; frame-ancestors 'none'; form-action 'none';");
include_once 'includes/csrf.php';
include_once 'includes/session.php';
require_once "includes/constant.php";
require_once "includes/config.php";
require_once "includes/functions.php";
require_once "mailer.php";
$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);
if(MAINTENANCE == "1"){
	header("Location: /maintenance");
	return;
}

$mysqli = db_connect($config);
$responseSignUp = array();
if(!$csrf->validate('signup')) {
  $responseSignUp["error"] = true;
  $responseSignUp["msg"] = "CSRF: Verification has been unsuccessful";
  echo json_encode($responseSignUp);
  return;
}

if(!isset($_POST['email']) && !isset($_POST['captcha'])){
  $responseSignUp["error"] = true;
  $responseSignUp["msg"] ="Error occured while sending activation code.";
  echo json_encode($responseSignUp);
  return;
}

$captcha_challenge = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['captcha'], ENT_QUOTES, 'UTF-8'));
$email = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8'));
$code  = generateActivationCode();
if(isset($captcha_challenge) && $captcha_challenge != $_SESSION['captcha_text']) {
  $responseSignUp["error"] = true;
  $responseSignUp["msg"] = "Incorrect Captcha, Please try again!";
  unset ($_SESSION["captcha_text"]);
  echo json_encode($responseSignUp);
  return;
}

if(!emailCheck($mysqli, $email)){
  $subject = "Please activate your Philippine Navy Decal System Account";
  $content = "<center><b>Welcome to Philippine Navy Decal System, ".$email."!</b> <br><br> To activate your account, please click on the button below to verify your email address. Once activated, 
  you'll have full access to Philippine Navy Decal System.<br> <br><a href='https://".$_SERVER['SERVER_NAME']."/activate?code=".$code."&email=".$email."'>Activate Account</a><br><br>
  <hr style='border-bottom:#e4e4ed 5px dotted;border-width:0 0 5px 0'><br> Button not working? Try pasting this URL into your browser: 
  <strong><a href='https://".$_SERVER['SERVER_NAME']."/activate?code=".$code."&email=".$email."'>https://".$_SERVER['SERVER_NAME']."/activate?code=".$code."&email=".$email."</a></center>";
  
  $responseMail = sendMail($email, $subject, $content);
  if($responseMail["error"]) {
    $responseSignUp["error"] = true;
    $responseSignUp["msg"] ="Error occured while sending activation code.";
    echo json_encode($responseSignUp);
    return;
  }

  $response = createAccount($mysqli, $email, $code);
  if($response['error']){
    $responseSignUp["error"] = true;
    $responseSignUp["msg"] ="Error occured while sending activation code.";
    echo json_encode($responseSignUp);
    return;
  }

  $responseSignUp["error"] = false;
  $responseSignUp["msg"] = "Activation Email Sent, Please check your email for activation.";
  $responseSignUp["email"] = $email;
  echo json_encode($responseSignUp);
  return;

}else{

  if(!emailActivatedCheck($mysqli, $email)){
    $responseSignUp["error"] = true;
    $responseSignUp["msg"] ="Email already in existed, Please use other email.";
    echo json_encode($responseSignUp);
    return;
  }
 
  $subject = "Please activate your Philippine Navy Decal System account";
  $content = "<center><b>Welcome to Philippine Navy Decal System, ".$email."!</b> <br><br> To activate your account, please click on the button below to verify your email address. Once activated, you'll have full access to Philippine Navy Decal System.<br> <br><a href='https://".$_SERVER['SERVER_NAME']."/activate?code=".$code."&email=".$email."'>Activate Account</a><br><br><hr style='border-bottom:#e4e4ed 5px dotted;border-width:0 0 5px 0'><br> Button not working? Try pasting this URL into your browser: <strong><a href='https://".$_SERVER['SERVER_NAME']."/activate?code=".$code."&email=".$email."'>https://".$_SERVER['SERVER_NAME']."/activate?code=".$code."&email=".$email."</a></center>";
  
  $responseMail = sendMail($email, $subject, $content);
  if($responseMail["error"]) {
    $responseSignUp["error"] = true;
    $responseSignUp["msg"] ="Error occured while sending activation code.";
    echo json_encode($responseSignUp);
    return;
  }

  $response = updateCodeAccount($mysqli, $email, $code);
  if($response['error']){
    $responseSignUp["error"] = true;
    $responseSignUp["msg"] ="Error occured while sending activation code.";
    echo json_encode($responseSignUp);
    return;
  }

  $responseSignUp["error"] = false;
  $responseSignUp["email"] = $email;
  $responseSignUp["msg"] = "Activation Email Sent, Please check your email for activation.";
  echo json_encode($responseSignUp);
  return;

}
?>