<?php
header("Content-Security-Policy: default-src 'none'; script-src 'none'; style-src 'none'; font-src 'none'; connect-src 'none'; img-src 'none'; frame-src 'none'; media-src 'none'; object-src 'none'; manifest-src 'none'; worker-src 'none'; prefetch-src 'none'; frame-ancestors 'none'; form-action 'none';");
include_once 'includes/csrf.php';
include_once 'includes/session.php';
include_once  'includes/constant.php';
include_once  'includes/config.php';
include_once  "includes/functions.php";
$csrf = new CSRF(
  'session-hashes', 
  'csrftoken',       
  5*60,
  256
);
if(MAINTENANCE == "1"){
	header("Location: maintenance");
	return;
}

$mysqli = db_connect($config);
$responseActivate = array();

if(!$csrf->validate('activate')) {
    $responseActivate['msg']       = "CSRF: Verification has been unsuccessful";
    $responseActivate['error']     = true;
    echo json_encode($responseActivate);
    return;
}

if(!isset($_POST['email'])  && !isset($_POST['email']) && !isset($_POST['password'])  && !isset($_POST['cpassword'])){
    $responseActivate['msg']       = "Error Occurred while logging in!";
    $responseActivate['error']     = true; 
    echo json_encode($responseActivate);
    return;
}

$email      = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8'));
$code       = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['code'], ENT_QUOTES, 'UTF-8'));
$password   = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['password'], ENT_QUOTES, 'UTF-8'));
$cpassword  = mysqli_real_escape_string($mysqli, htmlspecialchars($_POST['cpassword'], ENT_QUOTES, 'UTF-8'));

$number          = preg_match('@[0-9]@', $password);
$uppercase       = preg_match('@[A-Z]@', $password);
$lowercase       = preg_match('@[a-z]@', $password);
$specialChars    = preg_match('@[^\w]@', $password);

if(!activationCheck($mysqli, $email, $code)){
    $responseActivate['msg']       = "Error occured while creating account.";
    $responseActivate['error']     = true;
    echo json_encode($responseActivate);
    return;
}

if(strlen($password) < 8 || !$number || !$uppercase || !$lowercase || !$specialChars) {
    $msg = "Password must be at least 8 characters in length and must contain at least one number, one upper case letter, one lower case letter and one special character.";
    $responseActivate['msg']        = $msg;
    $responseActivate['error']      = true;
    echo json_encode($responseActivate);
    return;
}

if($password != $cpassword){
    $responseActivate['msg']        = "Password do not match!";
    $responseActivate['error']      = true;
    echo json_encode($responseActivate);
    return;
}

$encrypted_password = sha1(md5(sha1($password)));
$response = updateUserAccount($mysqli, $email, $code, $encrypted_password);
if($response['error']){
    $responseActivate['msg']        = "Error occured while creating account.";
    $responseActivate['error']      = true;
    echo json_encode($responseActivate);
    return;
}

$responseActivate['location']       = "login";
$responseActivate['msg']            = "You have successfully activated your account.";
$responseActivate['error']          = false;
echo json_encode($responseActivate);
return;
?>