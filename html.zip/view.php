<?php
include_once 'includes/csrf.php';
session_start();
if(!isset($_GET['id'])){
    echo '<script>window.location="404"</script>';
}
if(!isset($_COOKIE['user_c']) && !isset($_SESSION['email'])){
    header('Location: login');
}
include_once 'includes/config.php';
include_once 'includes/functions.php';
include_once 'includes/constant.php';

$csrf = new CSRF(
	'session-hashes', 
	'csrftoken',       
	5*60,
	256
  );
if(MAINTENANCE == "1"){
	header("Location: /maintenance");
	return;
}
$mysqli = db_connect($config);
$email = mysqli_real_escape_string($mysqli, $_SESSION["email"]);
$aid =  mysqli_real_escape_string($mysqli, htmlspecialchars($_GET['id'], ENT_QUOTES, 'UTF-8'));
$from = mysqli_real_escape_string($mysqli,  htmlspecialchars($_GET['from'], ENT_QUOTES, 'UTF-8'));
$response =  loginAccount($mysqli, $email);
if($response['error']){
  session_destroy();
  unset($_SESSION['email']);
  setcookie("user_c", "", time() - 3600);
  header('Location: /login');
  return;
}
$uid = $response["id"];
if(!didCheck($mysqli, $aid, $uid)){
    $_SESSION["state"]  = "danger";
    $_SESSION["title"]  = "Error";
    $_SESSION["msg"]    = "Problem occured while getting data...";
    header('Location: /pending');
    return;
}
$responseDecalInfo = getDecalInformation($mysqli, $aid);
if($responseDecalInfo["error"]){
    header('Location: /404');
    return;
}
$resVehicleInfo = getVehicleInformation($mysqli, $responseDecalInfo["vehicle_id"]);
$classification = $response["classification"];
$responseRead = setRead($mysqli, $aid, $response['id']);
include_once 'includes/header-home.php';
?>
<body data-background-color="dark">
	<div class="wrapper">
        <?php include "includes/navbar.php" ?>
		<?php include "includes/sidebar.php"; ?>

		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h2 class="text-white pb-2">Welcome, <?php echo $response["firstname"]; ?>!</h2>
					</div>
					<div class="row">
					<div class="col-md-12">
							<form id="decalForm" class="card" method="post" action="/save.edit">
                            <?=$csrf->input('edit');?>
                            <input id="classification" name="classification" type="hidden" value="<?php echo $response["classification"]  ?>"/>
                            <input type="hidden" name="decalid" value="<?php echo $aid ?>"/>
                                            <?php
                                             if(base64_decode($_GET["from"])=="pending.php"){
                                                $path = "Pending";
                                             }else if(base64_decode($_GET["from"])=="rejected.php"){
                                                $path = "Rejected";
                                             }else if(base64_decode($_GET["from"])=="approved.php"){
                                                $path = "Approved";
                                             }else if(base64_decode($_GET["from"])=="history.php"){
                                                $path = "History";
                                             }
                                             ?>
								<div class="card-header">
									<div class="d-flex align-items-center">
										<h4 class="card-title">Decal Request >> <?php echo $path ?> </h4>
                                        <div class="float-right w100">
                                            <button class="btn btn-primary btn-round pull-right pl-5 pr-5 ml-2 mr-2" type="button" data-toggle="modal" data-target="#timelineModal">
                                                <i class="fas fa-clock"></i>
                                                Timeline
                                            </button>
                                        </div>
									</div>
								</div>
								<div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6 mx-auto">
                                        <?php       
                                            $status = $responseDecalInfo["status"];
                                            $has_deficiency = $responseDecalInfo["has_deficiency"];
                                            if($status == "0"){
													if($has_deficiency){
														$stataFlag = "<span class='ir700'>Pending - Has Deficiency</span>";
													}else{
														$stataFlag = "<span class='io700'>Pending</span>";
													}
											}else if($status == "1"){
												if($responseDecalInfo["date_claimed"] != "" && $responseDecalInfo["claimed_by"] != ""){
                                                    $stataFlag = "<span  class='ig700'>Claimed</span>";
                                                }else{
                                                    $stataFlag = "<span  class='ig700'>Approved</span>";
                                                }
											}else if($status == "2"){
												$stataFlag = "<span class='ir700'>Rejected</span>";
											}else if($status == "3"){
												$stataFlag = "<span class='ig700'>Claimed</span>";
											} 
                                        ?>
                
                                                <div class="form-group">
                                                    <h5 class="card-title">Status: <?php echo  $stataFlag  ?></h5>
                                                </div>
                                            <?php if($responseDecalInfo["status"] == '1'){?>
                                                <?php if($responseDecalInfo["date_claimed"] != "" && $responseDecalInfo["claimed_by"] != ""){ ?>
                                                <div class="form-group">
                                                    <h5 class="card-title">Remarks: <span class="italic">Decal is already claimed by <?php echo $responseDecalInfo["claimed_by"] ?></span> </h5>
                                                </div>
                                                <?php }else { ?>
                                                <div class="form-group">
                                                    <h5 class="card-title">Remarks: <span class="italic">Claimed your Decal in your respective SIO where you apply.</span> </h5>
                                                </div>
                                                <?php } ?>
                                            <?php } ?>
                                            <?php if($responseDecalInfo["has_deficiency"] || $responseDecalInfo["status"] == '2'){?>
                                                <div class="form-group">
                                                    <h5 class="card-title">Remarks: <span class="ir"><?php echo  $responseDecalInfo["remarks"] ?></span> </h5>
                                                </div>
                                            <?php } ?>
                                        <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="sio">Select SIO</label>
                                                        <select class="form-control" name="sio" id="sio" disabled>
                                                        <?php $sios = getAllSios($mysqli, $responseDecalInfo["sio_id"]);
                                                        foreach ($sios as $value){
                                                            echo '<option value="'.$value['id'].'" '.$value['selected'].'>'.$value['sios'].'</option>';
                                                        } ?>
                                                        </select>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="year_model">Year Model</label>
                                                            <input type="text" id="year" name="year" value="<?php echo $resVehicleInfo['year_model'] ?>" hidden>
                                                            <select class="form-control" name="year_model" id="year_model" disabled></select>
                                                            
                                                        </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="plate_number">Plate No.</label>
                                                        <input class="form-control" value="<?php echo $resVehicleInfo['plate_number'] ?>" placeholder="Enter Plate No." id="plate_number" name="plate_number" type="text" disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="vehicle_color">Color</label>
                                                        <input class="form-control" value="<?php echo $resVehicleInfo['vehicle_color'] ?>" placeholder="Enter Vehicle Color" id="vehicle_color" name="vehicle_color" type="text" disabled>
                                                    </div>
                                                </div>
											</div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="vehicle_maker">Vehicle Manufacturer</label>
                                                        <input class="form-control" value="<?php echo $resVehicleInfo['vehicle_maker'] ?>" placeholder="Enter Vehicle Manufacturer" id="vehicle_maker" name="vehicle_maker" type="text" disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="vehicle_model">Vehicle Model</label>
                                                        <input type="text" value="<?php echo $resVehicleInfo['vehicle_model'] ?>" class="form-control" id="vehicle_model" name="vehicle_model" placeholder="Enter Vehicle Model" disabled>
											        </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="chassis_number">Chassis No.</label>
                                                        <input type="text" value="<?php echo $resVehicleInfo['chassis_number'] ?>" class="form-control" id="chassis_number" name="chassis_number" placeholder="Enter Chassis No." disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="motor_number">Engine No.</label>
                                                        <input class="form-control" value="<?php echo $resVehicleInfo['motor_number'] ?>" placeholder="Enter Engine No." id="motor_number" name="motor_number" type="text" disabled>
                                                    </div>
                                                </div>
											</div>
                                            <?php if($classification == "8" || $classification == "9" || $classification == "10"){ ?>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="endorse_by">Endorse by</label>
                                                        <input type="text" class="form-control" value="<?php echo $responseDecalInfo['endorse_by'] ?>" id="endorse_by" name="endorse_by" placeholder="Enter name of your Endorser"  disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="owner">Endorser's Contact No.</label>
                                                        <input class="form-control" placeholder="63xxxxxxxxx"  value="<?php echo $responseDecalInfo['endorser_contact'] ?>" id="endorser_phone" name="endorser_phone" type="phone" onkeypress="return onlyNumberKey(event)" maxlength="13" disabled>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php } ?>
											<div class="form-group">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="owner">Is the vehicle in your name?</label>
                                                        <select class="form-control" name="owner" id="owner" disabled>
                                                            <option value="1" <?php if($resVehicleInfo['is_owner'] == "1"){ echo "selected"; } ?>>Yes</option>
                                                            <option value="0" <?php if($resVehicleInfo['is_owner'] == "0"){ echo "selected"; } ?>>No</option>
                                                        </select>
                                                    </div>
                                                    <?php if($classification == "2") { ?>
                                                    <div class="col-lg-6">
                                                        <label for="decal_type">Decal Type</label>
                                                        <select class="form-control" name="decal_type" id="decal_type" disabled>
                                                            <option value="passcard" <?php if($responseDecalInfo['decal_type'] == "passcard"){ echo "selected"; } ?>>Passcard</option>
                                                            <option value="sticker" <?php if($responseDecalInfo['decal_type'] == "sticker"){ echo "selected"; } ?>>Sticker</option>
                                                        </select>
                                                    </div>
                                                    <?php } ?>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                    <label>Application Form <i>(PDF or Image)</i></label>
                                            </div> 
                                            <div class="form-group nd" id="select_file_af">
                                                
                                                <div class="upload-btn-wrapper">
                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                    <input id="afupload" type="file" name="id_af_file" accept="application/pdf, image/x-png, image/gif, image/jpeg; capture=camera">
                                                </div>
                                                <br>
                                                <div id="progress_af" class="progress nd" >
                                                     <div class="progress-bar progress-bar-success"></div>
                                                 </div>
                                            </div>
                                            <div id="uploaded_images_af" class="form-group">
                                                <div class="uploaded_af avatar-id avatar-new"> 
                                                    <input type="text" value="<?php echo $responseDecalInfo['application_form_path'] ?>" name="uploaded_af_name" id="uploaded_af_name" hidden=""> 
                                                    <?php if(fileExtension($responseDecalInfo['application_form_path']) == "pdf"){ ?>
                                                        <a href="<?php echo $responseDecalInfo['application_form_path'] ?>"  target="_blank"> 
                                                            <img src="/img/pdf_icon.png" class="avatar-img rounded"> 
                                                        </a> 
                                                        <a id="remove-af-btn" class="img_rmv btn nd">
                                                            <i class="fas fa-trash-alt removebtn"></i>
                                                        </a> 
                                                    <?php }else{ ?>
                                                        <a target="_blank" id="photoviewer_af" href="<?php echo $responseDecalInfo['application_form_path'] ?>"> 
                                                            <img src="<?php echo $responseDecalInfo['application_form_path'] ?>" class="avatar-img rounded"> 
                                                        </a> 
                                                        <a id="remove-af-btn" class="img_rmv btn nd">
                                                            <i class="fas fa-trash-alt removebtn"></i>
                                                        </a> 
                                                    <?php } ?>
                                                </div>
                                            </div>


                                            <?php if($classification == "1"){ ?>
                                            <div id="militaryID">
                                                <div class="form-group">
                                                    <label>Military ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_mf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_mf" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="mfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_mf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_mf">
                                                                <div class="uploaded_mf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_mf_name" id="uploaded_mf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_mb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_mb" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="mbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_mb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                                </div>
                                                            <div id="uploaded_images_mb">
                                                                <div class="uploaded_mb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_mb_name" id="uploaded_mb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "2"){ ?>
                                            <div id="retirementID">
                                                <div class="form-group">
                                                    <label>Retirement ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_rf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_rf" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="rfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_rf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                                </div>
                                                            <div id="uploaded_images_rf">
                                                                <div class="uploaded_rf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_rf_name" id="uploaded_rf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_rb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_rb" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="rbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_rb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_rb">
                                                                <div class="uploaded_rb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_rb_name" id="uploaded_rb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "3"){ ?>
                                            <div id="reservistID">
                                                <div class="form-group">
                                                    <label>Reservist ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_resf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_resf" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="resfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_resf" class="progress nd">
                                                                     <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                                </div>
                                                            <div id="uploaded_images_resf">
                                                                <div class="uploaded_resf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_resf_name" id="uploaded_resf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_resb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_resb" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="resbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_resb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                                </div>
                                                            <div id="uploaded_images_resb">
                                                                <div class="uploaded_resb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_resb_name" id="uploaded_resb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "4"){ ?>
                                            <div id="chrID">
                                                <div class="form-group">
                                                    <label>CivHR ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_cf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_cf" class="nd">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="cfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_cf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_cf">
                                                                <div class="uploaded_cf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_cf_name" id="uploaded_cf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_cb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_cb" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="cbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_cb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_cb">
                                                                <div class="uploaded_cb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_cb_name" id="uploaded_cb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "5"){ ?>
                                            <div id="projectfund">
                                                <div class="form-group">
                                                    <label>Service Contract</label>
                                                </div>
                                                <div class="form-group">
                                                    <div id="select_file_pf" class="nd">
                                                        
                                                        <div class="upload-btn-wrapper">
                                                            <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                            <input id="pfupload" type="file" name="id_service_file" accept="image/x-png, image/gif, image/jpeg" >
                                                        </div>
                                                        <div id="progress_pf" class="progress nd">
                                                            <div class="progress-bar progress-bar-success"></div>
                                                        </div>
                                                    </div>
                                                    <div id="uploaded_images_pf">
                                                        <div class="uploaded_pf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['service_contract_path'] ?>" name="uploaded_pf_name" id="uploaded_pf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_pf" href="<?php echo $responseDecalInfo['service_contract_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['service_contract_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-pf-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                    </div><br>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "6"){ ?>
                                            <div id="dependentID">
                                                <div class="form-group">
                                                    <label>Dependent ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_df">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_df" class="nd">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_df" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                                </div>
                                                            <div id="uploaded_images_df">
                                                                <div class="uploaded_df avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_df_name" id="uploaded_df_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_db">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_db" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_db" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_db">
                                                                <div class="uploaded_db avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_db_name" id="uploaded_db_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "7"){ ?>
                                            <div id="retiredDependent">
                                                <div class="form-group">
                                                    <label>Father/Mother's Retirement ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_drf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_drf" class="nd">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="drfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_drf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_drf">
                                                                <div class="uploaded_drf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_drf_name" id="uploaded_drf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_drb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_drb" class="nd">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="drbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_drb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_drb">
                                                                <div class="uploaded_drb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_drb_name" id="uploaded_drb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Birth Certificate</label>
                                                </div>
                                                <div class="form-group">
                                                    <div id="select_file_bc" class="nd">
                                                        <div class="upload-btn-wrapper">
                                                            <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                            <input id="bcupload" type="file" name="id_birth_file" accept="image/x-png, image/gif, image/jpeg" >
                                                        </div>
                                                        <div id="progress_bc" class="progress nd">
                                                            <div class="progress-bar progress-bar-success"></div>
                                                        </div>
                                                    </div>
                                                    <div id="uploaded_images_bc">
                                                        <div class="uploaded_bc avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['birth_cert_path'] ?>" name="uploaded_bc_name" id="uploaded_bc_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_bc" href="<?php echo $responseDecalInfo['birth_cert_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['birth_cert_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-bc-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                    </div><br>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "8"){ ?>
                                            <div id="concessionaires">
                                                <div class="form-group">
                                                    <label>Driver's License</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_dlf" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dlfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_dlf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                                </div>
                                                            <div id="uploaded_images_dlf">
                                                                <div class="uploaded_dlf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_dlf_name" id="uploaded_dlf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_dlb" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dlbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_dlb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_dlb">
                                                                <div class="uploaded_dlb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_dlb_name" id="uploaded_dlb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "9"){ ?>
                                            <div id="tenant">
                                                <div class="form-group">
                                                    <label>Tenant's Issued ID</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_tif">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_tif"  class="nd">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="tifupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_tif" class="progress nd">
                                                                     <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_tif">
                                                                <div class="uploaded_tif avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_tif_name" id="uploaded_dlf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_tib">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_tib" class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="tibupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_tib" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_tib">
                                                                <div class="uploaded_tib avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_tib_name" id="uploaded_tib_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }else if($classification == "10"){ ?>
                                            <div id="civilian">
                                                <div class="form-group">
                                                    <label>Driver's License</label>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlf">Front Picture</label>
                                                            <br>
                                                            <div id="select_file_dlf"  class="nd">
                                                                
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dlfupload" type="file" name="id_front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_dlf" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                                </div>
                                                            <div id="uploaded_images_dlf">
                                                                <div class="uploaded_dlf avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['frontid_path'] ?>" name="uploaded_dlf_name" id="uploaded_dlf_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_front" href="<?php echo $responseDecalInfo['frontid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['frontid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-front-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label for="select_file_dlb">Back Picture</label>
                                                            <br>
                                                            <div id="select_file_dlb"  class="nd">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                                    <input id="dlbupload" type="file" name="id_back_file" accept="image/x-png, image/gif, image/jpeg" >
                                                                </div>
                                                                <div id="progress_dlb" class="progress nd">
                                                                    <div class="progress-bar progress-bar-success"></div>
                                                                </div>
                                                            </div>
                                                            <div id="uploaded_images_dlb">
                                                                <div class="uploaded_dlb avatar-id avatar-new"> 
                                                                    <input type="text" value="<?php echo $responseDecalInfo['backid_path'] ?>" name="uploaded_dlb_name" id="uploaded_dlb_name" hidden=""> 
                                                                    <a target="_blank" id="photoviewer_back" href="<?php echo $responseDecalInfo['backid_path'] ?>"> 
                                                                        <img src="<?php echo $responseDecalInfo['backid_path'] ?>" class="avatar-img rounded"> 
                                                                    </a> 
                                                                    <a id="remove-back-btn" class="img_rmv btn nd">
                                                                        <i class="fas fa-trash-alt removebtn"></i>
                                                                    </a> 
                                                                </div>
                                                            </div><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                         <?php }?>
                                               
                                                <div class="form-group">
                                                    <label>Official Receipt <i>(PDF or Image)</i></label>
                                                </div> 
                                                <div class="form-group nd" id="select_file_or">
                                                    
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                        <input id="orupload" type="file" name="or_file" accept="application/pdf, image/x-png, image/gif, image/jpeg" >
                                                    </div>
                                                    
                                                    <br>
                                                    <div id="progress_or" class="progress nd">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    
                                                    <div id="files_or" class="files"></div>
                                                    <input type="text" name="uploaded_or_file_name" id="uploaded_or_file_name" hidden>
                                                </div>
                                                <div id="uploaded_images_or" class="form-group">
                                                   <div class="uploaded_or avatar avatar-xxxl"> 
                                                        <input type="text" value="<?php echo $responseDecalInfo['or_path']; ?>" name="uploaded_or_name" id="uploaded_or_name" hidden=""> 
                                                        <?php if(fileExtension($responseDecalInfo['or_path']) == "pdf"){ ?>
                                                            <a href="<?php echo $responseDecalInfo['or_path']; ?>" target="_blank">
                                                                <img src="/img/pdf_icon.png" class="avatar-img rounded">
                                                            </a> 
                                                            <a id="remove_or" class="img_rmv btn nd">
                                                                <i class="fas fa-trash-alt removebtn"></i>
                                                            </a> 
                                                        <?php } else { ?>
                                                            <a target="_blank" id="photoviewer_or" href="<?php echo $responseDecalInfo['or_path']; ?>">
                                                                <img src="<?php echo $responseDecalInfo['or_path']; ?>" class="avatar-img rounded">
                                                            </a> 
                                                            <a id="remove_or" class="img_rmv btn nd">
                                                                <i class="fas fa-trash-alt removebtn"></i>
                                                            </a> 
                                                        <?php } ?>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label>Certificate of Registration <i>(PDF or Image)</i></label>
                                                </div> 
                                                <div class="form-group nd" id="select_file_cr">
                                                    
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                        <input id="crupload" type="file" name="cr_file" accept="application/pdf, image/x-png, image/gif, image/jpeg" >
                                                    </div>
                                                    
                                                    <br>
                                                    <div id="progress_cr" class="progress nd">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    
                                                    <div id="files_cr" class="files"></div>
                                                    <input type="text" name="uploaded_cr_file_name" id="uploaded_cr_file_name" hidden>
                                                </div>
                                                <div id="uploaded_images_cr" class="form-group">
                                                   <div class="uploaded_cr avatar avatar-xxxl"> 
                                                       <input type="text" value="<?php echo $responseDecalInfo['cr_path']; ?>" name="uploaded_cr_name" id="uploaded_cr_name" hidden=""> 
                                                       <?php if(fileExtension($responseDecalInfo['cr_path']) == "pdf"){ ?>
                                                            <a href="<?php echo $responseDecalInfo['cr_path']; ?>" target="_blank">
                                                                <img src="/img/pdf_icon.png" class="avatar-img rounded">
                                                            </a> 
                                                            <a id="remove_cr" class="img_rmv btn nd">
                                                                <i class="fas fa-trash-alt removebtn"></i>
                                                            </a> 
                                                        <?php }else{ ?>
                                                            <a target="_blank" id="photoviewer_cr" href="<?php echo $responseDecalInfo['cr_path']; ?>">
                                                                <img src="<?php echo $responseDecalInfo['cr_path']; ?>" class="avatar-img rounded">
                                                            </a> 
                                                            <a id="remove_cr" class="img_rmv btn nd">
                                                                <i class="fas fa-trash-alt removebtn"></i>
                                                            </a> 
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Vehicle Front Picture</label>
                                                </div> 
                                                <div class="form-group nd" id="select_file_front">
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                        <input id="frontupload" type="file" name="front_file" accept="image/x-png, image/gif, image/jpeg" >
                                                    </div>
                                                    <br>
                                                    <div id="progress_front" class="progress nd">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    
                                                    <div id="files_front" class="files"></div>
                                                    <input type="text" name="uploaded_front_file_name" id="uploaded_front_file_name" hidden>
                                                </div>
                                                <div id="uploaded_images_front" class="form-group">
                                                   <div class="uploaded_front avatar avatar-xxxl"> 
                                                       <input type="text" value="<?php echo $responseDecalInfo['front_path']; ?>" name="uploaded_front_name" id="uploaded_front_name" hidden=""> 
                                                       <a target="_blank" id="photoviewer_front2" href="<?php echo $responseDecalInfo['front_path']; ?>">
                                                           <img src="<?php echo $responseDecalInfo['front_path']; ?>" class="avatar-img rounded">
                                                        </a> 
                                                        <a id="remove_front" class="img_rmv btn nd">
                                                            <i class="fas fa-trash-alt removebtn"></i>
                                                        </a> 
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label>Vehicle Rear Picture</label>
                                                </div> 
                                                <div class="form-group nd" id="select_file_rear">
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Image</button>
                                                        <input id="rearupload" type="file" name="rear_file" accept="image/x-png, image/gif, image/jpeg" >
                                                    </div>
                                                    
                                                    <br>
                                                    <div id="progress_rear" class="progress nd">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    
                                                    <div id="files_rear" class="files"></div>
                                                    <input type="text" name="uploaded_rear_file_name" id="uploaded_rear_file_name" hidden>
                                                </div>
                                                <div id="uploaded_images_rear" class="form-group">
                                                   <div class="uploaded_rear avatar avatar-xxxl"> 
                                                       <input type="text" value="<?php echo $responseDecalInfo['rear_path']; ?>" name="uploaded_rear_name" id="uploaded_rear_name" hidden=""> 
                                                       <a target="_blank" id="photoviewer_rear" href="<?php echo $responseDecalInfo['rear_path']; ?>">
                                                           <img src="<?php echo $responseDecalInfo['rear_path']; ?>" class="avatar-img rounded">
                                                        </a> 
                                                        <a id="remove_rear" class="img_rmv btn nd">
                                                            <i class="fas fa-trash-alt removebtn"></i>
                                                        </a> 
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Vehicle 2 Sides Pictures</label>
                                                </div> 
                                                <div class="form-group nd" id="select_file_sides">
                                                    <div class="upload-btn-wrapper">
                                                        <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Images</button>
                                                        <input id="sidesupload" type="file"  name="sides_file" accept="image/x-png, image/gif, image/jpeg" >
                                                    </div>
                                                    
                                                    <br>
                                                    <div id="progress_sides" class="progress nd">
                                                        <div class="progress-bar progress-bar-success"></div>
                                                    </div>
                                                    
                                                    <div id="files_sides" class="files"></div>
                                                    <input type="text" name="uploaded_sides_file_name" id="uploaded_sides_file_name" hidden>
                                                </div>
                                                <div id="uploaded_images_sides" class="form-group">
                                                    <?php 
                                                    if(strpos($responseDecalInfo['sides_path'], ",") !== false ) {
                                                        $sides_path_array = explode (",", $responseDecalInfo['sides_path']);
                                                        $i = 0;
                                                        foreach ($sides_path_array as $sides) { 
                                                        $i++;    ?>
                                                        <div class="uploaded_sides avatar avatar-xxxl"> 
                                                            <input type="text" value="<?php echo $sides; ?>" name="uploaded_sides_name[]" id="uploaded_sides_name[]" hidden=""> 
                                                            <a target="_blank" id="photoviewer_side<?php echo $i;?>" href="<?php echo $sides; ?>">
                                                                <img src="<?php echo $sides; ?>" class="avatar-img rounded">
                                                            </a> 
                                                            <a id="remove_side<?php echo $i; ?>" class="img_rmv btn nd">
                                                                <i class="fas fa-trash-alt removebtn"></i>
                                                            </a> 
                                                        </div>&nbsp; &nbsp;
                                                  <?php }
                                                    }else{?>
                                                    <div class="uploaded_sides avatar avatar-xxxl"> 
                                                       <input type="text" value="<?php echo $responseDecalInfo['sides_path']; ?>" name="uploaded_sides_name[]" id="uploaded_sides_name[]" hidden=""> 
                                                       <a target="_blank" id="photoviewer_side1" href="<?php echo $responseDecalInfo['sides_path']; ?>">
                                                           <img src="<?php echo $responseDecalInfo['sides_path']; ?>" class="avatar-img rounded">
                                                        </a> 
                                                        <a class="img_rmv btn">
                                                            <i class="fas fa-trash-alt removebtn"></i>
                                                        </a> 
                                                    </div>
                                                    <?php }?>
                                                  
                                                </div>
                                                <div id="support" class="nd">
                                                    <div class="form-group">
                                                        <label>Supporting Documents(DOS, Authorization) <i>(PDF or Image)</i></label>
                                                    </div> 
                                                    <div class="form-group nd" id="select_file_support">
                                                        <div class="upload-btn-wrapper">
                                                            <button class="btn2 btn-primary  pr-3 pl-3"><i class="icon-cloud-upload"></i> Upload Images</button>
                                                            <input id="supportupload" type="file" name="support_file" accept="image/x-png, image/gif, image/jpeg, application/pdf" >
                                                        </div>
                                                        
                                                        <br>
                                                        <div id="progress_support" class="progress nd">
                                                            <div class="progress-bar progress-bar-success"></div>
                                                        </div>
                                                        
                                                        <div id="files_support" class="files"></div>
                                                        <input type="text" name="uploaded_support_file_name[]" id="uploaded_support_file_name[]" hidden>
                                                    </div>
                                                    <div id="uploaded_images_support" class="form-group">
                                                    <?php 
                                                        if($responseDecalInfo['support_path'] != ""){
                                                            if(strpos($responseDecalInfo['support_path'], ",") !== false ) {
                                                                $support_path_array = explode (",", $responseDecalInfo['support_path']);
                                                                $i = 0;
                                                                foreach ($support_path_array as $support) { 
                                                                $i++; ?>
                                                                <div class="uploaded_support avatar avatar-xxxl"> 
                                                                    <input type="text" value="<?php echo $support; ?>" name="uploaded_support_name[]" id="uploaded_support_name[]" hidden=""> 
                                                                    <?php if(fileExtension($support) == "pdf"){ ?>    
                                                                        <a href="<?php echo $support; ?>" target="_blank">
                                                                            <img src="/img/pdf_icon.png" class="avatar-img rounded">
                                                                        </a> 
                                                                        <a id="remove_support<?php echo $i ?>" class="img_rmv btn nd">
                                                                            <i class="fas fa-trash-alt removebtn"></i>
                                                                        </a> 
                                                                    <?php }else{ ?>
                                                                        <a target="_blank" id="photoviewer_support<?php echo $i ?>" href="<?php echo $support; ?>">
                                                                            <img src="<?php echo $support; ?>" class="avatar-img rounded">
                                                                        </a> 
                                                                        <a id="remove_support<?php echo $i ?>" class="img_rmv btn nd">
                                                                            <i class="fas fa-trash-alt removebtn"></i>
                                                                        </a> 
                                                                    <?php } ?>
                                                                </div>&nbsp; &nbsp;
                                                    <?php }
                                                        }else{?>
                                                            <div class="uploaded_support avatar avatar-xxxl"> 
                                                            <input type="text" value="<?php echo $responseDecalInfo['support_path']; ?>" name="uploaded_support_name[]" id="uploaded_support_name[]" hidden=""> 
                                                            <?php if(fileExtension($responseDecalInfo['support_path']) == "pdf"){ ?>    
                                                                <a href="<?php echo $responseDecalInfo['support_path']; ?>"  target="_blank">
                                                                    <img src="/img/pdf_icon.png" class="avatar-img rounded">
                                                                </a> 
                                                                <a id="remove_support1" class="img_rmv btn nd">
                                                                    <i class="fas fa-trash-alt removebtn"></i>
                                                                </a>
                                                            <?php }else{ ?>
                                                                <a target="_blank" id="photoviewer_support1" href="<?php echo $responseDecalInfo['support_path']; ?>">
                                                                    <img src="<?php echo $responseDecalInfo['support_path']; ?>" class="avatar-img rounded">
                                                                </a> 
                                                                <a id="remove_support1" class="img_rmv btn nd">
                                                                    <i class="fas fa-trash-alt removebtn"></i>
                                                                </a>
                                                            <?php } ?>
                                                            </div>&nbsp; &nbsp;
                                                        <?php }
                                                        }?>
                                                    </div>
                                                </div>
                                                <br>
                                                <div class="card-action">
                                                    <div class="d-flex justify-content-center">
                                                    <?php if($status == "0"){ ?>
                                                            <a id="cancel-btn" href="/view/<?php echo $aid; ?>/<?php echo $from; ?>" class="btn btn-danger btn-round pr-5 pl-5 mr-1"><i class="fas fa-ban"></i>Cancel Edit</a>
                                                        <?php if ($responseDecalInfo["has_deficiency"]){?>
                                                            <button name="resubmit" type="submit" id="submit-btn" class="btn btn-success btn-round pr-5 pl-5">Resubmit Request</button>
                                                        <?php }else{ ?>
                                                            <button name="update" type="submit" id="submit-btn" class="btn btn-primary btn-round pr-5 pl-5 ml-1">Update Request</button>
                                                        <?php } ?>
                                                        <?php if($responseDecalInfo["approved_level"] == "4" || $responseDecalInfo["has_deficiency"]) { ?>
                                                            <button type="button" id="edit-btn" class="btn btn-primary btn-round pr-5 pl-5"><i class="fas fa-edit"></i>Edit Request</button>
                                                        <?php } ?>
                                                    <?php } ?>
								                    </div>
                                                </div>
                                                <br>
                                                <br>
                                            </div>
								</div>
                            </form>
						</div>
					</div>
			
				</div>
			</div>
                <div class="modal fade" id="timelineModal" role="dialog" aria-hidden="true">
                    <div class="modal-dialog mw" role="document">
                        <div class="modal-content">
                            <div class="modal-header no-bd">
                                <h3 class="modal-title mt700">
                                    Timeline
                                </h3>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <ul class="timeline">
                                                <?php $responseTimeline = getTimeline($mysqli, $aid);
                                                    while($u = mysqli_fetch_array($responseTimeline)) { 
                                                        if($u["what_type"] == "0"){
                                                            $timeline = "";
                                                            $title = "Decal request submitted";
                                                            $icon_color = "warning";
                                                            $icon  = "flaticon-message";
                                                        }else if($u["what_type"] == "1"){
                                                            $timeline = "timeline-inverted";
                                                            $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                            $role = $responseAdmin["user_role"];
                                                            $toRole = $role - 1;
                                                            $title = "Endorsed by ".$responseAdmin['account_name']." to ".getRoleName($mysqli, $toRole)["name"];
                                                            $icon_color = "primary";
                                                            $icon  = "icon-rocket";
                                                        }else if($u["what_type"] == "2"){
                                                            $timeline = "timeline-inverted";
                                                            $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                            $responseDecal = getDecalInformation($mysqli, $u["application_id"]);
                                                            $role = $responseAdmin["user_role"];
                                                            $forwardedTo = $role + 3;
                                                            $title = "Approved by ".$responseAdmin["account_name"]." and forwarded to ".getSioName($mysqli, $responseDecal["sio_id"])["sio_name"]." for printing and releasing.";
                                                            $icon_color = "success";
                                                            $icon  = "icon-like";
                                                        }else if($u["what_type"] == "3"){
                                                            $timeline = "";
                                                            $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                            $role = $responseAdmin["user_role"];
                                                            $responseDecal = getDecalInformation($mysqli, $u["application_id"]);
                                                            $title = "Decal already claimed by ".$responseDecal["claimed_by"];
                                                            $icon_color = "success";
                                                            $icon  = "flaticon-list";
                                                        }else if($u["what_type"] == "4"){
                                                            $timeline = "timeline-inverted";
                                                            $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                            $role = $responseAdmin["user_role"];
                                                            $title = "Request still Pending due to some deficiency. <br>
                                                            Check by: ". getRoleName($mysqli, $role)["name"];
                                                            $icon_color = "warning";
                                                            $icon  = "icon-dislike";
                                                        }else if($u["what_type"] == "5"){
                                                            $timeline = "timeline-inverted";
                                                            $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                            $role = $responseAdmin["user_role"];
                                                            $title = "Request rejected by ". getRoleName($mysqli, $role)["name"]."(".$responseAdmin["account_name"].")";
                                                            $icon_color = "danger";
                                                            $icon  = "icon-ban";
                                                        }else if($u["what_type"] == "6"){
                                                            $timeline = "timeline-inverted";
                                                            $responseAdmin = loginAdmin($mysqli, $u["admin_id"]);
                                                            $role = $responseAdmin["user_role"];
                                                            $title = "Your Decal is revoke by ". getRoleName($mysqli, $role)["name"]."(".$responseAdmin["account_name"].")";
                                                            $icon_color = "danger";
                                                            $icon  = "icon-ban";
                                                        }
                                                        
                                                        ?>
                                                        <li class="<?php echo $timeline ?>">
                                                            <div class="timeline-badge <?php echo $icon_color ?>"><i class="<?php echo $icon ?>"></i></div>
                                                            <div class="timeline-panel">
                                                                <div class="timeline-heading">
                                                                    <h5 class="timeline-title"><?php echo $title ?></h5>
                                                                    <p><small class="text-muted"></i><?php echo $u["what_time"] ?></small></p>
                                                                </div>
                                                            </div>
                                                        </li>
                                                <?php } ?>
                                            
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer no-bd">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                </div>
                        </div>
                    </div>
                </div>
			<footer class="footer">
				<div class="container-fluid">
				
					<div class="copyright ml-auto">
						<?php include "includes/footer.php"; ?>
					</div>				
				</div>
			</footer>
		</div>
		
	</div>
    <!--   Core JS Files   -->
	<script src="/assets/js/core/popper.min.js"></script>
	<script src="/assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="/assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="/assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

	<!-- Chart Circle -->
	<script src="/assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="/assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

    	<!-- Sweet Alert -->
	<script nonce="87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d" type="text/javascript" src="/assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="/assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="/assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Atlantis JS -->
	<script src="/assets/js/atlantis.min.js"></script>
    
    <script src="/js/upload.js"></script>
    <script src="/dist/js/iziToast.min.js"></script>
    <script src="/js/view.js"></script>
    <?php
		if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
			$state 	= $_SESSION["state"];
			$msg 	= $_SESSION["msg"];
			$title 	= $_SESSION["title"];
			?>
			<script nonce="8db0369dff542ac448aa8f9e8ceaece603fe3de4ea9afbea19a46f4b87f4959b">
				function displayNotification(title1, msg, state){
					if(state == 'success'){
						iziToast.success({title: title1, message: msg, onClosing: function () {},});
					}else{
						iziToast.error({title: title1, message: msg, onClosing: function () {},});
					}
					return;
				}
				displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>");
			</script>
	<?php } ?>
	

	<?php
		unset($_SESSION["state"]);
		unset($_SESSION["msg"]);
		unset($_SESSION["title"]);
	?>
</body>
</html>