	<!--   Core JS Files   -->
	<script type="text/javascript" src="/assets/js/core/popper.min.js"></script>
	<script type="text/javascript" src="/assets/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script type="text/javascript" src="/assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script type="text/javascript" src="/assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script type="text/javascript" src="/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

	<!-- Chart Circle -->
	<script type="text/javascript" src="/assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script type="text/javascript" src="/assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script type="text/javascript" src="/assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script type="text/javascript" src="/assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script nonce="87be3e75cbadd08834428a0086741956db584006b000d0e239a91f49d7bca3a9d" type="text/javascript" src="/assets/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script type="text/javascript" src="/assets/js/atlantis.min.js"></script>
	    
    <script type="text/javascript" src="/dist/js/iziToast.min.js"></script>
	<script type="text/javascript" src="/js/decal.list.js"></script>

		

	<?php
		if(isset($_SESSION["state"]) && $_SESSION["state"] !=""){
			$state 	= $_SESSION["state"];
			$msg 	= $_SESSION["msg"];
			$title 	= $_SESSION["title"];
			?>
			<script nonce="8db0369dff542ac448aa8f9e8ceaece603fe3de4ea9afbea19a46f4b87f4959b">
				function displayNotification(title1, msg, state){
					if(state == 'success'){
						iziToast.success({title: title1, message: msg, onClosing: function () {},});
					}else{
						iziToast.error({title: title1, message: msg, onClosing: function () {},});
					}
					return;
				}
				displayNotification("<?php echo $title; ?>" ,"<?php echo $msg; ?>" ,"<?php echo $state; ?>");
			</script>
	<?php } ?>
	

	<?php
		unset($_SESSION["state"]);
		unset($_SESSION["msg"]);
		unset($_SESSION["title"]);
	?>