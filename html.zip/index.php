<?php
include_once 'includes/phpsessid.php';
include_once 'includes/session.php';
include_once 'includes/constant.php';
if(MAINTENANCE == "1"){
  header("Location: /maintenance");
  return;
}
$page="";
include_once 'includes/header.php';
?>
    <div id="main">
      <div class="sc-glUWqk gZBdDv">
        <div class="sc-jqCOkK sc-bbmXgH sc-drlKqa kMexyI">
          <div class="sc-jqCOkK sc-bbmXgH sc-gGBfsJ sc-bIqbHp eFtCXp">
            <img width="200" height="200" src="<?php echo SITE_LOGO; ?>" class="sc-RbTVP kBYGdh">
            <h2 class="sc-iQKALj sc-dEfkYy fqMEYe"><?php echo APP;  ?></h2>
            <a href="/signup" class="sc-hEsumM sc-jxGEyO jFTvbI sc-kAzzGY gXQAXS" type="button" title="">SIGN UP</a>
            <a href="/login" class="sc-kAzzGY sc-hEsumM sc-jxGEyO sc-gacfCG boaKTO sc-chPdSV lYoTa" type="button" title="">LOGIN</a>
          </div>
          <div class="sc-jqCOkK sc-uJMKN sc-yZwTr dctPBU">
          </div>
          <div class="sc-jqCOkK sc-uJMKN sc-yZwTr dctPBU">
          </div>
          <?php 
            include_once 'includes/footer.php';
          ?>
        </div>
      </div>
    <!--<div id="cookie-container" class="cookie-container">
    <p class="content-p">
      We use cookies in this website to give you the best experience on our
      site and show you relevant ads. To find out more, read our
      <a href="#">privacy policy</a> and <a href="#">cookie policy</a>.
    </p>

    <button id="cookie-btn" class="cookie-btn">
      Okay
    </button>
    </div> -->
    </div>
    
    <div class="overlay"></div>
  </body>
<!--<script src="/js/cookie-banner.js"></script> -->
</html>
